#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		dimension = len(matrice)
		solution =[[0 for x in range(dimension)]for y in range(dimension)]
		for i in xrange(dimension):
			solution[i][i] = 1
		absP = abs(power)
		while (absP > 0):
			if (absP & 1) == 1:
				solution = self.Multiply_matrices(matrice,solution)
			absP >>=1
			matrice = self.Multiply_matrices(matrice,matrice)
		
		return solution


		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		dimension = len(a)
		RetValue =[[0 for x in range(dimension)]for y in range(dimension)]
		for i in xrange(dimension):
			for j in xrange(dimension):
				for k in xrange(dimension):
					RetValue[i][j] += a[i][k]*b[k][j]
		return RetValue

