import math
#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		#This method should return the final matrice
		#print matrice
		n = int(power)
		squares_array = []
		i = int(0)
		a = matrice
		while int(n/2) is not 0:
			if n%2 is 1:
				squares_array.append(a)
				i = i + 1
			n = int(n/2)
			a = self.Multiply_matrices(a, a)
		for j in range(0, i):
			a = self.Multiply_matrices(a, squares_array[j])
		return a

	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		result = [[0 for row in range(len(a))] for col in range(len(b[0]))]
		for i in range(len(a)):
        		for j in range(len(b[0])):
            			for k in range(len(b)):
                			result[i][j] += a[i][k]*b[k][j]
		return result


