#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE

class MatrixMultiplication:
    def __init__(self, cnter):
        self.counter = cnter

    #Matrix Multiplication
    def Multiply_matrices(self,S,T):
        self.counter = self.counter+1
        output =  [[ 0 for j in range(len(S))] for i in range(len(T[0]))]
        for i in range(len(S)):
            for j in range(len(T[0])):
                for k in range(len(S[0])):
                    output[i][j]+= S[i][k] * T[k][j]
        return output


    #Call Multiplier
    def Call_multiplier(self,X,s):
        # Identity Matrix
        op = [[1 if i==j else 0 for j in range(len(X))] for i in range(len(X))]
        if (s==1):
            return X
        else:
            while(s > 0):
                if ((s % 2) != 0):

                    op=self.Multiply_matrices( op, X)
                    s=s-1

                if(s>0):

                    X=self.Multiply_matrices( X, X)
                    s = s/2
        return  op
