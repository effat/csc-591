
# coding: utf-8
# CSC505 HW2.3(b)
# authour: Yeo Jin Kim (ykim32)

import math

# return the max number of power of 2, given n
# n = 2^p + q 
def get_maxpower(n):
    p = 0
    while n >=2:
        n = n/2
        p += 1
    return p

#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def Call_multiplier(self,matrice,power):
        #Write your code here to call Multiply_matrices lg(power) times.
        #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        #This method should return the final matrice
        height = math.ceil(math.log(power)/math.log(2)) # get the height of power
        r = matrice    # current result
        numPower = 1   # currently calculated number of power
        mem = []       # memory to store the intermediate results 
        mem.append([r,1]) # initialized with the given matrix and the number of power = 1
        for c in range(int(height-1)):         
            r = self.Multiply_matrices(r,r)    # calculate the current result of multiplication
            numPower *= 2                      # calculate the current number of power 
            mem.append([r,numPower])           # store the result of the multiplication of two matrix

        remainPower = power-numPower           # get the remaining number of power
        #print("remain:{0}".format(remainPower))
        while remainPower >=1:                 
            p = get_maxpower(remainPower)      # get the max number of power of 2, given the remaining number of power  
            r = self.Multiply_matrices(r,mem[p][0]) # calculate the current result of multiplication, using the stored results with the index p
            remainPower -= mem[p][1]           # calculate the remaining number of power
            #print("remainPower:{0}, maxpower:{1}".format(remain, p))

        return r

    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        c = [] # make a square matrix with 0-initialization
        row = []
        for i in range(len(a)):
            row.append(0)
        for i in range(len(a)):
            c.append(row[:])
                
        for i in range(len(a)):
            for j in range(len(a)):
                for k in range(len(a)):
                    c[i][j] += a[i][k]*b[k][j]
        return c


