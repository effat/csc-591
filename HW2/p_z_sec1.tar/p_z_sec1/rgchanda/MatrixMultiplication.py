#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		result = [[0 for c in range(len(matrice))] for r in range(len(matrice))]
		for i in range(len(matrice)):
			result[i][i] = 1
                while power >0: 
                	if power %2 ==0:
				matrice = self.Multiply_matrices(matrice,matrice)
				power = power/2 
                        else:
				result = self.Multiply_matrices(matrice,result)
				power = power -1
		return result
                         
	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
	        answer = [[0 for c in range(len(b[0]))] for r in range(len(a))]
		for i in range(len(a)):
			for j in range(len(b[0])):
				for k in range(len(b)):
					answer[i][j] = answer[i][j] + (a[i][k] * b[k][j]) 
		return answer

