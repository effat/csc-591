// Function calculates matrices products
class MatrixMult
{

	 
	static int counter = 0;
	public static int[][] Multiply_matrices(int a[][], int b[][]){
		int length= a.length;
	// matrix length
			int c[][] = new int[length][length] ;
 		for(int i=0;i<length;i++){
			for(int j=0;j<length;j++){
				c[i][j]=0; // Intializing the product array to zero
				for(int k=0;k<length;k++)
				{
					c[i][j] = (a[i][k]*b[k][j]) + c[i][j];
				}
			}
		}
		// matrix product is calculated
		counter=counter+1;
		
		return c;
	}
	// This function is used to invoke the Multiply_matrices; The condition for invoking Multiply_matrices is at most 2*ceiling(log power) times.
	// This method will finally return the desired product of matrices.
	public static int[][] Call_multiplier(int[][] matrix, int power)
	{int length = matrix.length;
	  
	    int ans[][] =new int[length][length];
	    for(int i=0;i<length;i++)
		{
			for(int j=0;j<length;j++)
			{       if(i!=j)
						ans[i][j]=0;
					else
						if(i==j)
						ans[i][j]=1;
			}
		}
	 
	    while (power > 0)
	    {
	        if (power%2==1)
	        { ans = Multiply_matrices(ans,matrix);
	        }	        // n must be even now
// We are performing 2*log(power) operations by using shift operator and done non-recursively 
	        power = power/2; 
			if(power>0)
				matrix = Multiply_matrices(matrix,matrix);  
	    }
	    
	    return ans;
	    
	}
	 
	public static void main(String[] args) throws Exception
	{
	    int input[][] = new int[][]{
	    	{2,4,3,1},
		    {3,1,4,2},
		    {4,6,5,3},
		    {6,2,4,1}

		    
			};
		int len = input.length;

	    MatrixMult m = new MatrixMult(); 
	    int[][] ans1 = m.Call_multiplier(input,5);
	    System.out.println("Final Product of matrices: ");
	    // Printing the product matrix.
	    for(int i=0;i<len;i++)
		{
			
			for(int j=0;j<len;j++)
			{
				System.out.print("\t"+ans1[i][j]);
			}
			System.out.println();
		}
	    
	   
	 
	}
	
}