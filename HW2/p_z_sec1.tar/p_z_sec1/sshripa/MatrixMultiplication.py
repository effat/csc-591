#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter
   
    
    def Multiply_matrices(self,a,b):
        self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
        l= len(a)
        result = [[0 for i in range(l)] for j in range(l)]
                
        for i in range(len(a)):
            for j in range(len(a)):
                for k in range(len(a)):
                    result[i][j] += a[i][k] * b[k][j]
        return (result)
    
    def Call_multiplier(self,matrice,power):
        
        flag =0
        if power < 0:
            print (" invalid input")
            return()
        elif power == 0:
            return (matrice)
        elif power % 2 !=0:
            flag = 1
            power = power-1
        g=matrice
        k = len(matrice)
        U=[2,4,8,16,32,64]
        temp = [[0 for i in range(k)] for j in range(k)]
        for i in range (len(matrice)):
            for j in range (len(matrice)):
                if i==j:
                    temp[i][j] = 1
                else:
                    temp[i][j] = 0
        if power in U:
            while (power > 1):
                if (power % 2 !=0):
                    temp = self.Multiply_matrices(matrice,temp)
                else:
                    matrice = self.Multiply_matrices(matrice,matrice)
                power = int(power/2)
        else:
            
            while (power > 0):
                if (power % 2 !=0):
                    temp = self.Multiply_matrices(matrice,temp)
                else:
                    matrice = self.Multiply_matrices(matrice,matrice)
                power = int(power/2)
        total = self.Multiply_matrices(matrice,temp)
        
        if flag == 1:
            return(self.Multiply_matrices(total,g))
        else:
            return (total)

    #counter = 0
    #power = input("Enter power")
    #power = int(power)
    #matrice = [[2,2],[2,2]]
   # n = int(input().strip())
    #matrice = []
    #for m in range(n):
     #   x = [int(x_temp) for x_temp in input().strip().split(' ')]
      #  matrice.append(x)
    #result=[0]*len(matrice)
    
    
    #Final = Call_multiplier(counter, matrice,power)
    #print(Final)
    
    

            
                
    

	
    


