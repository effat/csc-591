#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
        def __init__(self,cnter):
                self.counter=cnter
        def Call_multiplier(self,matrice,power):
                n=len(matrice)
                res = self.cid(n)
                c=0
                while(power>1):
                        if power %2==1:
                                if c==0:
                                        res=matrice
                                        c=1
                                else:
                                        res=self.Multiply_matrices(res,matrice)
                        power=power/2
                        matrice=self.Multiply_matrices(matrice,matrice)
                #print self.counter
                return self.Multiply_matrices(matrice,res)
        
                        
                
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
                
        def Multiply_matrices(self,a,b):
                self.counter +=1
                n=len(a)
                c=self.cid(n)
                for i in range(n):
                        c[i][i]=0
                #print c
                #print range(n)
                for i in range(n):
                        for j in range(n):
                                for k in range(n):
                                        c[i][j]+=a[i][k]*b[k][j]
                return c
                #Write code here to multiply 2 matrices and return the resultant matrice
		
		
        def cid(self,n):
                li=[]
                for i in range(n):
                        li.append([])
                        
                for i in range(n):
                        for j in range(n):
                                li[i].append(0)
                for i in range(n):
                        li[i][i]=1
                return li

#m1 = MatrixMultiplication(0)

#print m1.Multiply_matrices(a,b)



		
	


