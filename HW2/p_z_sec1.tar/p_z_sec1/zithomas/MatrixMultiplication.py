#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		#This method should return the final matrice
		
		if (power == 1):
			return matrice
  
		x = 1
		data = matrice
		old_data = None
		garb = {}
		while x < power:
			if x * 2 > power:
				power -= x
				if old_data == None:
					old_data = data
				else:
					old_data = self.Multiply_matrices(old_data, data)
				x = 1
				data = matrice
			else:
				x *= 2
				try:
					data = garb[str(x)]
				except:
					data = self.Multiply_matrices(data, data)
					garb[str(x)] = data
		
		if old_data != None:
			data = self.Multiply_matrices(old_data, data)

		return data	
		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		
		res = [[0 for x in range(len(a))] for x in range(len(a))]

		for i in range(len(a)):
			for j in range(len(b[0])):
				for k in range(len(b)):
					res[i][j] += a[i][k] * b[k][j]

		return res
			


