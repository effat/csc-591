#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE

class MatrixMultiplication:
        def __init__(self,cnter):
                self.counter=cnter

        def Multiply_matrices(self,a,b):
                self.counter +=1
                #Write code here to multiply 2 matrices and return the resultant matrice
                n=len(a)
                c= [[0 for row in range(n)] for col in range(n)]
                for i in range(n):
                        for j in range(n):
                                for k in range(n):
                                        c[i][j] += a[i][k] * b[k][j]
                return c
        
        def Call_multiplier(self,matrice,power):
                "Converting power into powers of 2 for eg: 10 will be [0,2,0,8]"
                d=[]
                b= bin(power)[:1:-1]
                for i in range(len(b)):
                        if int(b[i]):
                                d.append(2**i)
                        else:
                                d.append(0)
                s=matrice
                r={0:s}
                for i in range(1,len(d)):
                        s=self.Multiply_matrices(s,s)
                        r.update({i:s})
                m=r
                for i in range(len(d)):
                        if d[i]<=0:
                                m.update({i:0})
                n=len(matrice)
                k=[[1 if i==j else 0 for j in range(n)] for i in range(n)]
                
                for i in range(len(d)):
                        if (m[i]>0):
                                k=self.Multiply_matrices(k,m[i])
                return k
             
                
                
        


        
               
                        
