//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		
		int n = matrix[0].length;
		int productMatrix[][] = new int[n][n];
		 for(int i=0;i<n;i++) { //initializing product matrix as an identity matrix
			 for(int j=0;j<n;j++) {
			 if(i!=j)
				 productMatrix[i][j]=0;
			 else 
				 productMatrix[i][i]=1;	
			 }	
		 }
		 
		 if(power ==0) 
			 return productMatrix; //when matrix is raised to 0 return Identity Matrix
		 
		 if(power ==1 )
			 return matrix; //when matrix is raised to 1 return the matrix itself
		 
		while(power>0) {
			if(power%2 != 0) // when power is odd multiply the matrix once to the resultant matrix
				productMatrix = Multiply_matrices(productMatrix, matrix); 
				
			power = (int) Math.floor(power/2); //in every iteration divide n by 2
			matrix = Multiply_matrices(matrix, matrix);	// for both even and odd powers update the matrix as the square of the matrix
		}
		
		return productMatrix;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int n= a[0].length;
		int c[][] = new int[n][n];
		 //Write code here to multiply 2 matrices and return the resultant matrice
			for(int i=0; i< n ; i++) {
				for(int j=0; j< n ; j++)
				{
				 c[i][j] = 0;
					for(int k=0; k< n ; k++)
						c[i][j] = c[i][j] + a[i][k] * b[k][j];
								}
			}
			return c;
	}
}