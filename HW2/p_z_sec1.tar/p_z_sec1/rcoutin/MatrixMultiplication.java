public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		//Creating an Identity Matrix
		int[][] answer = new int[matrix.length][matrix.length];
		for(int i = 0; i < matrix.length; i++)
			for(int j = 0; j < matrix.length; j++)
				answer[i][j] = (i == j) ? 1 : 0;

		while(power>0){
			//When power is odd, multiply answer by matrix and subtract power by 1 so that it becomes even
			if(power%2!=0){
				answer=Multiply_matrices(answer, matrix);
				power=power-1;
				//power is now even
			}	
			//When power is even, power is halved and the matrix is squared
			power=power/2;
			matrix=Multiply_matrices(matrix, matrix);
		}
		return answer;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int rows= a.length;		
		//Rows=Columns in a square matrix
		int c[][]=new int[rows][rows];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < rows; j++) {
				for (int k = 0; k < rows; k++) {
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		return c;
	}
}