//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;
	
	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		 if(power == 0 || power == 1){
		     return matrix;
		 }
		 int[][] left = Call_multiplier(matrix,power/2);
		 int[][] result = Multiply_matrices(left,left);
		 if(power%2 != 0){
			 result = Multiply_matrices(result, matrix);
		 }
		 return result;
		 
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int[][] c = new int[a.length][b[0].length];
		 //Write code here to multiply 2 matrices and return the resultant matrice
		for(int i =0;i<a.length;i++){
			for(int j =0;j<b.length;j++){
			    c[i][j] = 0;
				for(int k =0;k<c.length;k++){
					c[i][j]=c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		return c;
	}
}