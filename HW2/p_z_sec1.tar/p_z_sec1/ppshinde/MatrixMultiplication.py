# DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self, cnter):
        self.counter = cnter

    def Multiply_matrices(self, a, b):
        self.counter += 1
        # Write code here to multiply 2 matrices and return the resultant matrice
        length = len(a)
        ans = [[0 for i in range(length)] for j in range(length)]
        for i in range(length):
            for j in range(length):
                for k in range(length):
                    ans[i][j] += a[i][k] * b[k][j]
        return(ans)

    def Call_multiplier(self, matrice, power):
        # Write your code here to call Multiply_matrices lg(power) times.
        # This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        # This method should return the final matrice
        size = len(matrice)
        x = [[0 for m in range(size)] for n in range(size)]
        for m in range(size):
            for n in range(size):
                if m == n:
                    x[m][n] = 1

        while power > 0:
            if(power % 2) != 0:
                x = self.Multiply_matrices(matrice, x)
            power = (power/2)
            matrice = self.Multiply_matrices(matrice, matrice)
        return(x)
