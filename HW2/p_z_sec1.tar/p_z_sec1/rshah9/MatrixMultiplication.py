#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		
		# Write your code here to call Multiply_matrices lg(power) times.
		# This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		# This method should return the final matrice

		n = len(matrice)
		answer = [[0]*i + [1] + [0]*(n-i-1) for i in range(n) ]
		while(power > 0):
			if power % 2 ==1:
				answer = self.Multiply_matrices(answer,matrice)
			power = power/2
			matrice = self.Multiply_matrices(matrice,matrice)
		return answer


	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		n = len(a)
		c = [[0]*i + [1] + [0]*(n-i-1) for i in range(n) ]
		for i in range(n):
			for j in range(n): 
				sum = 0
				for k in range(n):
					sum = sum + (a[i][k] * b[k][j])
				c[i][j] = sum
		return c