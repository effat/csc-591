//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice

		int[][] arr = new int[matrix.length][matrix.length];

		//Initializing arr
		for(int i=0; i<matrix.length; i++){
			for(int j=0; j<matrix.length; j++){
				if(i==j)
					temp[i][j] = 1;
			}}
    	   while (power > 1) {
        	   if(power%2 == 0){
			   //Call Multiply_matrices
        		   matrix = MatrixMultiplication.Multiply_matrices(matrix, matrix);
        		   power/=2;
        	   }
        	   else{
        		   arr = MatrixMultiplication.Multiply_matrices(arr, matrix);
        		   matrix = MatrixMultiplication.Multiply_matrices(matrix, matrix);
        		   power = (power-1)/2;
        	   }
		}
    	   matrix = MatrixMultiplication.Multiply_matrices(arr, matrix);
	   //return final matrix
    	   return matrix;
		
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int tempSum =0;
		int row = a.length;
		int[][] matProd= new int[row][row];
		for(int i=0; i<row; i++){
			for(int j=0; j<row; j++){
				matProd[i][j] = 0;
			}
		}
		for(int i=0; i<row; i++){
			for(int j=0; j<row; j++){
				for (int k = 0; k < row; k++) {
					tempSum += (a[i][k]*b[k][j]);
				}
				matProd[i][j] = tempSum;
				tempSum = 0;
			}
		}
		return matProd;
   }
}
