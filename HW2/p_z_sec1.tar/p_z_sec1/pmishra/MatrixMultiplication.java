//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		int[][] temp = new int[matrix.length][matrix.length];
		//Initializing temp as an identity matrix
		for(int i=0; i<matrix.length; i++){
			for(int j=0; j<matrix.length; j++){
				if(i==j)
					temp[i][j] = 1;
			}}
    	   while (power > 1) {
    		   //Check if power is even
        	   if(power%2 == 0){
        		   matrix = MatrixMultiplication.Multiply_matrices(matrix, matrix);
        		   //Divide the power by two
        		   power/=2;
        	   }
        	   //Check if power is odd
        	   else{
        		   temp = MatrixMultiplication.Multiply_matrices(temp, matrix);
        		   matrix = MatrixMultiplication.Multiply_matrices(matrix, matrix);
        		   //First decrement and then divide the power by two
        		   power = (power-1)/2;
        	   }
		}
    	   //Call Multiply_matrices for once to get the product with the odd power cases
    	   matrix = MatrixMultiplication.Multiply_matrices(temp, matrix);
    	   return matrix;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int sum =0;
		//Initialize a new 2D array to store the product of both input arrays
		int[][] c= new int[a.length][a.length];
		for(int i=0; i<a.length; i++){
			for(int j=0; j<b.length; j++){
				c[i][j] = 0;
			}
		}
		for(int i=0; i<a.length; i++){
			for(int j=0; j<a.length; j++){
				for (int j2 = 0; j2 < a.length; j2++) {
					sum += (a[i][j2]*b[j2][j]);
				}
				c[i][j] = sum;
				sum = 0;
			}
		}
		return c;
	}
}