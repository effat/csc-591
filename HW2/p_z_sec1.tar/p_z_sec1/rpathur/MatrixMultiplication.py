#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter
    def Call_multiplier (self,matrice,power):
		result = []
		# declaring identity matrix
		for i in range(0,len(matrice)):
			result.append([0]*len(matrice))
			result[i][i] = 1

		while power>0:
			if power%2 != 0:
				result = self.Multiply_matrices(result, matrice)
				power = power - 1
			matrice = self.Multiply_matrices(matrice, matrice)
			power = power/2
		return result

    def Multiply_matrices(self,a,b):
		self.counter +=1
		result = [] # temporary variable to store the multiplication of the two matrix and returning
		for i in range(0,len(a)):
			result.append([0]*len(a))
		for i in range(0,len(a)):
			for j in range(0,len(a)):
				for k in range(0,len(a)):
					result[i][j] += a[i][k]*b[k][j]
		return result
		#Write code here to multiply 2 matrices and return the resultant matrice



