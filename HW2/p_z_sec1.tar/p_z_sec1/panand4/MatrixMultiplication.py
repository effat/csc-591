#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
import math
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def Call_multiplier(self,matrice,power):
        #Write your code here to call Multiply_matrices lg(power) times.
        #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        #This method should return the final matrice
        lVal = math.log(power, 2)
        size = int(math.ceil(lVal))
        dynamicArray = []
        dynamicArray.append(matrice)
        for i in list(range(size)):
            dynamicArray.append(self.Multiply_matrices(dynamicArray[i], dynamicArray[i]))
        if lVal % 1 == 0:
            return dynamicArray[size]
        n = 0
        rangeList = list(range(len(matrice)))
        res = [[1 if(p==q)else 0 for p in rangeList] for q in rangeList]
        while n < power:
            size -= 1
            cpow = 2**size
            if n+cpow <= power:
                n+=cpow
                res = self.Multiply_matrices(res, dynamicArray[size])
                if n == power:
                    return res

    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        rangeList = list(range(len(a)))
        c = [[0 for p in rangeList] for q in rangeList]
        for i in rangeList:
            for j in rangeList:
                for k in rangeList:
                    c[i][j] += a[i][k] * b[k][j]
        return c
