//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power)
	{

		int rows = matrix.length;
		int cols = matrix[0].length;
		int [][]_final=new int[rows][cols];
		_final=getIdentityMatrix(matrix);

		int [][] temp=new int[rows][cols];
		temp= copyMatrix(matrix);

		if(power>1)
		{
			int n = power;

			while (n > 0)
			{
				if (n % 2 == 0)
				{
					temp = Multiply_matrices(temp, temp);
					n = n / 2;
				}
				else
					{
					   _final = Multiply_matrices(_final, temp);
					   n--;
					}
			}
			return _final;
		}
		else // power = 1
			return temp;

	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;

		 //Write code here to multiply 2 matrices and return the resultant matrice
		int rows = a.length;
		int cols = a[0].length;
		int [][]c=new int[rows][cols];
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				c[i][j]=0;
				for(int k=0;k<rows;k++)
				{
					c[i][j]+=(a[i][k]*b[k][j]);
				}
			}
		}
		return c;
	}

	public static int [][]copyMatrix(int [][]matrix)
	{
		int rows = matrix.length;
		int cols = matrix[0].length;

		int [][] temp=new int[rows][cols];
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				temp[i][j]=matrix[i][j];
			}
		}

		return temp;
	}

	public static int[][]getIdentityMatrix(int [][]matrix)
	{
		int rows = matrix.length;
		int cols = matrix[0].length;
		int [][]_identity=new int[rows][cols];
		for(int i=0;i<rows;i++)
		{
			for(int j=0;j<cols;j++)
			{
				if(i==j)
					_identity[i][j]=1;
				else
					_identity[i][j]=0;

			}
		}
		return _identity;
	}


}