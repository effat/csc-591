//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;
	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		int[][] answer1=matrix;
		int[][] answer=new int[matrix.length][matrix.length];
		for(int i=0;i<answer.length;i++){
			for(int j=0;j<answer.length;j++){
				if(i==j)
					answer[i][j]=1;
				else
					answer[i][j]=0;
			}
		}
		while(power>0){
			if(power%2!=0)
				answer=Multiply_matrices(answer,answer1);
			power=(int) Math.floor(power/2);
			answer1=Multiply_matrices(answer1,answer1);
		}
		
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		
		 //This method should return the final matrice
		return answer;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int[][] product=new int[a.length][a.length];
		 //Write code here to multiply 2 matrices and return the resultant matrice
		for(int i=0;i<a.length;i++){
			for(int j=0;j<a.length;j++){
				product[i][j]=0;
				for(int k=0;k<a.length;k++){
					product[i][j]+=a[i][k]*b[k][j];
				}			
			}
		}
		return product;
	}
}
