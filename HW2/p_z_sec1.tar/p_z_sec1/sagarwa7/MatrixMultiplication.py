#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
import math
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
                #The algorithm works on the similar guideline as part (a)
                #r basically here is the unity/identity matrix
                r = [[1 if x==y else 0 for y in range(len(matrice[0]))] for x in range(len(matrice))]
                while power > 0:
                        if power%2!=0:
                                 r = self.Multiply_matrices(r,matrice)
                        power = math.floor(power/2)
                        matrice = self.Multiply_matrices(matrice,matrice)

		#This method should return the final matrice
		return r
	
	def Multiply_matrices(self,a,b):
		self.counter +=1

		#Declaring resultant matrix as c
		c = [[0 for _ in range(len(b[0]))] for _ in range(len(a))]

		
		#Write code here to multiply 2 matrices and return the resultant matrice
                for i in range(len(a)):
                        for j in range(len(b[0])):
                                for k in range(len(b)):
                                        c[i][j] += a[i][k]*b[k][j]

                return c
                



