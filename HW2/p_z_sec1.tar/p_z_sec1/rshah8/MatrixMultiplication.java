//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
import java.util.*;
import java.io.*;
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		int[][] product=new int[matrix.length][matrix.length];
		int[][] temp=new int[matrix.length][matrix.length];
		for(int i=0;i<matrix.length;i++)
		{
			for (int j=0;j<product.length;j++)
			{
				if(i==j)
					product[i][j]=1;
				else
					product[i][j]=0;
			}
		}
		if (power==1)
			return matrix;
		if (power==0)
			return product;
		while(power>0)
		{
			if(power%2!=0)
				product=Multiply_matrices(product,matrix);
			power=(int)Math.floor(power/2);
			matrix=Multiply_matrices(matrix,matrix);
		}
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		return product;

	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int[][] c=new int[a.length][a.length];
		for(int i=0;i<c.length;i++)
			for(int j=0;j<c.length;j++)
				c[i][j]=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				for(int k=0;k<a.length;k++)
				{
					c[i][j]+=(a[i][k]*b[k][j]);
				}
			}
		 //Write code here to multiply 2 matrices and return the resultant matrice
		}
		return c;
			
	}
}