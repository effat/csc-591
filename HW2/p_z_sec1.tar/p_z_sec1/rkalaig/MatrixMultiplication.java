public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		int size = matrix.length;

		// Initializing an identity matrix result
		int[][] result = new int[size][size];
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size; j++) {
				if(i == j) {
					result[i][j] = 1;
				}
				else {
					result[i][j] = 0;
				}
			}
		}

		if(power == 1) {
			return matrix;
		}

		while(power > 0) {
			if(power % 2 != 0) {
				result = Multiply_matrices(result, matrix);
			}
			power = power / 2;
			matrix = Multiply_matrices(matrix, matrix);
		}
		return result;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int n = a.length;
		int[][] c = new int[n][n];
		for(int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				c[i][j] = 0;
				for(int k = 0; k < n; k++) {
					c[i][j] += a[i][k] * b[k][j];
				}
			}
		}
		return c;
	}
}