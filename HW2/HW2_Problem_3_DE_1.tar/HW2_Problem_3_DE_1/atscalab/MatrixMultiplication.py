#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
import math

class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

		

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #order matrice by column
		order = len(matrice[0])
		#print("order is: " + str(order))
		newmatrice = [[0 for row in range(len(matrice[0]))] for col in range(len(matrice))]
		#identity matrix to have all 1s
		for i in range(0,order):
			for j in range(0,order):
				#print("I is: "  + str(i))
				#print("J is: "  + str(j))
				newmatrice[i][j] = 0# identity matrice
				if i == j:
					newmatrice[i][j] = 1 #1's along the diagonal 
		#print(newmatrice)
		while(power > 0):
			 if(math.floor(power/2)!= 0):
			 	newmatrice = self.Multiply_matrices(newmatrice, matrice)
			 matrice = self.Multiply_matrices(matrice, matrice) 
			 power = math.floor(power/2) 
		return newmatrice
	#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
	#This method should return the final matrice
		
	def Multiply_matrices(self,a,b):
		#self.counter +=1
		rows_a = len(a) 
		columns_a = len(a[0])
		rows_b = len(b)
		columns_b = len(b[0])

	    # Conduct matrix multp. and insert in new matrix c
	    # Dimensions of the new matrix will  be rows_a x columns_b
		c = [[0 for row in range(columns_b)] for col in range(rows_a)]

		#Write code here to multiply 2 matrices and return the resultant matrice
		for i in range(rows_a):
			for j in range(columns_b):
				for k in range(columns_a):
					c[i][j] += a[i][k] * b[k][j]

	    	#C = numpy.matrix(c).reshape(len(a),len(b[0]))	
		return c
