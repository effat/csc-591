        #DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def Call_multiplier(self,matrice,power):
         #Write your code here to call Multiply_matrices lg(power) times.
         #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
         #This method should return the final matrice
                result =[[ 0 for row in range(len(matrice))] for col in range(len(matrice))]
                for i in range(len(matrice)):
                        result [i][i] = 1
                while (power > 0):
                        if (power % 2) ==1 :
                                result = self.Multiply_matrices(result,matrice)
                        power = power >> 1
                        matrice = self.Multiply_matrices(matrice,matrice)
                return result
                        
                        
    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        #initialize the result matrix to zero
        product =[[ 0 for row in range(len(a))] for col in range(len(b))]
        
        for i in range(len(a)):
            for j in range(len(b[0])):
                for k in range(len(b)):
                    product[i][j] += a[i][k] * b[k][j]

        return product


