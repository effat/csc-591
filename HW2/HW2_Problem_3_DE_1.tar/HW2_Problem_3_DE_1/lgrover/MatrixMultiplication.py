#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
                c = [[0]*(len(matrice)) for y in range (len(matrice))]
                for i in range (0, len(matrice)):
                        c[i][i] = 1
                result_temp = matrice
                print result_temp
                while (power!=0):
                        if( power%2 == 1 ):
                                c = MatrixMultiplication.Multiply_matrices(self,c,result_temp);
                        result_temp = MatrixMultiplication.Multiply_matrices(self,result_temp, result_temp)
                        print result_temp
                        power = power/2;
                #c = MatrixMultiplication.Multiply_matrices(self, matrice, matrice)
                return c


	def Multiply_matrices(self,a,b):
		self.counter +=1
                size = len(a)
                l=0
                #c = [[0]* size]* size //makes copies, Dont use
                c = [[0]*(size) for y in range (size)]
                #Write code here to multiply 2 matrices and return the resultant matrice
                for i in range (size):
                        for j in range (size):
                                for k in range (size):
                                        c[i][j] = c[i][j] + (a[i][k]*b[k][j])
                                #print i," ",j," ",c[0][0]
                return c
 