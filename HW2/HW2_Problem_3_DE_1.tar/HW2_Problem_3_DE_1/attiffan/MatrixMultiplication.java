/**
 * 
 * @author Aurora Tiffany-Davis (attiffan)
 * 
 * 9/29/17
 * CSC 505
 * Homework 2
 * Problem 3 (b)
 * 
 * Problem Description:
 * 
 * Program a non-recursive algorithm which computes An, where A is a square matrix with integer coefficients. 
 * You have to achieve this by at most 2lg(n) matrix multiplication steps. 
 * 
 * As you can see in the code framework provided (MatrixMultiplication_framework), MatrixMultiplication.py/java file has 2 methods: 
 * Call_multiplier and Multiply_matrices. 
 * The method Call_multiplier calls the Multiply_matrices method for a given input of A and n. 
 * Multiply_matrices multiplies 2 matrices which are passed to it by Call_multiplier. 
 * Call_multiplier should call Multiply_matrices at most 2lg(n) times for a given value of n. 
 * You can create additional methods if required but do not change the name of existing methods and any existing code - points will be cut if you do. 
 * You can code this in either Java or Python. 
 * 
 * Another file MatrixMultiplicationtest.py/java has been provided which tests your code for various inputs. 
 * You need to test your code on VCL using this file (instructions for VCL setup and test are included in the readme file). 
 * You just have to submit the file MatrixMultiplication.py/java and not the test file. 
 * Your code will be checked on VCL by us automatically using the provided cases, 
 * plus some (unknown) kXk integer matrices that will be raised to the (unknown) power n where 1 <= n <= 100. 
 * To avoid loss of marks please make sure that all provided test cases pass on VCL by using the test file.
 * 
 * You may assume that n is a positive integer for both the subproblems, but do not assume that n is always a power of 2. 
 * (Here, lg := logarithm base 2). 
 * For subpart (b) you may assume that all input matrices will be square matrices and you do not need to check if an input matrix has valid dimensions.
 *
 */

//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	
	// Keep track of how many times Multiply_matrices is called
	public static int counter = 0;

	/** 
	 * Raise a matrix to a power by calling Multiply_matrices repeatedly
	 * 
	 * @param matrix 				The input 2d matrix
	 * @param power					The power to which the input matrix should be raised
	 * @return int[][]				The resultant 2d matrix
	 */
	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice

		// Declare variables
		int [][][] aMemoizedMatrices;
		boolean [] abMatricesToCompute;
		int nMatrixDimension;
		int nIncrementalHalfPowerUp;
		int nIncrementalHalfPowerDown;
		int i;
		// This is a double to make sure that we get the correct ceiling value
		double nDivisor = 2;
		
		// Edge case: power = 1, simply return input matrix back out again
		if (power == 1) {
			return matrix;
		}
		
		else {
			
			/* Will save time by using memoized matrices along the way, so initialize that now
			 * aMemoizedMatrices[0] will hold matrix ^ 1 (already known)
			 * aMemoizedMatrices[1] will hold matrix ^ 2
			 * etc.
			 */
			nMatrixDimension = matrix[0].length;
			aMemoizedMatrices = new int[power][nMatrixDimension][nMatrixDimension];
			aMemoizedMatrices[0] = matrix;
			
			// See which matrices we will need to compute along the way
			abMatricesToCompute = getMatricesToCompute(power);
			
			/* Memoize the matrices up to the largest one needed for the final multiplication
			 * Start with small powers so that large powers will already have the matrices they need to work with
			 */
			for (i = 2; i <= power; i++) {
				
				// Do we need this power to compute the final matrix?
				if (abMatricesToCompute[i-1] == true) {
					
					// This  matrix will be ~ matrix ^ half-power * matrix ^ half-power
					nIncrementalHalfPowerUp = (int) Math.ceil(i/nDivisor);
					nIncrementalHalfPowerDown = (int) Math.floor(i/nDivisor);

					// Compute 
					aMemoizedMatrices[i-1] = 
							Multiply_matrices(aMemoizedMatrices[nIncrementalHalfPowerUp-1], aMemoizedMatrices[nIncrementalHalfPowerDown-1]);
					
				}
				
			}
			
			// We should have all the necessary matrices memoized including the final one matrix^power
			return aMemoizedMatrices[power-1];
			
		}
		
	}

	/** 
	 * Multiply two matrices together
	 * 
	 * @param a 					The first 2d matrix
	 * @param b						The second 2d matrix
	 * @return aMultiplied			The resultant 2d matrix
	 */
	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		
		// Declare variables
		int [][] aMultiplied;
		int nMatrixDimension;
		int i, j, k;
		int sum;
		
		// Multiply the matrices
		nMatrixDimension = a.length;
		aMultiplied = new int[nMatrixDimension][nMatrixDimension];
		for (i = 0; i < nMatrixDimension; i++) {
			for (j = 0; j < nMatrixDimension; j++) {
				sum = 0;
				for (k = 0; k < nMatrixDimension; k++) {
					sum += a[k][j] * b[i][k];
				}
				aMultiplied[i][j] = sum;
			}
		}
		
		// Return
		return aMultiplied;
			
	}
	
	/** 
	 * Get a boolean array of values indicating which matrices to compute
	 * to be able to compute A^power
	 * 
	 * @param power 				The power to which we desire to raise a matrix
	 * @return abMatricesToCompute	boolean array of values indicating which matrices to compute
	 * 								to be able to compute A^power
	 * 								abMatricesToCompute[0] true means we need A^1
	 * 								abMatricesToCompute[1] true means we need A^2
	 * 								etc.
	 */
	private static boolean[] getMatricesToCompute (int power) {
		
		// Declare variables
		boolean [] abMatricesToCompute;
		int nHalfPowerUp;
		int nHalfPowerDown;
		int i;
		
		// This is a double to make sure that we get the correct ceiling value
		double nDivisor = 2;
		
		// Start out assuming we don't have to compute anything and flip to true only as we know we have to
		abMatricesToCompute = new boolean[power];
		for (i = 0; i < power; i++) {
			abMatricesToCompute[i] = false;
		}
		
		// Figure it out
		abMatricesToCompute[power-1] = true;
		nHalfPowerUp = (int) Math.ceil(power/nDivisor);
		nHalfPowerDown = (int) Math.floor(power/nDivisor);
		
		// For a power of 1, we already know we don't need to compute, that's the input matrix
		while (nHalfPowerUp > 1 || nHalfPowerDown > 1) {
			
			// We know we need to compute these in order to get the answer IF not zero
			if (nHalfPowerUp > 1) {
				abMatricesToCompute[nHalfPowerUp-1] = true;
			}
			if (nHalfPowerDown > 1) {
				abMatricesToCompute[nHalfPowerDown-1] = true;
			}
			
			// Set up the next ones to try
			nHalfPowerUp = (int) Math.ceil(nHalfPowerUp/nDivisor);
			nHalfPowerDown = (int) Math.floor(nHalfPowerDown/nDivisor);
			
		}
		
		// Return
		return abMatricesToCompute;
		
	}
	
	// USED FOR DEBUG PRIOR TO RUNNING JUNIT TESTS (can be ignored)
	/*
	public static void print2dMatrix(int[][] matrix) {
		System.out.println("");
		int i,j,nDimension;
		nDimension = matrix[0].length;
		for (i = 0; i < nDimension; i++) {
			for (j = 0; j < nDimension; j++) {
				System.out.println("matrix [" + i + "][" + j + "]: " + matrix[i][j]);
			}
		}
		System.out.println("");
	}
	*/
	
	// USED FOR DEBUG PRIOR TO RUNNING JUNIT TESTS (can be ignored)
	/*
	public static void main(String[] args) {

		int power = 10;
		
		System.out.println("");
		System.out.println("TEST getMatricesToCompute");
		System.out.println("");
		
		System.out.println("");
		System.out.println("power: " + power);
		System.out.println("");
		
		boolean [] abMatricesToCompute = getMatricesToCompute(power);
		
		System.out.println("");
		int i;
		for (i = 0; i < power; i++) {
			System.out.println("abMatricesToCompute[" + i + "]: " + abMatricesToCompute[i]);
		}
		System.out.println("");
		
		System.out.println("");
		System.out.println("TEST Call_multiplier");
		System.out.println("");
		
		int [][] matrix = new int[][]{
		    {1,2},
		    {2,1}
		};
		matrix = Call_multiplier(matrix,power);
		print2dMatrix(matrix);
		
		System.out.println("");
		System.out.println("TEST counter");
		System.out.println("");
		
		System.out.println("");
		System.out.println("counter: " + counter);
		System.out.println("");
			
	}
	*/
	
}