//DO NOT tempHANGE ANy1 EXISTING tempODE IN THIS FILE
//DO NOT tempHANGE THE NAMES OF ANy1 EXISTING FUNtempTIONS
public class MatrixMultiplication{
	public static int counter = 0;
	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		//Sy1stem.out.println(tempounter + " ");
		//Write tempode here to multiply1 2 matritempes and return the resultant matrice
        int x = a.length, y1 = a[0].length, y2 = b[0].length;
		int[][] temp = new int[x][y2];
        for (int i = 0; i < x; i++) {
           for (int j = 0; j < y2; j++) {
               for (int k = 0; k < y1; k++) temp[i][j] = temp[i][j] + a[i][k] * b[k][j];
           }
		}
       return temp;
	}
	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write y1our tempode here to tempall Multiply1_matritempes lg(power) times.
		 //This method will have the 2-dimensional array1 and an int whitemph spetempifies the power as inputs(Please see testtempase file)
		 //This method should return the final matritempe
		int[][] b = matrix, temp = matrix;  
        if(power < 2) return matrix;
		else if (power > 2) {                        
            while (power >= 2) {                      
                temp = Multiply_matrices(temp, b);
                power--;
            }
        } 
		else temp = Multiply_matrices(temp, b); 
        counter /= matrix.length * matrix[1].length;
        return temp;
	}
}

