//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
import java.util.ArrayList;
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		int w = matrix.length;
		int[][] result = new int[w][w];
		int[][] tmp = new int[w][w];
		int index = 1;
		for(int i=0; i<w; i++){
			for(int j=0; j<w; j++){
				if(i==j)
					result[i][j] = 1;
				else
					result[i][j] = 0;
				
				tmp[i][j] = matrix[i][j];
			}
		}
		
		
		ArrayList<Integer> powerlist = new ArrayList<Integer>();
		int power_tmp = power;
		while(power_tmp>0){
			int x = 1;
			int power_index = 0;
			while(x*2<=power_tmp){
				x = x*2;
				power_index = power_index+1;
			}
			powerlist.add(power_index);
			power_tmp -= x;
		}
		for(int i=powerlist.size()-1; i>=0; i--){
			int number = 0;
			
			if(i==powerlist.size()-1)
				number = powerlist.get(i);
			else
				number = powerlist.get(i)-powerlist.get(i+1);
	
			for(int j=0; j<number; j++){
				tmp=Multiply_matrices(tmp, tmp);
			}
			result = Multiply_matrices(result, tmp);
		}
		return result;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int w = a.length;
		int[][] result = new int[w][w];
		for(int i=0; i<a.length; i++){
			for(int j=0; j<a.length; j++){
				int tmp = 0;
				for(int k=0; k<a.length; k++){
					tmp = tmp + a[i][k]*b[k][j];
				}
				result[i][j] = tmp;
			}
		}
		return result;
	}
}