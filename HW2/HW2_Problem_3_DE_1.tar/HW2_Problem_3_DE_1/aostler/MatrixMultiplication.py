#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
from math import *
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def Call_multiplier(self,matrice,power):
        #Write your code here to call Multiply_matrices lg(power) times.
        #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        #This method should return the final matrice
        A=[matrice]
        pwr=1
        lgn = int(log(power,2))
        for i in range(lgn):
            pwr = pwr*2
            A.append(self.Multiply_matrices(A[i],A[i]))
        answer= A[lgn]
        power=power-pwr
        if pwr == power:
            return answer
        else:
            for i in range(lgn,0,-1):
                pwr=pwr/2
                if power-pwr>=0:
                    answer=self.Multiply_matrices(answer,A[i-1])
                    power=power-pwr
        return answer


    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        result= []
        for i in range(len(a[0])):
            inner_result=[]
            for j in range(len(a[0])):
                index_sum=0
                for k in range(len(b[0])):
                     index_sum +=a[i][k]*b[k][j]
                inner_result.append(index_sum)
            result.append(inner_result)
        return result
