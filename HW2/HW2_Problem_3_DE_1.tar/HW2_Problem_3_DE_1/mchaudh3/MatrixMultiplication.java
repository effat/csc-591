//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

/*	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 int len_row = matrix.length;
//		 System.out.print("PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP");
		 int c[][] = new int [len_row][len_row];
		 double d = (Math.log(power)/Math.log(2));
		 double p = 2*(Math.ceil(d));
//		 System.out.print(p);
		 if(p>0)
		 c = Multiply_matrices(matrix, matrix);
		 while(p > 0){
//			 System.out.print("--------------------------Inside while-----------------------------");
			 c = Multiply_matrices(c, matrix);
//			 System.out.print(" p is " + p);
			 p--;
//			 System.out.print("Decremented p is " + p);
		 }
		/* for(int x=0; x< len_row; x++){
			 for(int y=0; y < len_row; y++){
				 System.out.print("Result Matrix is: " + c[x][y]);
			 }
		 }
		 return c;
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
	} */

	public static int[][] Call_multiplier(int[][] matrix,int power){
		int len_row = matrix.length;
		int c[][] = new int [len_row][len_row];
//		int p = power;
		for(int x=0; x< len_row; x++){
			 for(int y=0; y < len_row; y++){
				 if (x == y)
				 c[x][y] = 1;
				else 
					c[x][y] = 0;
			 }
		 }
		if(power == 0)
			return c;
		else{
			 while(power > 0){
			 if (power%2 != 0)
				c = Multiply_matrices(c, matrix);
				power = (int) Math.floor(power/2);       
				matrix = Multiply_matrices(matrix, matrix);
			 }
		return c;
		}
	} 
	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		int len_row = a.length;
		int len_col = a[0].length;
		int c[][] = new int [len_row][len_col];
//		System.out.print("-----------------Multiply_matrices called----------");
		 //Write code here to multiply 2 matrices and return the resultant matrice
		for (int i=0; i<len_row; i++){
			for(int j=0; j<len_col; j++){
				c[i][j]=0;
				for(int k=0; k<len_col; k++)
					c[i][j] += a[i][k]*b[k][j];
			}
		}
		for(int x=0; x< len_row; x++){
			 for(int y=0; y < len_row; y++){
				 System.out.print("Result Matrix is: " + c[x][y]);
				 System.out.println();
			 }
		 }
		 System.out.print("counter is " + counter);
	return c;
	}
}