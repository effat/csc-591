#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Multiply_matrices(self,a,b):	
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice

		Matrix = [[0]*(len(a)) for i in range(len(a))]
		for i in range(0, len(a)) :
			for j in range(0,len(a)) :
				Matrix[i][j] = 0
				for k in range(0,len(a)) :
					Matrix[i][j] = Matrix[i][j] + a[i][k]*b[k][j]
		return Matrix



	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		A = matrice
		n = power
		Array = []

		while n > 1:
			if n%2 == 0 :
				n = n/2
				Array.append(0)
			else :
				n = n - 1
				Array.append(1)
		
		for j in reversed(Array):
			if j == 0 :
				A = self.Multiply_matrices(A, A)
			else :
				A = self.Multiply_matrices(A, matrice)
		return A


		
