//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		int[][] sol = init(matrix.length,matrix[0].length);
		while(power!=0){
			if((power&1)==1){
				sol = Multiply_matrices(sol, matrix);
			}
			power = power>> 1;
			matrix = Multiply_matrices(matrix, matrix );
		}
		return sol;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int[][] sol = new int[a.length][a[0].length];
		for (int rowa =0;rowa<a.length ;rowa++) {
			for (int cola= 0;cola<a[0].length ;cola++ ) {
				for (int colb = 0; colb<b[0].length ; colb++ ) {
					sol[rowa][cola] +=a[rowa][colb]*b[colb][cola];
				}
			}
		}
		return sol;
			
	}
	public static int[][] init(int row, int col){
		int[][] ans = new int[row][col];
		for(int i=0;i<row;i++){
			for (int j=0;j<col;j++ ) {
				if(i==j){
					ans[i][j] = 1;
				}else{
					ans[i][j] = 0;
				}
				
			}
		}
		return ans;
	}
}

