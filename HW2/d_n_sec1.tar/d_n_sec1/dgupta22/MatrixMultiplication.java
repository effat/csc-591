//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice

		int len = matrix.length; //stores length of the input matrix
		int n = power;
		int i,j;  //variables for running loops
		
		int extra[][] = new int[len][len]; //variable to store extra component in a step
		int factor[][] = new int[len][len]; //variable to store factor of multiplication
		int result[][] = new int[len][len]; //variable to calculate result
		factor = matrix;

	//initializing extra as an Identity matrix
		for(i=0;i<len;i++)
			for(j=0; j<len; j++)
					if(i == j)
						extra[i][j] = 1;
				

		while(n>1)
		{
			//if n is odd then store the extra component in extra matrix
			if(n%2 == 1)
				extra = Multiply_matrices(extra, factor);

			factor = Multiply_matrices(factor, factor);
			n = n/2;	
		}

		result = Multiply_matrices(extra, factor);
		
		return result;		

	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice

		int len = a.length;
		int i,j,k;
		int temp[][] = new int[len][len];
		int sum = 0;

		for(i=0;i<len;i++)
			for(j=0; j<len; j++)
						temp[i][j] = 0;

		for(i=0;i<len;i++)
			for(j=0; j<len; j++)
				for(k=0; k<len; k++)
					temp[i][j] += a[i][k] * b[k][j];

	
		return temp;
			
	}
}
