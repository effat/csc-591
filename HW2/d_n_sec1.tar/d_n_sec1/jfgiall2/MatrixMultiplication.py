#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
import math

class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
			 #Write your code here to call Multiply_matrices lg(power) times.
			 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
			 #This method should return the final matrice
			result = []
			while (power != 0):
				if (power % 2 != 0):
					result = self.Multiply_matrices(result,matrice)
					power = power - 1
				power = power / 2
				if (power > 0):
					matrice = self.Multiply_matrices(matrice,matrice)
			print(result)
			return result

	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		if (a != [] and b !=[]):
			matrice = self.initEmptyMatrix(a)
			for x in range(len(a)):
				for y in range(len(b[0])):
					for z in range(len(b)):
						matrice[x][y] += a[x][z] * b[z][y] 
		else:
			matrice = b
		return matrice

	def initEmptyMatrix(self,matrice):
		DictOfArrays = dict()
		result = []
		for z in range(0,len(matrice)):
			DictOfArrays[z] = []
		# print(DictOfArrays.keys())
		# print(DictOfArrays.values())
		for keys in DictOfArrays:
			array = DictOfArrays[keys]
			for y in range(len(matrice)):
				array.append(0)
			result.append(array)
		return result


