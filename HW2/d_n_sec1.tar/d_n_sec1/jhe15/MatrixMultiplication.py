#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter
	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		#This method should return the final matrice
		res = [[0 for col in range(len(matrice))] for row in range(len(matrice))]
		for i in range(len(matrice)):
			res[i][i] = 1
		while power:
			if power == 1:
				return self.Multiply_matrices(res, matrice)
			if power & 1:
				res = self.Multiply_matrices(res, matrice)
			if (power/2) > 0:
				matrice = self.Multiply_matrices(matrice, matrice)
			power /= 2
		return res

	def Multiply_matrices(self,X,Y):
		#Write code here to multiply 2 matrices and return the resultant matrice
		self.counter +=1
		return [[sum(a*b for a,b in zip(X_row,Y_col)) for Y_col in zip(*Y)] for X_row in X]
