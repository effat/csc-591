#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def Call_multiplier(self,matrice,power):
         #Write your code here to call Multiply_matrices lg(power) times.
         #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
         #This method should return the final matrice
         reminder = [[1 if x == y else 0 for x in range(len(matrice[0]))] for y in range(len(matrice))]
         while power > 1 :
             if power % 2 != 0:
                 reminder = self.Multiply_matrices(reminder, matrice)

             matrice = self.Multiply_matrices(matrice, matrice)
             power = power / 2

         matrice = self.Multiply_matrices(matrice, reminder)

         return matrice


    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        c = [[0 for x in range(len(a[0]))] for y in range(len(b))]

        for i in range(len(a)):
            for j in xrange(len((b[0]))):
                for k in range(len(a)):
                    c[i][j] = c[i][j] + (a[i][k]*b[k][j])

        return c
