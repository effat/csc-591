#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		matrice1= [[0 for i in range(len(matrice))] for j in range(len(matrice))]
		p=power
		turns=1
		while (1):
			m=p%2
			p=p/2
			
			if m==1 and turns==1:
				matrice1=matrice
				turns=0
				if p==0:
					break
				else:
					matrice=self.Multiply_matrices(matrice,matrice)
					continue
			if m==1:
				matrice=self.Multiply_matrices(matrice1,matrice)
			if p==0:
				break

			matrice=self.Multiply_matrices(matrice,matrice)

		return matrice

		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		matrix = [[0 for i in range(len(a))] for j in range(len(b))] 
		for i in range(len(a)):
			for j in range(len(a)):
				for k in range(len(a)):
					matrix[i][j] += a[i][k] * b[k][j]

		#for x in matrix:
			#print(x)
		return matrix

		#Write code here to multiply 2 matrices and return the resultant matrice
