'''
name: Isaac Polinsky
email: ipolins@ncsu.edu
course: CSC 505 - Fall 2017
homework: Problem Set 2 - Question 3.b 
date: 9/29/2017
'''

class MatrixMultiplication:
    def __init__(self, cnter):
        self.counter = cnter


    def Call_multiplier(self, matrice, power):
        '''
        This function takes an NxN matrix, represented as a list of lists and raises it to
            the specified power
        Input: An NxN matrix, matrice, and an non-negative integer, power
        Output: An NxN matrix which is the solution of raising the input matrix to the specified power
        '''

        # Get the size of the matrix
        N = len(matrice)
        
        # If the 0th power, return the identity matrix of size N
        if power == 0:
            return self.identity(N)
        else:
            # Set the tail matrix to the identity matrix (i.e. tail = 1)
            tail = self.identity(N)

            # Loop until the end of square exponentiation
            while power > 1:
                # If the power is even simply raise the squared base to the power divided by 2
                if power % 2 == 0:
                    matrice = self.Multiply_matrices(matrice, matrice)
                    power = power / 2
                else:
                    # Calculate the new "tail" after taking out a power
                    tail = self.Multiply_matrices(tail, matrice)

                    # Square the base
                    matrice = self.Multiply_matrices(matrice, matrice)
                    
                    # Take out 1 to make it even (the tail) and then divide by 2
                    power = (power - 1) / 2

            # Combine the tail and the matrix from squared exponentiation
            return self.Multiply_matrices(tail, matrice)
        

    def Multiply_matrices(self, A, B):
        '''
        This function takes two NxN matrices and returns their product
        Input: two NxN matrices, A and B, represented as a linked list of linked lists
        Output: an NxN matrix which is the product of the input matrices
        '''
        self.counter += 1
    
        # Get the size of the matrices
        N = len(A)

        # Initialize the output matrix
        C = []

        # Loop through all rows
        for i in range(N):
            # Add a new empty list for that row
            C.append([])

            # Loop through N columns
            for j in range(N):
                # Initialize that entry to 0
                C[i].append(0)

                # Multiply the kth element in the ith row with the kth element in the jth row
                #   and sum up these values and store in C[i][j]
                for k in range(N):
                    C[i][j] = A[i][k] * B[k][j] + C[i][j]

        # Return the product of A and B
        return C


    def identity(self, N):
        '''
        This function takes a size parameter, N, and returns an NxN identity matrix.
        Input: N, integer > 0
        Output: An NxN identity matrix (a matrix where the diagonal are 1 and all other
                 entries are 0)
        '''
         
        # Initialize the identity matrix as an empty list
        identity = []
        
        # Loop through N rows
        for i in range(N):
            # Add a new empty list for that row
            identity.append([])

            # Loop through N columns
            for j in range(N):

                # If the current position is a diagonal insert 1, otherwise 0
                if i == j:
                    identity[i].append(1)
                else:
                    identity[i].append(0)
        
        # Return the identity matrix
        return identity