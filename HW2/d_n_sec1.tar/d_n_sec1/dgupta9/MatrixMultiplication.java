//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice

		int rows = matrix.length;
		int columns = matrix[0].length;
		int [][] res = new int[rows][columns];
		int [][] temp = new int[rows][columns];


		for(int i=0;i<rows;i++){
			for(int j=0;j<columns;j++){
				int defVal = 0;
				if(i==j)
					defVal = 1;
				res[i][j] = defVal;
			}
		}

		while (power > 0)
    	{
        	if (power%2==1)
            	res = Multiply_matrices(res,matrix);

        	power = power/2;
       		matrix = Multiply_matrices(matrix,matrix);
    	}
		return res;
	}



	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int rows = a.length;
		int columns = a[0].length;
		int [][] res = new int[rows][columns];
		for(int i=0;i<rows;i++){
			for(int j=0;j<rows;j++){
				int sum=0;
				for(int k=0;k<rows;k++){
					sum += ( a[i][k] * b[k][j]);
				}
				res[i][j]=sum;
			}
		}
		return res;
	}
}