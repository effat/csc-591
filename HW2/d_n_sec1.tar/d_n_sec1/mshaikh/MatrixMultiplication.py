
#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		if (power ==1):
			return matrice;												# if power=1 return matrice as it is
		else:
			t=[[1 if i==j else 0 for j in range(len(matrice[0]))]for i in range(len(matrice))] #Creates an identity matrix
			while (power>1):
				if (power%2==0):  										# When power is even
					matrice= self.Multiply_matrices(matrice,matrice)	# Multiply matrix with itself and store the result in matrice
					power = (power)/2									# decrement the power
				else:
					t= self.Multiply_matrices(t,matrice)				# Store the matrice value in t, will be useful if t is odd
					matrice=self.Multiply_matrices(matrice,matrice)		# Multiply matrix with itself and store the result in matrice
					power = (power-1)/2									# decrement the power
			return self.Multiply_matrices(t,matrice)					# return the matrice with power n

	def Multiply_matrices(self,a,b):									# Helper code to multiply 2 matrices
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		a_row = len(a)
		a_column = len(a[0])
		b_row = len(b)
		b_column = len(b[0])
		c= [[0 for row in range(b_column)]for col in range(a_row)]		# Create a zero matrix
		for x in range(a_row):
			for y in range(b_column):
				for z in range(b_row):
					c[x][y] += a[x][z]*b[z][y]							# c= c+a*b	
		return c;

# def main():
# 	matrice = [[1,2,3],[3,1,2],[2,3,1]]
# 	power = 8
# 	temp = MatrixMultiplication(0)
# 	temp1 = temp.Call_multiplier(matrice,power)
# 	print (temp1)


# if __name__=='__main__':
# 	main()