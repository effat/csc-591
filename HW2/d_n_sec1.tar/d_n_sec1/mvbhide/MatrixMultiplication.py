#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
                a='{0:b}'.format(power)
                n = len(matrice)
                num = [[0 for i in xrange(n)] for j in xrange(n)]
                for i in xrange(n):
                    for j in xrange(n):
                        num[i][j]=matrice[i][j]
                
                prod = [0]*len(a)
                res = self.identity(n)
                for j in xrange(len(a)-2,-1,-1):
                        matrice = self.Multiply_matrices(matrice,matrice)
                        prod[j] = matrice
                if (a[len(a)-1]=='1'):
                        res = num
                for i in xrange(len(a)-2,-1,-1):
                        if (a[i]=='1'):
                                res = self.Multiply_matrices(prod[i],res)
                print res
                return res
                
        def identity(self,n):
            m=[[0 for x in range(n)] for y in range(n)]
            for i in range(0,n):
                m[i][i] = 1
            return m

		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		
		#Write code here to multiply 2 matrices and return the resultant matrice
	
                n = len(a)
                c = [[0 for i in xrange(n)] for j in xrange(n)]

                for i in xrange(n):
                        for k in xrange(n):
                                for j in xrange(n):
                                    c[i][j] += a[i][k] * b[k][j]
                return c
