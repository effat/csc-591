#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
import math 
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice

		 # Assume every matrix is square matrix - Get number of rows and columns
		 rows = len(matrice)
		 cols = len(matrice[0])

		 # Generate Identity matrix with the dimensions from the input matrix i.e., 1's in diagonal, 0 elsewhere
		 result = [[0 for row in range(rows)] for col in range(cols)]
		 for i in range(rows):
			for j in range(cols):
				if(i==j):
					result[i][j]=1
		 # Check if power is 1. If so, return the same matrice without calling Multiply_matrices.
		 if(power==1):
		 	return matrice
		 else:
			 # Loop until power becomes 0
			 while(power>0):
		 		# If power is odd
		 		if(power%2!=0):
		 			result = self.Multiply_matrices(result,matrice)
		 		# Take a floor value of power/2 and assign it to 'power'
		 		power=math.floor(power/2)
		 		matrice = self.Multiply_matrices(matrice,matrice)
		 	 # result has the matrix to be output
		 	 return result
		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice

		# Get rows and columns of each matrix
		rowsa = len(a)
		colsa = len(a[0])
		rowsb = len(b)
		colsb = len(b[0])

		# Check if the matrices can be multiplied
		if(colsa!=rowsb):
			raise ValueError("Columns of First Matrix NOT EQUAL TO Rows of Second Matrix. Cannot multiply!! ")
		else:
			product = [[0 for row in range(rowsa)] for col in range(colsb)]
			# Multiply matrices
			for i in range(rowsa):
				for j in range(colsb):
					for k in range(rowsb):
						product[i][j]+=a[i][k]*b[k][j]
			return product
