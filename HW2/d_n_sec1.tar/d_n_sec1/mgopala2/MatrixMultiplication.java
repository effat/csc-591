//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	/**
	 * This method will compute the a^n where a is a square matrix
	 * @param matrix this is a square matrix
	 * @param power to which the matrix should be raised to
	 * @return the final value of matrix after computing a^n.
	 */
	public static int[][] Call_multiplier(int[][] matrix,int power){
		int length_to_Compute_Temp_Matrix = matrix.length;
		int[][] tempMatrix = new int[length_to_Compute_Temp_Matrix][length_to_Compute_Temp_Matrix];/*Initializing the identity matrix*/
		
		//Below method constructs an identity matrix which will be used in later part of computation
		for(int i=0; i<length_to_Compute_Temp_Matrix;i++)
		{
			for(int j=0;j<length_to_Compute_Temp_Matrix;j++)
			{
				if(i==j)
				{
					tempMatrix[i][j]=1;
				}
			}
		}
		if(power == 1)
		{
			//When the value of power is 1 then we should return the matrix 
			return matrix;
		}
		while (power >1)
		{
			if(power%2 == 0)/*Checking whether the value of power is even */
			{
				matrix = Multiply_matrices(matrix, matrix);
				power = power/2;
			}
			else
			{
				/*When value of power is odd then the below actions takes place*/
				tempMatrix = Multiply_matrices(tempMatrix, matrix);
				matrix = Multiply_matrices(matrix, matrix);
				power=(int) Math.floor(power/2);
			}
		}
		matrix = Multiply_matrices(matrix, tempMatrix);
		return matrix;
	}

	/**
	 * This method will multiply any two matrices given to it
	 * @param a this is the first matrix to be multiplied
	 * @param b this is the second matrix to be multiplied to
	 * @return the final multiplied matrix result
	 */
	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;/*This counter will check how many times this method of multiplying os matrices is called, 
		this should be 2* log(n) times according to the requirement*/
		int[][] resultantMatrix = new int[a.length][a.length];
		
		//This below loop computes the multiplication of two matrices,
		//by going through the indexes of matrix a and matrix b and putting the result in resultant matrix
		for(int i=0; i<a[0].length; i++)
		{
			for(int j=0;j<b[0].length; j++ )
			{
				for(int k=0;k<a[0].length;k++)
				{
					resultantMatrix[i][j] = (a[i][k]*b[k][j])+(resultantMatrix[i][j]);
				}
			}
		}
		return resultantMatrix;
	}
}