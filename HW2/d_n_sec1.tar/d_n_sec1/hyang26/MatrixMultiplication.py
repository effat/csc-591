#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		result = [[0] * len(b[0]) for i in range(len(a))]
		for i in range(len(a)):
			for j in range(len(b[0])):
				for k in range(len(b)):
					result[i][j] += a[i][k] * b[k][j]
		return result

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		if (not(power)):
			return 1
		New_matrice = matrice
		result = [[0] * len(matrice[0]) for i in range(len(matrice))]
		for j in range(len(result)):
			for k in range(len(result)):
				if (j == k):
					result[j][k] = 1
		while(power):
			if (power%2):
				result = self.Multiply_matrices(result,New_matrice)
			New_matrice  = self.Multiply_matrices(New_matrice,New_matrice)
			power /= 2
		return result




