import math

#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter
		self.powers = []

	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		#This method should return the final matrice

		self.powers += [matrice]

		first_time = True
		while power >= 1:
			if first_time:
				first_time = False
				for k in range(int(math.log(power, 2))):
					matrice = self.Multiply_matrices(matrice, matrice)
					self.powers += [matrice]
			else:
				p = int(math.log(power, 2))
				matrice = self.Multiply_matrices(self.powers[p], matrice)

			power -= int(math.pow(2, int(math.log(power, 2))))

		return matrice
		
	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		n = len(a)

		# initializing an empty matrix of size n*n
		c = [[0 for _ in xrange(n)] for _ in xrange(n)]

		# multiplying the matrix a with b and storing the result in c
		for i in xrange(n):
			for j in xrange(n):
				for k in xrange(n):
					c[i][j] += a[i][k] * b[k][j]
		return c

