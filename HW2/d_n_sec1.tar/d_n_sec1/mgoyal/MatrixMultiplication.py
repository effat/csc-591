#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		#Write your code here to call Multiply_matrices lg(power) times.
		#This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		#This method should return the final matrice
		res = []
		for i in range(0,len(matrice)):
			r = []
			for j in range(0,len(matrice[0])):
				if j == i:
					r.append(1)
				else:
					r.append(0)
			res.append(r)
		p = power
		while p>0:
			if p%2 != 0:
				res = self.Multiply_matrices(res,matrice)
			p = p/2
			matrice = self.Multiply_matrices(matrice,matrice)
		return res

	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		ret_mat = []
		for i in range(0,len(a)):
			r = []
			for j in range(0,len(b)):
				r.append(0)
			ret_mat.append(r)
		for i in range(0,len(a)):
			for j in range(0,len(b[0])):
				for k in range(0,len(b)):
					ret_mat[i][j] += a[i][k]*b[k][j]
		return ret_mat	


