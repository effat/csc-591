#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		size = len(matrice)
		result = []
		for row in range(size):
			result.append([])
			for column in range(size):
				if row == column:
					result[row].append(1)
				else:
					result[row].append(0)
		while power > 0:
			if power%2 != 0:
				result = self.Multiply_matrices(matrice,result)
			matrice = self.Multiply_matrices(matrice,matrice)
			power = power // 2
		return result

	def Multiply_matrices(self,a,b):
		self.counter += 1
		size = len(a)
		answer = []
		for row in range(size):
			answer.append([])
			for column in range(size):
				answer[row].append(0)
		for i in range(size):
			for j in range(size):
				for k in range(size):
					answer[i][j] += a[i][k] * b[k][j]
		return answer