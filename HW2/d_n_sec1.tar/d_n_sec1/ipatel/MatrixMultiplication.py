#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice
		 def identity(m):
			 result = []
			 for i in range(m):
				 row = [0] * m
				 row[i] = 1
				 result.append(row)
			 return result

		 A = identity(len(matrice)) 	# Initializing the identity matrix

		 if (power == 1):
			 return matrice; 			# For power of 1 returning the same matrix
		 else:
			 while (power > 1):
				 if (power % 2 == 1):	# For odd powers
					 A = self.Multiply_matrices(A, matrice)
					 matrice = self.Multiply_matrices(matrice, matrice)
					 power = (power - 1) / 2
				 else:					#For even powers
					 matrice = self.Multiply_matrices(matrice, matrice)
					 power = power / 2
			 return self.Multiply_matrices(A, matrice)

	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice
		rowA = len(a)
		colA = len(a[0])
		rowB = len(b)
		colB = len(b[0])
		Answer = [[0 for row in range(colB)] for column in range(rowA)]
		for i in range(rowA):			#iterate over rows of 1st matrix
			for j in range(colB):		#iterate over columns of 2nd matrix
				for k in range(rowB):	#iterating over (columns of 1st matrix OR rows of 2nd matrix)[condition for matrix multiplication]
					Answer[i][j] += a[i][k] * b[k][j]
		return Answer
	


