//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS

import java.io.*;

public class MatrixMultiplication{
	public static int counter = 0;

    static int[][] makeIdentity(int[][] matrix, int m, int n){
        for(int i = 0; i < m; i++){
            matrix[i][i] = 1;
        }
        return matrix;
    }

    static int[][] makeZeroes(int[][] matrix, int m, int n){
       for(int i = 0; i < m; i++){
            for(int j = 0; j <n; j++){
                matrix[i][j] = 0;
            }
       }
        return matrix; 
    }

    static void printMatrix(int[][] matrix, int m, int n){
        System.out.println("**");
        for(int i = 0; i < m; i++){
            for(int j = 0; j < n; j++){
                System.out.print(String.valueOf(matrix[i][j]) + " ");
            }
            System.out.println();
        }
        System.out.println("**");
    }

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
        int m = matrix.length,
            n = matrix[0].length;
         
        int[][] eMatrix, 
                result = matrix,
                identity = new int[m][n];
        
        identity =  makeIdentity(identity, m, n);
        result = identity;
        
        if( power == 0 ) return identity;
        else if( power == 1 ) return matrix;  
        
        int num_iterations = power;
        while( num_iterations > 0 ){
            if( (num_iterations % 2) == 1){
                result = Multiply_matrices(matrix, result);
            }
            
            matrix = Multiply_matrices(matrix, matrix);
            num_iterations >>=1 ;
            
        }
        //printMatrix(result, m, n);
        return result;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){

		counter+=1;
        int m = a.length,
            n = a[0].length;

        int[][] result = makeZeroes(new int[m][n], m, n);
		//Write code here to multiply 2 matrices and return the resultant matrice
        // m == n. Assumption in problem
        for(int i = 0; i < m; i++){
            for(int j = 0; j <m; j++){
                for(int k = 0; k < m; k++){
                    result[i][j] += a[i][k]* b[k][j];
                }
            }
        }
        return result;			
	}
}
