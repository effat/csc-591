//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrices
		
		int log_n=0, i, n2 = power;
		int[][] res = null;
		
		while( n2 > 0 ) {
			log_n = log_n + 1;
			n2 = n2 / 2;
		}
		
		for (i = log_n-1 ; i >= 0; i--) {
			if( (( power>>i ) & (0x1)) == 1)  {
				if(res != null) {
					res = Multiply_matrices(res, res);
					res = Multiply_matrices(res, matrix);
				}
				else {
					res = matrix;
				}
			}
			else {
				if( res!= null)
					res = Multiply_matrices(res, res);
			}
		}
		
		return res;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		int n = a.length;
		
		int result[][] = new int[n][n];
		
		for (int i=0;i<n;i++) {
			for (int j=0;j<n;j++) {
				for(int k = 0; k<n; k++) {
					result[i][j] += a[i][k]*b[k][j];
				}
			}
		}
		return result;
	}
}