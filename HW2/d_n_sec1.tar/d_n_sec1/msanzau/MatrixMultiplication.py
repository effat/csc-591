#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self,cnter):
        self.counter=cnter

    def get_column(self, matrix, col):
        return [row[col] for row in matrix]

    def Call_multiplier(self,matrice,power):
        #Write your code here to call Multiply_matrices lg(power) times.
        #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        #This method should return the final matrice
        result = [[0 for x in range(len(matrice))] for y in range(len(matrice))]
        for elem in range(len(matrice)):
            result[elem][elem] = 1
        i = power
        divs = []
        while i >= 1:
            divs.append(i)
            i /= 2
        for d in reversed(divs):
            if d == 1:
                result = matrice
            else:
                if d % 2 == 1:
                    result = self.Multiply_matrices(result, result)
                    result = self.Multiply_matrices(result, matrice)
                else:
                    result = self.Multiply_matrices(result, result)
        return result


    def Multiply_matrices(self,a,b):
        self.counter +=1
        #Write code here to multiply 2 matrices and return the resultant matrice
        result = [[] for x in range(len(a))]
        for row in range(len(a)):
            for col in range(len(a[0])):
                a_vec = a[row]
                b_vec = self.get_column(b, col)
                mult = [x*y for x, y in zip(a_vec, b_vec)]
                result[row].append(reduce((lambda x, y: x+y), mult))
        return result

