
#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	# The method Call_multiplier calls the Multiply_matrices method for a given input of A and n
	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice

		if power == 1:
			return matrice
		else:
			dividedMatrix = self.Call_multiplier(matrice, power/2)
			if power % 2 == 0:
				return self.Multiply_matrices(dividedMatrix, dividedMatrix)
			else:
		 		return self.Multiply_matrices(self.Multiply_matrices(dividedMatrix, dividedMatrix), matrice)


	def Multiply_matrices(self, a, b):
		self.counter += 1
		newMatrix = []
		for i in range(0, len(a[0])):
			newRow = []
			for j in range(0, len(b)):
				sum = self.multiplyRowAndColumn(a[i], self.getColumn(b, j))
				newRow.append(sum)
			newMatrix.append(newRow)
		return newMatrix

	def getColumn(self, candidateMatrix, colNumber):
		toReturn = []
		for i in range(0, len(candidateMatrix)):
			toReturn.append(candidateMatrix[i][colNumber])

		return toReturn

	def multiplyRowAndColumn(self, row, column):
		sum = 0
		for i in range(0, len(row)):
			sum += row[i] * column[i]
		return sum







