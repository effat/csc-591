
public class MatrixMultiplication {
	//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
	//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
		public static int counter = 0;

		public static int[][] Call_multiplier(int[][] matrix,int power){
			int n = matrix.length;
	        int [][] result = new int[n][n];
	        for(int i = 0 ; i < result.length ;i++){
	            for(int j = 0 ; j< result[i].length ;j++){
	                if(i==j){
	                    result[i][j] = 1;
	                }else{
	                    result[i][j] = 0;
	                }
	            }
	        }
	        while(power!=0){
	            if((power&1)==1) result = Multiply_matrices(result,matrix);
	            power>>=1;
	            matrix = Multiply_matrices(matrix,matrix);
	        }
	        return result;
			 //Write your code here to call Multiply_matrices lg(power) times.
			 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
			 //This method should return the final matrice
		}

		



		public static int[][] Multiply_matrices(int[][] a,int[][] b){
			counter+=1;
			 //Write code here to multiply 2 matrices and return the resultultant matrice
	        int result[][] = new int[a.length][b.length];
	        for(int i = 0 ; i < result.length ;i++){
	            for(int j = 0 ; j< result[i].length ;j++){
	                for(int k = 0 ; k < a[0].length ;k++){
	                    result[i][j] += a[i][k]*b[k][j];
	                }
	            }
	        }
	        return result;
				
		}

}
