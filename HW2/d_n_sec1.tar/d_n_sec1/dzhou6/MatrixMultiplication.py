# Name Dunhui Zhou   Unity ID: dzhou6
# DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
    def __init__(self, cnter):
        self.counter = cnter

    def Call_multiplier(self, matrice, power):
        # Write your code here to call Multiply_matrices lg(power) times.
        # This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
        # This method should return the final matrice
        x = [[0 for x in range(len(matrice))] for y in range(len(matrice))]
        for i in range(len(matrice)):
            for j in range(len(matrice)):
                if i == j:
                    x[i][j] = 1
        while power > 0:
            if (power % 2) == 0:
                matrice = self.Multiply_matrices(matrice, matrice)
                power = power / 2
            if (power % 2) != 0:
                x = self.Multiply_matrices(x, matrice)
                matrice = self.Multiply_matrices(matrice, matrice)
                power = power // 2
        return x

    def Multiply_matrices(self, a, b):
        self.counter += 1
        # Write code here to multiply 2 matrices and return the resultant matrice
        c = [[0 for x in range(len(a))] for y in range(len(a))]  # define new matrix
        for i in range(len(a)):
            for j in range(len(a)):
                for k in range(len(a)):
                    c[i][j] = c[i][j] + a[i][k] * b[k][j]
        return c
