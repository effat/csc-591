# DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
from math import log


class MatrixMultiplication:
    def __init__(self, cnter):
        self.counter = cnter

    def Call_multiplier(self, matrice, power):
        le = int(log(power, 2)) + 1
        c = [0 for i in range(le)]
        pow2 = [0 for i in range(le)]
        pow_matrix = [None for i in range(le)]
        denomitor = 1
        for i in range(le):
            pow2[i] = denomitor
            denomitor *= 2
            if i == 0:
                pow_matrix[i] = matrice
            else:
                pow_matrix[i] = self.Multiply_matrices(pow_matrix[i - 1], pow_matrix[i - 1])
        i = le - 1
        while i >= 0:
            c[i] = power / pow2[i]
            power = power % pow2[i]
            i -= 1
        result = [[1 if i == j else 0 for i in range(len(matrice))] for j in range(len(matrice))]
        for i in range(0, le):
            if c[i] == 1:

                result = self.Multiply_matrices(result, pow_matrix[i])
        return result

    def Multiply_matrices(self, a, b):
        self.counter += 1
        c = [[0 for i in range(len(a))] for j in range(len(a))]
        for i in range(len(a)):
            for j in range(len(a)):
                c[i][j] = 0
                for k in range(len(a)):
                    c[i][j] += a[i][k] * b[k][j]
        return c

