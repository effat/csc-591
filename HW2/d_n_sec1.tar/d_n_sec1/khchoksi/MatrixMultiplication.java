//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
	public static int counter = 0;

	/*public static void main(String[] args) {
		System.out.println("\n Hey there");
        int[][] matrix = {
					    {1,2,3},
					 	{3,2,1},
					 	{2,1,3}
						};

		int[][] ans = Call_multiplier(matrix, 7);
		printMatrix(ans);
		System.out.println("\n Counter: "+counter);
		//Call_multiplier(matrix,power)
	}*/
	

	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice		System.out.println("\n Hey there");
        boolean hasFinalMatriceValue = false;
		int length = matrix[0].length;
		int[][] finalMatrice = new int[length][length];
		//initialize the finalMatrice with unity matrix
		/*for(int i=0; i<length; i++){
			for(int j=0; j<length; j++){
				finalMatrice[i][j] = (i==j) ? 1 : 0;
			}
		}*/

		while(power>0){
			if(power % 2 == 0){
				matrix = Multiply_matrices(matrix,matrix);
				power = power/2;
			}else{
				
				if(hasFinalMatriceValue){
					finalMatrice = Multiply_matrices(finalMatrice,matrix);
					
				}	
				else{
					hasFinalMatriceValue = true;
					for(int i=0; i<length; i++){
						for(int j=0; j<length; j++){
							finalMatrice[i][j] = matrix[i][j];		//just copying array //no computation required
						}
					}
				
				}
				

				power = power-1;		//power reduced to one
			}
		}
		//finalMatrice = Multiply_matrices(finalMatrice,matrix);
		return finalMatrice;
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		 //Write code here to multiply 2 matrices and return the resultant matrice
		counter+=1;
		 
		 int length = a[0].length;				//Length of the resultant matrice
		 int[][] mul = new int[length][length];	//Resultant Matrice

		for(int i=0; i<length; i++){
			for(int j=0; j<length; j++){
				mul[i][j] = 0;
				for(int k=0;k<length;k++){
					mul[i][j] = (a[i][k]*b[k][j])+mul[i][j];	//matrix multiplication
				}
			}
		}
		return mul;	
	}

	/*public static void printMatrix(int[][] matrice){
		int length = matrice[0].length;				//Length of the matrice

		for(int i=0; i<length; i++){
			for(int j=0; j<length; j++){
				System.out.print("  "+matrice[i][j]);
			}
			System.out.print("\n");
		}
	}*/
}