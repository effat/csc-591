import math


#DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
class MatrixMultiplication:
	def __init__(self,cnter):
		self.counter=cnter

	def Call_multiplier(self,matrice,power):
		 #Write your code here to call Multiply_matrices lg(power) times.
		 #This method will have the 2-dimensional array and a number which specifies the power as inputs(Please see testcase file)
		 #This method should return the final matrice

                # initialize matrix with powers with initial element being matrice itself
                powers = [matrice]

                # append matrice raised to the (2^n)th powers
                for i in range(int(math.floor(math.log(power, 2)))):
                        powers.append(self.Multiply_matrices(powers[i], powers[i]))

                # number of powers calculated
                l = len(powers)
                # initialize as final element of list, will store resulting matrix to return
                result = powers[l-1]
                # count number of times we have multiplied A by itself
                cnt = pow(2, (l-1))

                # iterate through powers list backwards, starting with the second to last element
                for j in range(1, len(powers)+1):
                        # if multiplying the result by the jth element keeps us under the answer, continue. Otherwise skip
                        if cnt + pow(2, (l - j)) <= power:
                                # multiply result by the (l-j)th element
                                result = self.Multiply_matrices(result, powers[-j])
                                # increment counter accordingly
                                cnt = cnt + pow(2, (l-j))
                return result


	def Multiply_matrices(self,a,b):
		self.counter +=1
		#Write code here to multiply 2 matrices and return the resultant matrice

                # initialize result list
                result = []
                # for rows in a
                for i in range(len(a)):
                        # append an empty list to insert into
                        result.append([])
                        # for columns in b
                        for j in range(len(b[i])):
                                # initialize sum as 0
                                sum = 0
                                # multiply values and add to sum
                                for k in range(len(a[i])):
                                        sum += a[i][k] * b[k][j]
                                # append sum to result matrix
                                result[i].append(sum)
                return result
