//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
public class MatrixMultiplication{
  public static int counter = 0;

  public static int[][] Call_multiplier(int[][] matrix,int power){
    //Write your code here to call Multiply_matrices lg(power) times.
    //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
    //This method should return the final matrice
     int[][] result = new int[matrix.length][matrix[0].length];
     //for (int i = 0; i < result.length; i++) {
     //  for (int j = 0; j < result[0].length; j++) {
     //    result[i][j] = 1;
     //  }
     //}
     for (int i = 0; i < result.length; i++) { //Make identity matrix
       result[i][i] = 1;
     }
     
     //int temp[][] = new int[matrix.length][matrix.length]; //Setup temp matrix
     int temp[][];
     
     while (power > 0) {
       if(power%2 != 0) {
         temp = Multiply_matrices(result, matrix);
         result = temp;
       }
       power = power/2;
       temp = Multiply_matrices(matrix, matrix);
       matrix = temp;
     }
     return result;
  }

  public static int[][] Multiply_matrices(int[][] a,int[][] b){
    counter+=1;
    //Write code here to multiply 2 matrices and return the resultant matrice
    int heightA = a.length;
    int lengthA = a[0].length;
    int lengthB = b[0].length;
    int c[][] = new int[heightA][lengthA];
    
    for (int i = 0; i < heightA; i++) {
      for (int j = 0; j < lengthB; j++) {
        for (int k = 0; k < lengthA; k++) {
          c[i][j] += a[i][k] * b[k][j];
        }
      }
    }
    return c;
  }
  
}