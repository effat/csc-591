/**
 * MatrixMultiplication class
 * @author Sakthi Murugan [srmuruga]
 */

public class MatrixMultiplication {

	public static int counter = 0;
 
  //stat_power holds the original power value
  public static int stat_power = 0;
  
  //Temporary matrix which holds the powered matrix temporarily
  public static int[] powMatrix;
  
  //Unit matrix - Any matrix when multiplied with unit matrix results in
  //same matrix
  public static int[][] tempMatrix;
  
  //product of two matrices
  public static int[][] prodMatrix;
  
  /**
   * Call_multiplier method calls the Multiply_matrices method
   * recursively to calculate matrix^power
   * @param matrix original Matrix passed to the method
   * @param power the power to which matrix has to be raised
   * @return returns the powered matrix each time
   */ 
  
	public static int[][] Call_multiplier(int[][] matrix,int power){
      
      powMatrix = new int[2* (int) (Math.log10(power) / Math.log10(2))];
      int count = 0;
     
      while(power > 0){
        powMatrix[count] = power;
        count++;
        power = power/2;
      }
     count--;
     
      
      
      tempMatrix = matrix;
      
      for(int i = --count;i>=0; i--){
        if (powMatrix[i] % 2 == 0 ) {
          tempMatrix = Multiply_matrices(tempMatrix,tempMatrix);
        }
          
        else
          tempMatrix = Multiply_matrices( Multiply_matrices(matrix,tempMatrix),tempMatrix);          
      }
     
     return tempMatrix;
	}
  
  /**
   * Multiply_matrices method calculates the product of the 
   * two matrices passed to it
   * @param a first matrix to be multiplied
   * @param b second matrix to be multiplied
   * @return returns the product of the two passed matrices
   */ 
  
	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		prodMatrix = new int[a.length][a[0].length];
		for ( int i = 0; i < a.length; i++ ) {
			for ( int j = 0; j < a[0].length; j++ ) {
				prodMatrix[i][j] = 0;
				for ( int k = 0; k < a[0].length; k++) {
					prodMatrix[i][j] += a[i][k]*b[k][j];
				}
			}
		} 
		return prodMatrix;
	}
}
