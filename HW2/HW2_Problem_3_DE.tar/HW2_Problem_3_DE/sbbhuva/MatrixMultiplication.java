//DO NOT CHANGE ANY EXISTING CODE IN THIS FILE
//DO NOT CHANGE THE NAMES OF ANY EXISTING FUNCTIONS
import java.io.*;
public class MatrixMultiplication{
	public static int counter = 0;
/*	public static void main(String args[]) {
		int[][] matrix = {{1,2,3},{3,1,2},{2,3,1}};
		int power = 8;
		int[][] answer=Call_multiplier(matrix,power);
		for(int i=0;i<answer.length;i++)
		{	for(int j=0;j<answer[0].length;j++)
				System.out.print(answer[i][j]+" ");
		System.out.println();
		}
	}

*/
	public static int[][] Call_multiplier(int[][] matrix,int power){
		 //Write your code here to call Multiply_matrices lg(power) times.
		 //This method will have the 2-dimensional array and an int which specifies the power as inputs(Please see testcase file)
		 //This method should return the final matrice
		int[][] Num =new int[matrix.length][matrix.length];
		// Creating a identity matrix of the same length as the input matrix 
		for (int i = 0; i < matrix.length; i++){
			for (int j = 0; j < matrix.length; j++){ 
				if (i == j){
					Num[i][j] = 1;
				}
				else Num[i][j] = 0;
				}
			}
		int n = power;
		// In case, n = 0, returns the identity matrix
		if (n == 0)
			return Num;
		else{
			while (n > 0){
				if (n%2 == 1) 
					Num = Multiply_matrices(Num,matrix); // Checks for odd
				matrix = Multiply_matrices(matrix,matrix);
				n = (int)Math.floor(n/2);
			}
		}
		return Num; 
	}

	public static int[][] Multiply_matrices(int[][] a,int[][] b){
		counter+=1;
		 //Write code here to multiply 2 matrices and return the resultant matrice
		 // Standard code for matrix multiplication taken from Lecture 1
		int[][] result=new int[a.length][b.length];
		for(int i=0;i<a.length;i++){
			for(int j=0;j<b.length;j++){
				result[i][j]=0;
				for(int k=0;k<b.length;k++){
					result[i][j]+=a[i][k]*b[k][j];
				}			
			}
		}
		return result;
	}
}
