package Main;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

/**
 * Project 1 that compresses and decompresses from standard input.
 * 
 * @author Arno Dasgupta (adasgup2)
 *
 */
public class proj1 {

	/**
	 * Main method that reads from standard input and figures out if it needs to be
	 * decompressed on compressed
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		MTFLinkedList list = new MTFLinkedList();
		// Scanner in = new Scanner(System.in);

		Scanner in = new Scanner(System.in, "ISO-8859-1");

		if (in.hasNextInt()) {
			decompression(in, list);
		} else {
			compression(in, list);
		}
	}

	/**
	 * Decompression helper method that reads from stdin and uncompresses the file.
	 * 
	 * @param in   - the input that is being read in.
	 * @param list - the list that is being used to store words.
	 */
	public static void decompression(Scanner in, MTFLinkedList list) {
		boolean done = true;
		int place = -3;
		int len = 0;
		String s = "";
		String temp = "";
		String add = "";
		String line[];
		char ogArr[];

		while (in.hasNextLine() && done) {
			// Read past the 0_
			boolean didSomething = false;
			if (place == -3)
				in.next();

			s = in.nextLine();
			ogArr = s.toCharArray(); // Puts every character in the line into a char array.
			line = s.split("[^A-Za-z0-9]+"); // Splits the line that was read in based on letters and numbers
			len = 0; // Holds on to tdhe place in the line I am in, by character.
			// Loops through the entire length of the line
			for (int j = 0; j < line.length; j++) {
				didSomething = true;
				temp = line[j];
				// Handles the first space after the 0
				if (place == -3) {
					place = -2;
					len++;
					continue;
				} else if (place == -2) {
					// handles the cases where there could be a tab, leading space, etc in a line.
					place = -1;
					while (s.length()  > len) {
						if (!Character.isAlphabetic(s.charAt(len)) && !Character.isDigit(s.charAt(len))) {
							System.out.print(s.charAt(len));
							len++;
						} else {
							break;
						}
					}
				}

				len += temp.length();
				// len = temp.length();
				if (temp.equals("") && j == 0) {
					while (s.length() > len) {
						if (!Character.isAlphabetic(s.charAt(len)) && !Character.isDigit(s.charAt(len))) {
							System.out.print(s.charAt(len));
							len++;
						} else {
							break;
						}
					}
				} else if (Character.isDigit(temp.charAt(0))) { // Checks if it is a digit
					place = Integer.valueOf(temp);
					if (place == 0) {
						done = false;
						break;
					}
					add = list.lookUp(place);
					list.addToFront(add);
					System.out.print(add);
				} else { // Must be a word/string
					list.addToFront(temp);
					System.out.print(temp);
				}

				// Handles printing of special characters after a word.
				while (s.length()  > len) {
					if (!Character.isAlphabetic(s.charAt(len)) && !Character.isDigit(s.charAt(len))) {
						System.out.print(s.charAt(len));
						len++;
					} else {
						break;
					}
				}

			}
			if (!didSomething && ogArr.length != 0) {
				while (s.length()  > len) {
					if (!Character.isAlphabetic(s.charAt(len)) && !Character.isDigit(s.charAt(len))) {
						System.out.print(s.charAt(len));
						len++;
					} else {
						break;
					}
				}
			}
			// Checks if there is another line, and keeps going.
			if (in.hasNextLine()) {
				System.out.println("");
			} else {
				break;
			}
			place = -2;
		}
		in.close();
	}

	/**
	 * Compression helper method that reads from stdin and compresses the file.
	 * 
	 * @param in   - the input that is being read in.
	 * @param list - the list that is being used to store words.
	 */
	public static void compression(Scanner in, MTFLinkedList list) {
		int place = -1;
		int len = 0;
		int read = 0;
		int write = 0;
		boolean unique = true;
		String s = "";
		String temp = "";
		String line[];
		char ogArr[];
		char arr[];

		while (in.hasNextLine()) {
			boolean didSomething = false;
			if (place == -1) {
				System.out.print("0 ");
				place = 0;
			}

			s = in.nextLine();
			ogArr = s.toCharArray();
			read += s.length();
			line = s.split("[^a-zA-Z]"); // Splits the line based solely on strings
			len = 0;

			// Loops for the entireity of the line
			for (int j = 0; j < line.length; j++) {
				didSomething = true;
				temp = line[j];

				// Takes care of the Non alphabetic characterse
				if (temp.equals("") && j == 0) {
					while (s.length()  > len) {
						if (!Character.isAlphabetic(s.charAt(len))) {
							System.out.print(s.charAt(len));
							len++;
							write++;
						} else {
							break;
						}
					}
				} else if (temp.equals("")) {
					place = 0;
					while (s.length() > len) {
						if (!Character.isAlphabetic(s.charAt(len))) {
							System.out.print(s.charAt(len));
							len++;
							write++;
						} else {
							break;
						}
					}
					continue;
				} else { // Finally reached a word
					arr = temp.toCharArray();
					len += arr.length;
					unique = list.isUnique(temp);
					place = list.addToFront(temp);

					if (unique) {
						System.out.print(temp);
						write += temp.length();
					} else {
						System.out.print(place);
						write += String.valueOf(place).length();
					}
					// Prints out the parts that aren't a word/letter
					while (s.length()  > len) {
						if (!Character.isAlphabetic(s.charAt(len))) {
							System.out.print(s.charAt(len));
							len++;
							write++;
						} else {
							break;
						}
					}

				}
			}

			if (!didSomething && s.length() != 0) {
				while (s.length() > len) {
					if (!Character.isAlphabetic(s.charAt(len))) {
						System.out.print(s.charAt(len));
						len++;
						write++;
					} else {
						break;
					}
				}
			}
			if (in.hasNextLine()) {
				System.out.println("");
			} else {
				break;
			}

		}
		in.close();
		System.out.println("");
		System.out.println("0 Uncompressed: " + read + " bytes;  Compressed: " + write + " bytes");

	}

}
