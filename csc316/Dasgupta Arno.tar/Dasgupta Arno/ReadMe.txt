This program is run through input redirection, so compile the program, and run it
by doing java proj1 < input1.txt > output.txt
It takes input from input1.txt and returns the output to output.txt.

Inputs 3-10: 
	Did Find and replace using [^\x00-\x7F]+ and replaced them with "" (empty) to get rid of all the non-ascii/printable characters
