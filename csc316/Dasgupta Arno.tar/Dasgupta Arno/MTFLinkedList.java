package Main;

/**
 * Linked List class that implements the move to front heuristic.
 * @author Arno Dasgupta (adasgup2)
 *
 */
public class MTFLinkedList {
	/** Node that contains the beginning of the list */
	Node head;
	
	/**
	 * Method that adds the word to the front. If it exists, it removes the old one and moves it to the front.
	 * @param str - the word to be added.
	 * @return - the place of where the word used to be, or 1 if it is a unique word
	 */
	public int addToFront( String str ) {
		int i = 1;
		Node add = new Node( str );
		Node temp = head;
		Node prev = head;
		
		if ( head != null && head.data.equals(str)) {
			return i;
		}
		
		while (temp != null) {
			if ( temp.data.equals(str)) {
				prev.next = temp.next;
				temp.next = head;
				head = temp;
				return i;
			}
			prev = temp;
			temp = temp.next;
			i++;
		}
		
		add.next = head;
		head = add;
		return 1;
	}
	
	/**
	 * Function that checks if the word is unique, or if it already exists
	 * @param str - word that is going to be checked.
	 * @return true if the word is unique, otherwise false.
	 */
	public boolean isUnique( String str ) {
		Node temp = head;
		
		while ( temp != null ) {
			if ( temp.data.equals(str)) {
				return false;
			}
			temp = temp.next;
		}
		return true;
	}
	
	/**
	 * Function that looks up what word is in place of the number. If it exists, it returns the string
	 * @param num - the place where a number should exists
	 * @return the string at that place in the list
	 */
	public String lookUp( int num ) {
		Node temp = head;
		int i = 1;
		
		while ( i < num && temp != null ) {
			temp = temp.next;
			i++;
		}
		
		return temp.data;
	}
	
	/**
	 * Node private class that holds the data for nodes.
	 * @author Arno Dasgupta (adasgup2)
	 *
	 */
	private class Node {
		String data;
		Node next;
		
		Node( String data) {
			this.data = data;
			next = null;
		}
	}
}
