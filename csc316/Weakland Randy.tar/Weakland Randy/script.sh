#!/bin/bash

for f in test-files/input*.txt; do

    java -jar Proj1.jar < $f >| $f.compressed.out

    java -jar Proj1.jar < $f.compressed.out >| $f.decompressed.out

    diff $f $f.decompressed.out >|$f.diff

    status=$?

    if [ $status -eq 0 ]

    then

        echo "TEST PASSED: $f"

    else

        echo "TEST FAILED: $f"

    fi

done