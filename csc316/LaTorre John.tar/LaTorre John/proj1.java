import java.util.Scanner;
/**
 * A compression and decompression program for text
 * @author John LaTorre
 * @version 6.5.2019
 *
 */
public class proj1 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int [] characters = new int[2];
		input.useDelimiter("");
		
		String first = input.next();
		if (Character.isDigit(first.charAt(0))) {
			decompress(input);
		} else {
			characters = compress(input, first);
			System.out.println();
			System.out.println("0 Uncompressed: " + characters[0] + " bytes;  Compressed: " + characters[1] + " bytes");
		}
		input.close();
		
	}
	/**
	 * Decompression algorithm
	 * @param input
	 */
	public static void decompress(Scanner input) {
		String delim = " .,/%&!@#$?\\-_><'";
		WordList<String> words = new WordList<String>();
		input.next();
		while (input.hasNextLine()) {
			String w = "";
			char c = ' ';
			String line = input.nextLine();
			if (!line.equals("")) {
				c = line.charAt(0);
			} else {
				line = input.nextLine();
			}
			//char c = line.charAt(0);
			if (Character.getNumericValue(c) == 0) {
				break;
			}
			
			for (int i = 0; i < line.length(); i++) {
				c = line.charAt(i);
				if (Character.getNumericValue(c) == 0) {
					break;
				}
				if (delim.indexOf(c) != -1) {
					if (!words.contains(w) && !w.equals("")) {
						words.add(0, w);
						System.out.print(w);
						w = "";
						System.out.print(c);
					} else {
						System.out.print(c);
					}
					//It's getting late and figuring out a way to compensate for multi digit list indexes while
					// maintaining the single character parsing method is beyond my skills to solve in the time I 
					// have left. Below is my attempt which still has flaws but I am giving up on this feature for now.
				} else if (!Character.isDigit(c)) {
					w += c;
				} else if (Character.isDigit(line.charAt(i+1))) {
					String num = "";
					num = num + line.charAt(i) + line.charAt(i + 1);
					System.out.print(words.get(Integer.parseInt(num) - 1));
					words.moveToFront(words.get(Integer.parseInt(num) - 1));
					i++;
				} else if (Character.isDigit(line.charAt(i+1)) && Character.isDigit(line.charAt(i+2))) {
					String num = "";
					num = num + line.charAt(i) + line.charAt(i + 1) + line.charAt(i + 2);
					System.out.print(words.get(Integer.parseInt(num) - 1));
					words.moveToFront(words.get(Integer.parseInt(num) - 1));
					i+= 2;
				} else if (Character.isDigit(line.charAt(i+1)) && Character.isDigit(line.charAt(i+2)) && Character.isDigit(line.charAt(i+3))) {
					String num = "";
					num = num + line.charAt(i) + line.charAt(i + 1) + line.charAt(i + 2) + line.charAt(i + 3);
					System.out.print(words.get(Integer.parseInt(num) - 1));
					words.moveToFront(words.get(Integer.parseInt(num) - 1));
					i+= 3;
				}else {
					System.out.print(words.get(Character.getNumericValue(c) - 1));
					words.moveToFront(words.get(Character.getNumericValue(c) - 1));
				}
			}
			if (!w.equals("")) {
				words.add(0, w);
				System.out.print(w);
			}
			if (input.hasNextLine()) {
				System.out.println("");
			}
		}
	}
	/**
	 * The compression algorithm
	 * @param input
	 * @param first
	 * @return the data needed for the data tally at the end of file
	 */
	public static int[] compress(Scanner input, String first) {
		int uncompressed = 1;
		int compressed = 0;
		int[] data = {uncompressed, compressed};
		String delim = " .,/%&!@#$?\\-_><'";
		WordList<String> words = new WordList<String>();
		String w = "";
		w += first;
		System.out.print("0 ");
		while (input.hasNextLine()) {
			String line = input.nextLine();
			char c = ' ';
			
			for (int i = 0; i < line.length(); i++) {
				c = line.charAt(i);
				uncompressed++;
				if (delim.indexOf(c) != -1) {
					if (!words.contains(w) && !w.equals("")) {
						words.add(0, w);
						System.out.print(w);
						compressed += w.length();
						w = "";
						System.out.print(c);
						compressed++;
					} else if (!w.equals("")){
						int index = 0;
						for (int j = 0; j < words.size(); j++) {
							if (words.get(j).equals(w)) {
								index = j + 1;
								System.out.print(index);
								compressed += ((int) Math.log10(index) + 1);
								System.out.print(c);
								compressed++;
							}
						}
						
						words.moveToFront(w);
						w = "";
						
					} else {
						System.out.print(c);
						compressed++;
					}
				} else {
					w += c;
				}
			}
			if (!w.equals("")) {
				words.add(0, w);
				System.out.print(w);
				compressed += w.length();
				w = "";
			}
			if (input.hasNextLine()) {
				System.out.println("");
			}
		}
	data[0] = uncompressed;
	data[1] = compressed;
	return data;
	}
	
}
