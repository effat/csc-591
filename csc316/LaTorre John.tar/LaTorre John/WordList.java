
/**
 * Creates a LinkedList using Recursion to implement functionality
 * Originally created for CSC 216 project in 2017, adapted for CSC 316 SUM2019 Project 1
 * @author John LaTorre
 * @version 5.30.19
 * @version 11.14.17
 * @param <E> The list holds any type of object once declared
 */
public class WordList<E> {

	/** A ListNode that keeps track of the front of the list */
	private ListNode front = null;
	/** The size of the list */
	private int size;
	
	/**
	 * Constructs a basic, empty list
	 */
	public WordList() {
		front = null;
		size = 0;
	}
	
	/**
	 * Size of the list
	 * @return the size of the list
	 */
	public int size() {
		return size;
	}
	
	/**
	 * Checks if the list is empty
	 * @return true if empty, false if not
	 */
	public boolean isEmpty() {
		return size == 0;
	}
	
	/**
	 * Checks to see if the list already contains the provided element
	 * @param element the object to check
	 * @return true if the element is in the list, false if not
	 */
	public boolean contains(E element) {
		boolean there;
		if (isEmpty()) {
			there = false;
		} else {
			there = front.contains(element);
		}
		return there;
	}
	/**
	 * Adds an object to the list
	 * @param object to be added
	 * @return true if can add false if not
	 */
	public boolean add(E object) {
		boolean added = false;
		if (isEmpty()) {
			front = new ListNode(object, null);
			size++;
			added = true;
		} else {
			front.add(object);
			added = true;
		}
		return added;
	}
	/**
	 * Adds an object at a specific index
	 * @param idx index where to add 
	 * @param obj object to be added
	 */
	public void add(int idx, E obj) {
		
		if (idx < 0 || idx > size) {
			throw new IndexOutOfBoundsException();
		}
		if (obj == null) {
			throw new NullPointerException();
		}
		if (isEmpty()) {
			front = new ListNode(obj, null);
			size++;
		} else if (idx == 0) {
			front = new ListNode(obj, front);
			size++;
		} else {
			front.add(idx, obj);
		}
	}
	/**
	 * Gets an object at a specific index
	 * @param index to get the object from
	 * @return the desired object
	 */
	public E get(int index) {
		E got = null;
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException();
		} else {
			got = front.get(index);
		}
		return got;
	}
	/**
	 * Removes an object from the list at an index
	 * @param index index of the object to be removed
	 * @return the object that was removed
	 */
	public E remove(int index) {
		E removed = null;
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		if (index == 0) {
			removed = front.data;
			front = front.next;
			size--;
		} else {
			removed = front.remove(index);
		}
		return removed;
	}
	/**
	 * Removes a given object from the list
	 * @param obj object to remove
	 * @return the removed object
	 */
	public boolean remove (E obj) {
		boolean removed;
		if (obj == null) {
			removed = false;
			return removed;
		}
		
		if (isEmpty()) {
			removed = false;
			return removed;
		}
		if (front.data.equals(obj)) {
			removed = true;
			front = front.next;
			size--;
		} else {
			removed = front.remove(obj);
		}
		return removed;
	}
	/**
	 * Sets the item in the list at a given index to a specific object
	 * @param idx index to set the object
	 * @param element the object to set
	 * @return the element that was replaced
	 */
	public E set(int idx, E element) {
		E setted = null;
		if (element == null) {
			throw new NullPointerException();
		}
		if (contains(element)) {
			throw new IllegalArgumentException();
		}
		if (idx < 0 || idx >= size) {
			throw new IndexOutOfBoundsException();
		} else {
			setted = front.set(idx, element);
		}
		return setted;
	}
	/**
	 * Moves the object at the provided index to the front of the list
	 * @param idx index of item to move
	 */
	public void moveToFront(E obj) {
		remove(obj);
		add(0, obj);
	}
	
	/**
	 * Creates the ListNode object that holds the data and keeps track of the list
	 * @author John LaTorre
	 *
	 */
	private class ListNode {
		
		/** The data in the node */
		public E data;
		/** The node pointing to the next element in the list */
		public ListNode next;
		
		/**
		 * Constructs a ListNode with only a data parameter
		 * @param data the data of the node
		 * @param next the next ListNode in the list
		 */
		public ListNode(E data, ListNode next) {
			this.data = data;
			this.next = next;
		}
		/**
		 * Checks recursively if each node in the list has the given element
		 * @param element the data to check
		 * @return true if it's there, false if not
		 */
		public boolean contains(E element) {
			boolean there = false;
			if (data.equals(element)) {
				there = true;
			} else if (!data.equals(element) && next != null) {
				there = next.contains(element);	
			}
			return there;
		}
		/**
		 * Recursive check to add an object to the back of the list
		 * @param element object to be added
		 */
		public void add(E element) {
			if (next == null) {
				next = new ListNode(element, null);
				size++;
			} else {
				next.add(element);
			}
		}
		/**
		 * Recursive check to add elements at a given index
		 * @param idx index where to add the new element
		 * @param element the object to add
		 */
		public void add (int idx, E element) {
			if (idx == 1) {
				next = new ListNode(element, next);
				size++;
			} else {
				next.add(idx - 1, element);
			}
		}
		/**
		 * Recursive check to get an element of the list
		 * @param idx index to get
		 * @return the element at the given index
		 */
		public E get(int idx) {
			E got = null;
			if (idx == 0) {
				got = data;
			} else {
				got = next.get(idx - 1);
			}
			return got;
		}
		/**
		 * Recursive check to remove an element at a given index
		 * @param idx the index to remove the element from
		 * @return the removed element
		 */
		public E remove(int idx) {
			E removed = null;
			if (idx == 1) {
				removed = next.data;
				next = next.next;
				size--;
			} else {
				next.remove(idx - 1);
			}
			return removed;
		}
		/**
		 * Recursive check to remove a given object from the list
		 * @param obj the object to be removed
		 * @return the object that was removed
		 */
		public boolean remove(E obj) {
			boolean removed = false;
			if (next.data.equals(obj)) {
				removed = true;
				next = next.next;
				size--;
			} else {
				next.remove(obj);
			}
			return removed;
		}
		/**
		 * Recursive check to set the data of a node to a new object
		 * @param idx index of the node whose data will be set
		 * @param element the object to set
		 * @return the previous data in the node
		 */
		public E set(int idx, E element) {
			E setted = null;
			if (idx == 0) {
				setted = data;
				data = element;
			} else {
				next.set(idx - 1, element);
			}
			return setted;
		}
	}
	
}
