#!/bin/bash

for f in test-files/input*.txt; do

    java proj1 < $f >| $f.compressed.out

    java proj1 < $f.compressed.out >| $f.decompressed.out

    diff $f $f.decompressed.out >|$f.diff

    status=$?

    if [ $status -eq 0 ]

    then

        echo "TEST PASSED: $f"

    else

        echo "TEST FAILED: $f"

    fi

done