import java.util.*;
import java.io.*;
import java.lang.*;

public class proj2 {
  
  public static int MAX_CHAR = 256;
  
  public static char[] pretrav = new char[MAX_CHAR];
  public static char[] posttrav = new char[MAX_CHAR];
  public static Queue<Node> q = new LinkedList<>();
  public static int pathA = 0;
  public static int pathB = 0;
  public static void main(String[] args) {
    
    System.out.println("Input File Name: ");
    Scanner scanPrompt = new Scanner(System.in);
    String inputFile = scanPrompt.nextLine();
    File file = new File(inputFile);
    System.out.println("Output File Name: ");
    String outputFile = scanPrompt.nextLine();
    int preCounter = 0;
    int postCounter = 0;
    char starter = ' ';
    try {
      Scanner scanFile = new Scanner(file);
      
      while(scanFile.hasNextLine()) {
        String line = scanFile.nextLine();
        Scanner scanChar = new Scanner(line);

        if ( scanChar.hasNext()) {
          starter = scanChar.next().charAt(0);
        }
        // if line start with < store the charcters in pretrav array
        if ( starter == '<') {
          while( scanChar.hasNext()) {
            char ch = scanChar.next().charAt(0);
            pretrav[preCounter] = ch;
            preCounter++;
          }
        }
        // if line start with > store the charcters in posttrav array
        if (starter == '>') {
          while( scanChar.hasNext()) {
            char ch = scanChar.next().charAt(0);
            posttrav[postCounter] = ch;
            postCounter++;
          }
          break;
        }
      }
      Node root = buildTree(preCounter,0, 0);
      
      while(scanFile.hasNextLine()) {
        
        String line = scanFile.nextLine();
        Scanner scanChar = new Scanner(line);
        
        if (starter == '?') {
          while( scanChar.hasNext()) {
            char a = scanChar.next().charAt(0);
            char b = scanChar.next().charAt(0);
            //System.out.println(a + " " + b);
            pathA = 0;
            pathB = 0;
            
            markFirstAncestors(root, a);
            findFirstMark(root,b);
            //System.out.println(pathA + " " + pathB );
            try {
              PrintWriter writer = new PrintWriter(outputFile);
              
              if (pathA == 0 && pathB == 0) {
                writer.println(a + " is " + b);
              }
              if (pathA == 0 && pathB == 1) {
                writer.println(a + " is " + b + "'s parent");
              }
              if (pathA == 0 && pathB == 2) {
                writer.println(a + " is " + b + "'s grandparent");
              }
              if (pathA == 0 && pathB == 3) {
                writer.println(a + " is " + b + "'s great-grandparent");
              }
              if (pathA == 0 && pathB > 3) {
                writer.println(a + " is " + b + "'s (great)^"+ (pathB-2)+ "-grandparent");
              }
              if (pathA == 1 && pathB == 0) {
                writer.println(a + " is " + b + "'s child");
              }
              if (pathA == 2 && pathB > 0) {
                writer.println(a + " is " + b + "'s grandchild");
              }
              if (pathA >= 3 && pathB == 0) {
                writer.println(a + " is " + b + "'s (great)^"+ (pathB-2)+ "-grandchild");
              }
              if (pathA == 1 && pathB == 1) {
                writer.println(a + " is " + b + "'s sibling");
              }
              if (pathA == 1 && pathB == 2) {
                writer.println(a + " is " + b + "'s aunt/uncle");
              }
              if (pathA == 1 && pathB >= 2) {
                writer.println(a + " is " + b + "'s (great)^"+ (pathB-2)+ "-aunt/uncle");
              }
              if (pathA == 2 && pathB == 1) {
                writer.println(a + " is " + b + "'s niece/nephew");
              }
              if (pathA >= 2 && pathB == 1) {
                writer.println(a + " is " + b + "'s (great)^"+ (pathB-2)+ "-niece/nephew");
              }
              if (pathA >= 2 && pathB >= 2) {
                writer.println(a + " is " + b + "'s " + ((Math.min(pathB,pathA))-1) + "th cousin " + Math.abs(pathA-pathB) + "times removed.");
              }
              unMarkAll(root);
              for (int i = 0; i < q.size(); i ++ ) {
                Node next = q.remove();
                writer.println(next.getChar());
              }
              writer.close();
            } catch (IOException e) {
                System.out.println("Can't Create File");
            }
          }
        }
      }
    }
    catch( FileNotFoundException e) {
      e.printStackTrace();
    }
    
  }
  /**
   *
   */
  public static void markFirstAncestors(Node root, char a ) {
    
      if ( root.getChar() != a ) {
        if ( root.getNumberOfChildren() > 0 ) {
          for ( int i = 0; i < root.getNumberOfChildren(); i++ ) {
            Node newRoot = root.getChildNode(i);
            markFirstAncestors(newRoot, a);
            if ( newRoot.getMarkVal() == 1 ) {
              root.markAncestor();
              pathA++;
              break;
            }
          }
        }
      }
      else {
        root.markAncestor();
      }
    
  }
  /**
   *
   */
  public static void findFirstMark(Node root, char b ) {
    
    if ( root.getChar() != b ) {
      if ( root.getNumberOfChildren() > 0 ) {
        for ( int i = 0; i < root.getNumberOfChildren(); i++ ) {
          Node newRoot = root.getChildNode(i);
          findFirstMark(newRoot, b);
          if ( newRoot.getMarkB() == 1 ) {
            if ( root.getMarkVal() == 0 ){
              pathB++;
            }
            root.markB();
            break;
          }
      }
    }
    else {
      root.markB();
      if ( root.getMarkVal() == 0 ) {
        pathB++;
      }
      else if ( root.getMarkVal() == 1) {
        pathB = 0;
      }
    }
      
    }
  }
  /**
   *
   */
  public static void unMarkAll(Node root) {
    root.unMarkAncestor();
    root.unMarkB();
    if ( root.getNumberOfChildren() > 0 ){
      for ( int i = 0; i < root.getNumberOfChildren(); i++ ) {
        Node newRoot = root.getChildNode(i);
        unMarkAll(newRoot);
      }
    }
  }
  /**
   * recursive function that build subtree
   * @param size the number of nodes in the subtree to be build
   * @param prestart the place in pretrav where the preorder traversal of this subtree begins
   * @param poststart the place in posttrav where the postorder traversal of this subtree begins
   */
  public static Node buildTree(int size, int prestart, int poststart) {
    
    if ( prestart < 0 || poststart < 0 ) {
      return null;
    }
    Node root = new Node(pretrav[prestart]);
    q.add(root);
    int childrenSize = 0;
    
    for ( int i = poststart; i <= size; i++ ) {
      char a = pretrav[prestart];
      char b = posttrav[i];
      if ( a != b ) {
        childrenSize ++;
      }
      else {
        break;
      }
    }
    int nextChild = 1;
    for ( int i = poststart; i <= size; i++ ) {
      if ( pretrav[prestart + 1 ] != posttrav[i]) {
        nextChild ++;
      }
      else {
        break;
      }
    }
    prestart++;
    
    while ( childrenSize > 0 ) {
      root.addChild(buildTree(childrenSize, prestart, poststart));
      childrenSize-=nextChild;
      poststart+=nextChild;
      prestart++;
    }
    return root;
  }
}

class Node {
  char key;
  ArrayList<Node> children;
  int mark = 0;
  int markB = 0;
  
  Node(char ch) {
    this.key = ch;
    this.children = new ArrayList<Node>();
  }
  public void addChild(Node n) {
    children.add(n);
  }
  public char getChar() {
    return key;
  }
  
  public void markAncestor() {
    mark = 1;
  }
  public void unMarkAncestor() {
    mark = 0;
  }
  
  public void markB() {
    markB = 1;
  }
  public void unMarkB() {
    markB = 0;
  }
  
  public Node getChildNode(int i) {
    return children.get(i);
  }
  
  public int getNumberOfChildren() {
    return children.size();
  }
  public int getMarkVal() {
    return mark;
  }
  
  public int getMarkB() {
    return markB;
  }

  
}
