import javafx.util.Pair;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Author by Maggie Fang. Email maggie2fang@gmail.com. Date on 2019-01-31
 * Talk is Cheap,Show me the Code.
 **/
public class MazeSearch {
    private static final int MODE_ALL = 0;
    private static final int MODE_SHOREST = 1;
    int n; // the size of matrix ,e.g 4*4, n = 4
    int solutionCnt = 0;  // the total number of unique paths to get to goal,

    // store the shortest path when we exhaust all unique path
    String shortestPath = null;
    // store the moves the shortest path made to get to goal
    int shortLength = Integer.MAX_VALUE;

    /**
     * @param cell
     * @param goal
     * @param matrix
     * @return
     */
    public int heuristic(int[] cell, int[] goal, int[][] matrix) {
        int x = cell[0];
        int y = cell[1];
        if (x == goal[0] && y == goal[1]) {
            return 0;
        }
        if (x == goal[0] || y == goal[1]) {
            return 1;
        }
        return 2;
    }


    /**
     * entry of bfs
     *
     * @param file filename
     */
    public void bfsSearch(String file) {
        solutionCnt = 0;
        shortLength = Integer.MAX_VALUE;
        shortestPath = null;
        Pair<int[][], int[]> pair = fileProcess(file);
        try {
            bfsForMaze(pair.getValue(), pair.getKey(), MODE_ALL);
//            bfsForMaze(pair.getValue(), pair.getKey(), MODE_SHOREST);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * bfs for maze
     *
     * @param goal,  the position(x,y) of goal
     * @param matrix the maze matrix. the point of G,I use Integer.MAX_VALUE to indicate.
     * @param mode   , expansiable. when =MODE_ALL,means to find all unique paths. when =MODE_SHOREST mean to find the  unqiue path.
     */
    public void bfsForMaze(int[] goal, int[][] matrix, int mode) throws FileNotFoundException {
        n = matrix.length;
        // pair<Integer,String> .e.g (i,prepath), measn when get to position i, the pre path it went
        LinkedList<Pair<Integer, String>> queue = new LinkedList<>();  // queue for bfs
        queue.add(new Pair<>(0 * n + 0, "0,0\n"));
        while (!queue.isEmpty()) {
            int size = queue.size();
            while (size > 0) {
                Pair<Integer, String> cur = queue.poll();
                int key = cur.getKey();
                int x = key / n;
                int y = key % n;
                if (x == goal[0] && y == goal[1]) {
                    if (solutionCnt == 0) {
                        PrintWriter out = new PrintWriter(n + "x" + n + "maze-bfs.txt");
                        out.println(cur.getValue());
                        out.flush();
                    }

                    if (mode == MODE_SHOREST) { // the first one find in bfs is the shortest.
                        System.out.println("BFS shortest path for " + n + "x" + n + " maze :");
                        System.out.println(cur.getValue());
                        String[] sp = cur.getValue().split("\n");
                        System.out.println("BFS find the shortest path expand state count  is " + sp.length);
                        return;
                    }
                    // not ask to putout
//                    System.out.println("BFS solution " + solutionCnt + " as follows");
//                    System.out.println(cur.getValue());
                    solutionCnt++;
                } else {
                    int num = matrix[x][y];
                    String pre = cur.getValue();
                    //left
                    if (y - num >= 0 && !pre.contains(x + "," + (y - num) + "\n")) {
                        queue.add(new Pair<>(x * n + (y - num), cur.getValue() + x + "," + (y - num) + "\n"));
                    }
                    //right
                    if (y + num < n && !pre.contains(x + "," + (y + num) + "\n")) {
                        queue.add(new Pair<>(x * n + (y + num), cur.getValue() + x + "," + (y + num) + "\n"));
                    }
                    //up
                    if (x - num >= 0 && !pre.contains((x - num) + "," + y + "\n")) {
                        queue.add(new Pair<>((x - num) * n + y, cur.getValue() + (x - num) + "," + y + "\n"));
                    }
                    //down
                    if (x + num < n && !pre.contains((x + num) + "," + y + "\n")) {
                        queue.add(new Pair<>((x + num) * n + y, cur.getValue() + (x + num) + "," + y + "\n"));
                    }
                }
                size--;
            }
        }
        if (mode == MODE_ALL) {
            System.out.println("the total number of unique path for " + n + "x" + n + " maze is " + solutionCnt);
        }
    }

    /**
     * Entry of dfs Search
     *
     * @param file name
     */
    public void dfsSearch(String file) {
        solutionCnt = 0;
        shortLength = Integer.MAX_VALUE;
        shortestPath = null;
        Pair<int[][], int[]> pair = fileProcess(file);
        dfsForMaze(pair.getValue(), pair.getKey(), MODE_ALL);
//        dfsForMaze(pair.getValue(), pair.getKey(), MODE_SHOREST);

    }

    /**
     * dfs for maze
     *
     * @param goal,  the position(x,y) of goal
     * @param matrix the maze matrix. the point of G,I use Integer.MAX_VALUE to indicate.
     * @param mode   , expansiable. when =MODE_ALL,means to find all unique paths. when =MODE_SHOREST mean to find the  unqiue path.
     */
    public void dfsForMaze(int[] goal, int[][] matrix, int mode) {
        n = matrix.length;
        dfs(matrix, 0, 0, goal, new HashSet<>(), "", mode);
        //for 3(a) to output the shortest path
        if (mode == MODE_SHOREST) {
            System.out.println("Shortest Path DFS for " + n + "x" + n + " maze :");
            System.out.println(shortestPath);
            String[] sp = shortestPath.split("\n");
            System.out.println("DFS find the shortest path expand state count  is " + sp.length);
        }
        if (mode == MODE_ALL) {
            System.out.println("the total number of unique path for " + n + "x" + n + " maze  is " + solutionCnt);
        }

    }

    /***
     * implementment of dfs.
     * @param matrix maze matrix
     * @param i, current cell position x.
     * @param j  current cell position y,
     * @param goal goal position
     * @param visited, mark the cells visited in a path.
     * @param pre, the pre path when get to (i,j)
     * @param mode  when =MODE_ALL,means to find all unique paths. when =MODE_SHOREST mean to find the  unqiue path
     */
    public void dfs(int[][] matrix, int i, int j, int[] goal, HashSet<Integer> visited, String pre, int mode) {
        if (i == goal[0] && j == goal[1]) {
            pre = pre + i + "," + j + "\n";
            if (solutionCnt == 0) {
                try {
                    PrintWriter out = null;
                    out = new PrintWriter(n + "x" + n + "maze-dfs.txt");
                    out.println(pre);
                    out.flush();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (mode == MODE_ALL) {
                /** not ask use the output all the paths. just the number.**/
                // System.out.println("DFS Solution " + solutionCnt + " as follows");
                //  System.out.println(pre);
                solutionCnt++;
            } else {
                if (pre.length() < shortLength) {
                    shortLength = pre.length();
                    shortestPath = pre;
                }
            }
            return;
        }

        visited.add(i * n + j);
        int num = matrix[i][j];
        // left
        if (j - num >= 0 && !visited.contains(i * n + (j - num))) {
            dfs(matrix, i, j - num, goal, visited, pre + (i + "," + j + "\n"), mode);
        }
        // right
        if (j + num < n && !visited.contains(i * n + (j + num))) {
            dfs(matrix, i, j + num, goal, visited, pre + (i + "," + j + "\n"), mode);
        }

        //up
        if (i - num >= 0 && !visited.contains((i - num) * n + j)) {
            dfs(matrix, i - num, j, goal, visited, pre + (i + "," + j + "\n"), mode);
        }
        // down
        if (i + num < n && !visited.contains((i + num) * n + j)) {
            dfs(matrix, i + num, j, goal, visited, pre + (i + "," + j + "\n"), mode);
        }
        visited.remove(i * n + j);
    }

    /**
     * file processing before doing search
     *
     * @param fileName fileName
     * @throws FileNotFoundException if file not found
     */
    public Pair<int[][], int[]> fileProcess(String fileName) {
        try {
            File f = new File(fileName);
            Scanner scanner = null;
            scanner = new Scanner(f);
            int index = f.getName().indexOf("x");
            int n = Integer.parseInt(f.getName().substring(0, index));
            int[][] matrix = new int[n][n];
            int i = 0;
            int[] goal = new int[2];
            while (scanner.hasNextLine()) {
                String s = scanner.nextLine();
                String[] sp = s.split(",");
                for (int j = 0; j < n; j++) {
                    if ("G".equals(sp[j])) {
                        goal[0] = i;
                        goal[1] = j;
                        matrix[i][j] = Integer.MAX_VALUE;
                    } else {
                        matrix[i][j] = Integer.parseInt(sp[j]);
                    }
                }
                i++;
            }
            return new Pair<>(matrix, goal);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return new Pair<>(null, null);

    }

    public static void main(String[] args) throws FileNotFoundException {
        MazeSearch search = new MazeSearch();
        search.dfsSearch("4x4Maze-maze.txt");
        search.bfsSearch("4x4Maze-maze.txt");

        search.dfsSearch("6x6Maze.txt");
        search.bfsSearch("6x6Maze.txt");

        search.dfsSearch("8x8-maze.txt");
        search.bfsSearch("8x8-maze.txt");

//        search.dfsSearch("12x12a-maze.txt");
//        search.bfsSearch("12x12a-maze.txt");
//
//        search.dfsSearch("12x12b-maze.txt");
//        search.bfsSearch("12x12b-maze.txt");
//
//
//        search.dfsSearch("25x25-maze.txt");
//        search.bfsSearch("25x25-maze.txt");
    }
}
