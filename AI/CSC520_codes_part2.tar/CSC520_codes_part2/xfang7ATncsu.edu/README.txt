The MazeSearch.java implement the bfs and bfs for all the questions and the heuristic function.
the bfsSearch(String file) is the entry method for bfs;
The dfsSearch(String file) is the entry for bfs;
We define 
    private static final int MODE_ALL = 0;
    private static final int MODE_SHOREST = 1;
For different mode to just find the shortest path or all the path. which can calculate the the number of unique  path. The expand state on specific path.