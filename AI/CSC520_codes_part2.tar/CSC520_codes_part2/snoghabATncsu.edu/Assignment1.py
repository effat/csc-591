import sys 


#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------ASTAR ALGORITHM AND NECESSARY CLASSES AND FUNCTIONS------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
class Node():


    def __init__(self, parent_Node=None, location_Node=None):
        self.g_func = 0
        self.h_func = 0
        self.f_func = 0
        
        self.parent = parent_Node
        self.location = location_Node

       

    def __eq__(self, second_Node):
        
        return self.location == second_Node.location

def finding_children(current_node , maze):
    
    children = []
    location  = maze[current_node.location[0]][current_node.location[1]]
    location_list = []
    location_list.append((0, -location))
    location_list.append((0, location))
    location_list.append((-location,0))
    location_list.append((location,0))

    for new_location in location_list: 
        # location of nearby nodes
        x_dir =current_node.location[0] + new_location[0]
        y_dir =current_node.location[1] + new_location[1]
        node_location = (x_dir, y_dir)

        # check the range of the maze and make sure that the nodes are within the range
        if node_location[0] > (len(maze) - 1) or node_location[0] < 0:
           continue
        if node_location[1] > (len(maze[len(maze)-1]) -1) or node_location[1] < 0:
           continue

        new_node = Node(current_node, node_location)

        # Add the node to the list of the children
        children.append(new_node)

    # return the children
    return children


def calculate_heuristic(current_node, end_node, maze):
    heuristicvalue =0
    nodeValue  = maze[current_node.location[0]][current_node.location[1]]
    diff_x = current_node.location[0] -end_node.location[0]
    diff_y = current_node.location[1] -end_node.location[1]

    if diff_x == 0:
        if nodeValue == diff_y:
            heuristicvalue = 1
        else:
            heuristicvalue = 2

    if diff_y == 0:
        if nodeValue == diff_x:
            heuristicvalue = 1
        else:
            heuristicvalue = 2


    if nodeValue == diff_y:
        heuristicvalue = 2
    else:
        heuristicvalue = 3


    if nodeValue == diff_y:
        if diff_x != 0:
            heuristicvalue = 2
        else:
            heuristicvalue = 3

    if nodeValue == diff_x:
        if diff_y != 0:
            heuristicvalue = 2
        else:
            heuristicvalue = 3
    return heuristicvalue

def astar(maze, start, end):
    global expansion_num
    # defining start and end nodes 
    start_node = Node(None, start)
    end_node = Node(None, end)
    start_node.g_func = start_node.h_func = start_node.f_func = 0
    end_node.g_func = end_node.h_func = end_node.f_func = 0

    # initialize the queue and visited nodes
    queue = []
    visited_queue = []

    # appending queue with the start node
    queue.append(start_node)

    # initializing the expansion numbers 
    expansion_num =0
    
    debug = 0

    # trying while the queue is empty
    while queue :

        # getting the node
        current_node = queue[0]
        index_current = 0

        if debug == 1:
            print(queue)

        for index, item in enumerate(queue):
            if item.f_func < current_node.f_func:
                index_current = index
                current_node = item
                
        if debug == 1:
            print("popped")

        # removing one item from the queue
        queue.pop(index_current)
        expansion_num = expansion_num+1
        
        # adding visited node
        visited_queue.append(current_node)

        # detectiong whether the goal is done
        if current_node == end_node:
            
            current = current_node
            # initialize the path
            path = []
            while current is not None:
                path.append(current.location)
                current = current.parent
            print(expansion_num)
            #  reversed the final path path
            return path[::-1] 

        # get the children
        children = finding_children(current_node, maze)
        flag =0
        # loop through children
        for child in children:

            for closed_child in visited_queue:
                if child == closed_child:
                    flag =1

            if flag ==1:
                flag=0
                continue


            # Create the f, g, and h values
            child.g_func = current_node.g_func + 1
            child.h_func =  calculate_heuristic(child,end_node,maze)
            child.f_func = child.g_func + child.h_func

            # Child is already in the open list
            for item in queue:
                if child == item:
                    if child.g_func > item.g_func:
                        continue

            # Add the child to the open list
            queue.append(child)





#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------BFS ALGORITHM AND NECESSARY CLASSES AND FUNCTIONS------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------


def BFS(maze, start, end):
   visited = []                # which nodes are visited
   queue = []                  # which is the next node to visit
   path = []
   global expansion_num
   start_node = Node(None, start)
   end_node = Node(None, end)

   queue.append(start_node)                  # enqueue start node
   visited.append(start_node)                # mark start node as visited

   expansion_num = 0
   while queue:                         # while queue is not empty
    current_node = queue.pop(0)            # ...get current node

    expansion_num = expansion_num+1
    path.append(current_node.location)

    current = current_node.location

    children = []
    number  = maze[current[0]][current[1]]
    for new_location in [(0, -number), (0, number), (-number, 0), (number, 0)]: # Adjacent squares
        

        # Get node location
        node_location = (current[0] + new_location[0], current[1] + new_location[1])

        # Make sure within range
        if node_location[0] > (len(maze) - 1) or node_location[0] < 0 or node_location[1] > (len(maze[len(maze)-1]) -1) or node_location[1] < 0:
           continue


        # Create new node
        new_node = Node(current_node, node_location)

        # Append
        children.append(new_node)


    for child in children:        # ...for each neighbor of current
        if child not in visited:        # ......if neighbor not visited
            visited.append(child)       # .........mark as visited
            queue.append(child)         # .........add it to the queue
            if child == end_node:            # .........if target found stop



               path1 = []
               current = child
               while current is not None:
                  path1.append(current.location)
                  current = current.parent


                
               #print("FOUND:", end)
               #print(path1[::-1])
               #print(len(path1))
               print(expansion_num)
               return path1[::-1]

#                sys.exit(0)
#print("Not found")
#print(path)





#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------DFS ALGORITHM AND NECESSARY CLASSES AND FUNCTIONS------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------


def DFS(maze, start, end):
   visited = []                # which nodes are visited
   queue = []                  # which is the next node to visit
   path = []
   global expansion_num
   start_node = Node(None, start)
   end_node = Node(None, end)

   expansion_num=0

   queue.append(start_node)                  # enqueue start node
   visited.append(start_node)                # mark start node as visited
   while queue:                         # while queue is not empty
    current_node = queue.pop()            # ...get current node

    expansion_num = expansion_num+1
    path.append(current_node.location)

    current = current_node.location

    children = []
    number  = maze[current[0]][current[1]]
    for new_location in [(0, -number), (0, number), (-number, 0), (number, 0)]: # Adjacent squares
        

        # Get node location
        node_location = (current[0] + new_location[0], current[1] + new_location[1])

        # Make sure within range
        if node_location[0] > (len(maze) - 1) or node_location[0] < 0 or node_location[1] > (len(maze[len(maze)-1]) -1) or node_location[1] < 0:
           continue


        # Create new node
        new_node = Node(current_node, node_location)

        # Append
        children.append(new_node)


    for child in children:        # ...for each neighbor of current
        if child not in visited:        # ......if neighbor not visited
            visited.append(child)       # .........mark as visited
            queue.append(child)         # .........add it to the queue
            if child == end_node:            # .........if target found stop



               path1 = []
               current = child
               while current is not None:
                  path1.append(current.location)
                  current = current.parent


                
               #print("FOUND:", end)
               #print(path1[::-1])
               #print(len(path1))
               print(expansion_num)
               return path1[::-1]


#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------BESTFIRST ALGORITHM AND NECESSARY CLASSES AND FUNCTIONS------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------


def Bestfirst(maze, start, end):
    
    global expansion_num
    # defining start and end nodes 
    start_node = Node(None, start)
    end_node = Node(None, end)
    start_node.g_func = start_node.h_func = start_node.f_func = 0
    end_node.g_func = end_node.h_func = end_node.f_func = 0

    # initialize the queue and visited nodes
    queue = []
    visited_queue = []

    # appending queue with the start node
    queue.append(start_node)

    # initializing the expansion numbers 
    expansion_num =0

    # trying while the queue is empty
    while queue :

        # getting the node
        current_node = queue[0]
        index_current = 0
        for index, item in enumerate(queue):
            if item.f_func < current_node.f_func:
                current_node = item
                index_current = index

        # removing one item from the queue
        queue.pop(index_current)
        expansion_num = expansion_num+1


        visited_queue.append(current_node)

        # detectiong whether the goal is done
        if current_node == end_node:
            
            current = current_node
            # initialize the path
            path = []
            while current is not None:
                path.append(current.location)
                current = current.parent
            print(expansion_num)
            #  reversed the final path path
            return path[::-1] 

        # get the children
        children = finding_children(current_node, maze)
        flag =0
        # loop through children
        for child in children:

            for closed_child in visited_queue:
                if child == closed_child:
                    flag =1

            if flag ==1:
                flag=0
                continue


            # Create the f, g, and h values
            child.g_func = 0
            child.h_func =  calculate_heuristic(child,end_node,maze)
            child.f_func = child.h_func

            # Child is already in the open list
            for item in queue:
                if child == item :
                    if child.g_func > item.g_func:
                        continue

            # Add the child to the open list
            queue.append(child)



#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------ALL PATHS ALGORITHM AND NECESSARY CLASSES AND FUNCTIONS------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------

def visitedNodeInPath(paths, child):
    visited = 0
    for node in paths:
        if child.location == node.location:
            visited =1
    return visited

def printPath(paths):
    for path in paths:
        print(path.location)

def AllPossiblePaths(maze, start, end):
   visited = []                # which nodes are visited
   queue = []                  # which is the next node to visit
   path = []
   FinalPaths = []
   global expansion_num
   AllPaths= []

   start_node =[]
   start_node.append( Node(None, start))
   end_node = Node(None, end)


   
   FinalPaths.append(start_node)
   
   
   while FinalPaths:                         # while queue is not empty

    current_path =[]
    

    # ...get current node
    temp = []
    temp.append(FinalPaths.pop(0))
    expansion_num = expansion_num +1
    for item in temp:
        current_path.append(item)   

    current_node2= (current_path[len(current_path)-1])
    
    #print("popped = ")
    #print(current_node2[len(current_node2)-1].location) 
    
    current_node = current_node2[len(current_node2)-1]
    #path.append(current_node.location)
    
    current = current_node.location

    children = []
    number  = maze[current[0]][current[1]]
    for new_location in [(0, -number), (0, number), (-number, 0), (number, 0)]: # Adjacent squares
        

        # Get node location
        node_location = (current[0] + new_location[0], current[1] + new_location[1])

        # Make sure within range
        #if current[0] ==3 and current[1]==5:
        #    k=1

        if node_location[0] > (len(maze) - 1) or node_location[0] < 0 or node_location[1] > (len(maze[len(maze)-1]) -1) or node_location[1] < 0:
           continue


        # Create new node
        new_node = Node(current_node, node_location)

        # Append
        children.append(new_node)
        
        #temp_path = current_node2.copy()
        temp_path = list(current_node2)
        
        
            

        if visitedNodeInPath(temp_path,new_node) == 1:
            a=1
             
        else:
            #check goal
            temp_path = list(current_node2)
            temp_path.append(new_node)
            if new_node.location == end_node.location:
                AllPaths.append(temp_path)
                #printPath(temp_path)
                #print("----------------------------------------------------------------------------------------------------------------------")

            else:
                
                FinalPaths.append(temp_path)

   return AllPaths     
        

    
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------READING AND WRITING AND CALLING FUNTIONS FOR EACH ALGORITHM----------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------------------------------------------------------------



# the following lines read the input file and store them in a 2D list so we can use it later.
# it also read the second argument from the cmd which is the file name plus extention such as test.text
readFile = open(sys.argv[2],'r')
lines = readFile.readlines()
grid = []
maze = []
for line in lines:
   line.rstrip("\n")
   grid.append(line)

Ydim = len(grid)

for i in range(0,Ydim):
   grid[i] = grid[i][:-1]
   grid[i] =grid[i].split(',')

Xdim = len(grid[0])    
goalX=0
goalY=0

# the following lines locate the location of goal node and store the values in end variable
for i in range(0,Ydim):
    for j in range(0,Xdim):
        if grid[i][j] == 'G':
            grid[i][j] = 0
            goalX = i
            goalY = j
        else:
            grid[i][j]= int(grid[i][j])

# the following two variables store the location of start and end in the maze. 
# note that end location is already readed from the input file 
start = (0, 0)
end = (goalX, goalY)


# this variable is used to record the expansion numbers and print them in the output file
expansion_num =0

# this line gets the first argument in the command line and creat an output file with the same name. 
# note that the first argument of this program is the algorithm type which can be selected from 'bfs','dfs','astar','bestfirst'
# the out put file is consisted of the number of expansions and paths beside number of expansions for all paths and all unique paths 
outputFile = open(sys.argv[1]+".txt", "w")

# these lines calls astar function which runs the astar algorithm and write the outputs in a file with simillar name
if(sys.argv[1] == 'astar'):
    print("A Star")
    path = astar(grid, start, end)
    print(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("-----------------------------NUMBER OF EXPANSIONS FOR A STAR------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write(str(expansion_num)+"\n")
    #outputFile.writelines(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("------------------------------------PATH USING A STAR-------------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    for i in range(0,len(path)):
        for j in range(0,2):
            outputFile.write(str(path[i][j]))
            if j == 0:
                outputFile.write(",")
        outputFile.write("\n")
    print("------------------------------------------------")


 
# these lines calls bfs function which runs the bfs algorithm and write the outputs in a file with simillar name
if(sys.argv[1] == 'bfs'):
    print("BFS")
    path = BFS(grid, start, end)
    print(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("------------------------------NUMBER OF EXPANSIONS FOR BFS--------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write(str(expansion_num)+"\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("-------------------------------------PATH USING BFS---------------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    #outputFile.writelines(path)
    for i in range(0,len(path)):
        for j in range(0,2):
            outputFile.write(str(path[i][j]))
            if j == 0:
                outputFile.write(",")
        outputFile.write("\n")
    print("------------------------------------------------")



# these lines calls dfs function which runs the dfs algorithm and write the outputs in a file with simillar name
if(sys.argv[1] == 'dfs'):
    print("DFS")
    path = DFS(grid, start, end)
    print(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("------------------------------NUMBER OF EXPANSIONS FOR DFS--------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write(str(expansion_num)+"\n")
    #outputFile.writelines(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("-------------------------------------PATH USING DFS---------------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    for i in range(0,len(path)):
        for j in range(0,2):
            outputFile.write(str(path[i][j]))
            if j == 0:
                outputFile.write(",")
        outputFile.write("\n")
    print("------------------------------------------------")


# these lines calls bestfirst function which runs the bestfirst algorithm and write the outputs in a file with simillar name
if(sys.argv[1] == 'bestfirst'):
    print("Best First")
    path = BFS(grid, start, end)
    print(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("---------------------------NUMBER OF EXPANSIONS FOR Best First----------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write(str(expansion_num)+"\n")
    #outputFile.writelines(path)
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    outputFile.write("---------------------------------PATH USING BEST FIRST------------------------------------------\n")
    outputFile.write("------------------------------------------------------------------------------------------------\n")
    for i in range(0,len(path)):
        for j in range(0,2):
            outputFile.write(str(path[i][j]))
            if j == 0:
                outputFile.write(",")
        outputFile.write("\n")
    print("------------------------------------------------")




#print("All Possible Paths")


# these lines calls allpossiblepaths function which runs the bfs algorithm and write all the possible paths and the number of expansions in the outputfile
outputFile.write("------------------------------------------------------------------------------------------------\n")
outputFile.write("------------------------------------ALL POSSIBLE PATHS------------------------------------------\n")
outputFile.write("------------------------------------------------------------------------------------------------\n")
path = AllPossiblePaths(grid, start, end)
for i in range(0,len(path)):
    for k in range (0, len(path[i])):

       outputFile.write(str(path[i][k].location))
       if j == 0:
           outputFile.write(",")
    outputFile.write("\n")

outputFile.write("------------------------------------------------------------------------------------------------\n")
outputFile.write("----------------------------NUMBER OF EXPANSIONS FOR ALL PATHS----------------------------------\n")
outputFile.write("------------------------------------------------------------------------------------------------\n")
outputFile.write(str(expansion_num)+"\n")
