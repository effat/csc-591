What is in the folder?===============================================================================================
- Report_Assignment_1.pdf contains answers for the questions and description of the code
Within the Code folder:
- maze_solver.py contains solution to the coding problem
- TrainingMazes folder contains the input mazes provided to us
=====================================================================================================================
Prerequisites =======================================================================================================
- Platform - Windows 10
- Python 3.6.2
- Visual Studio Code 1.27.2 to view the code (Optional). Different editor can also be used.
=====================================================================================================================
To run the maze_solver.py ===========================================================================================
- open cmd
- go to the folder where you saved the maze_solver.py file using cd command
- execute the following command:

    python maze_solver.py algorithm_name path_to_input_file

    Example: python maze_solver.py BFS TrainingMazes/4x4Maze-maze.txt
  
  Executing the command will create a output.txt file in the folder where maze_solver.py was saved.
=====================================================================================================================
Understanding output.txt ============================================================================================
- The output.txt file is quite self explanatory
- For the input file it will generate the following in the given order:
  1. The shortest path found using the algorithm specified in the command and the count of expanded states
     in this case
  
  For any 6x6 or 8x8 maze the output.txt file will also contain:
  2. All unique paths from the start state([0,0]) to the goal state(The square containing letter 'G')
  3. The count of expanded states when finding all unique paths
======================================================================================================================