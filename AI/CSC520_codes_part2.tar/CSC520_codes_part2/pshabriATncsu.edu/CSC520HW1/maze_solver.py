import sys
import math
# global variables
# a 2d array that contains the maze
maze=[] 
# a 2d array that contains the current cost of each state/square in the grid. used in best first search and A*
# stores heuristic cost for Best first searh and f-score for A* search
cost_matrix = []
# g_score_matrix stores the g_score(actual distance from the start node to a node) of a node for A* algorithm
g_score_matrix = []
# a 2d array that contains pairs indicating the coordinate of the current parent of each state/square in the grid 
parent_matrix = []
# a 2d array that contains values indicating if a square is not-visited(0), visited(1) or expanded(2)
visited_flags = []
# a pair that contains the x and y value of the goal square
goal_coordinate = ()
# number of rows in the maze
maze_row = int()
# number of cols in the maze
maze_col = int()
# max_jump is the largest jump possible within the maze
max_jump = int()
# output file 
output_file= open("output.txt","w+")


# read_file function takes the filename as input, reads it, creates the input maze (a two dimensional array) 
# from the content of the file and returns it
def read_file(filename):
    file=open(filename,"r")
    file=file.read().split("\n")
    for row in file:
        if row!="":
            row=row.split(",")
            maze.append(row)

# initialization - initialize the visited_flags, parent_matrix and the cost_matrix with the same number of rows and cols as the mazes
# initially the visited_flags array contains 0s, parent_matrix contains(-1,-1) and cost_matrix_contains 0s in all squares 
def initialization():
    for i in range (0, maze_row):                               
        new_row_visited = [] 
        new_row_parent = []
        new_row_cost = []
        new_row_g = []               
        for j in range (0, maze_col):    
            new_row_visited.append(0)
            new_row_parent.append((-1,-1))
            new_row_cost.append(0)
            new_row_g.append(0)        
        visited_flags.append(new_row_visited)
        parent_matrix.append(new_row_parent)
        cost_matrix.append(new_row_cost)
        g_score_matrix.append(new_row_g)

# clears data from visited_flags, parent_matrix and cost_matrix and assigns them with the initial value
def clear_data():
    for i in range (0, maze_row):
        for j in range (0, maze_col):
            visited_flags[i][j] = 0
            parent_matrix[i][j] = (-1, -1)
            cost_matrix[i][j] = 0
            g_score_matrix[i][j] = 0

# A heuristic function that estimates the cost of traversing from one state to another
# for the estimation of cost euclidean distance is used
def heuristic(start, goal):
    # start and goal are coordinates of the two states
    euclid_dist = math.sqrt(sum([(a - b) ** 2 for a, b in zip(start, goal)]))
    heuristic_cost = euclid_dist/max_jump
    return heuristic_cost
    

    
# bfs_dfs implements the Breadth first search and Depth first search depending on the value of parameter 'type'
# If the value of 'type' is 1 it performs bfs, if 'type' is 2, the method perform dfs
def bfs_dfs(type):
    if type == 1:
        output_file.write("Solving maze using BFS:\n")
    else:
        output_file.write("Solving maze using DFS:\n")
    # expanded_states stores the states that are expanded. i.e, whose successors are queued
    expanded_states = list()
    # if the input constructs a valid 2d array(maze) then the search is performed
    if maze_row != 0:
        queue = list()
        # enqueue the root
        root = (0, 0)
        queue.append(root)
        while len(queue) != 0:
            # pop the pair at the top of the list if type=1(bfs implemented using queue) and from bottom of the list if type=2(dfs implemented using stack)
            if type == 2:
                curr_pos = queue.pop(len(queue)-1)
            else:
                curr_pos = queue.pop(0)
            
            # mark the pair at the top as expanded
            visited_flags[curr_pos[0]][curr_pos[1]] = 2
            # content_curr_pos contains the content of dequeued top
            content_curr_pos = maze[curr_pos[0]][curr_pos[1]]
            # if the current state is not the goal state, type convert it's content
            if content_curr_pos != 'G':
                content_curr_pos = int(content_curr_pos)
            else:
                # if the current state is the goal state
                # print the shortest path
                print_shortest_path()
                # print the number of states expanded by the algorithm when finding the path
                output_file.write("Count of expanded states:\n")
                output_file.write(str(len(expanded_states)) + "\n")
                return

            # if the current state is not a goal state append it to the list of expanded states and expand its successors
            expanded_states.append(curr_pos)
            
            # for each successor mark them as visited i.e, discovered but not expanded, assign the current state as their parent and append them to the queue
            # left_child
            if curr_pos[1]-content_curr_pos >= 0 and visited_flags[curr_pos[0]][curr_pos[1]-content_curr_pos] == 0:
                visited_flags[curr_pos[0]][curr_pos[1]-content_curr_pos] = 1
                left_child = (curr_pos[0], curr_pos[1]-content_curr_pos)
                parent_matrix[left_child[0]][left_child[1]] = curr_pos
                queue.append(left_child)
                
            # right_child
            if curr_pos[1]+content_curr_pos < maze_col and visited_flags[curr_pos[0]][curr_pos[1]+content_curr_pos] == 0:
                visited_flags[curr_pos[0]][curr_pos[1]+content_curr_pos] = 1
                right_child = (curr_pos[0], curr_pos[1]+content_curr_pos)
                parent_matrix[right_child[0]][right_child[1]] = curr_pos
                queue.append(right_child)
                
            # top_child
            if curr_pos[0]-content_curr_pos >= 0 and visited_flags[curr_pos[0]-content_curr_pos][curr_pos[1]] == 0:
                visited_flags[curr_pos[0]-content_curr_pos][curr_pos[1]] = 1
                top_child = (curr_pos[0]-content_curr_pos, curr_pos[1])
                parent_matrix[top_child[0]][top_child[1]] = curr_pos
                queue.append(top_child)
                
            # bottom_child
            if curr_pos[0]+content_curr_pos < maze_row and visited_flags[curr_pos[0]+content_curr_pos][curr_pos[1]] == 0:
                visited_flags[curr_pos[0]+content_curr_pos][curr_pos[1]] = 1
                bottom_child = (curr_pos[0]+content_curr_pos, curr_pos[1])
                parent_matrix[bottom_child[0]][bottom_child[1]] = curr_pos
                queue.append(bottom_child)

# best_first_search() implements the Best First Search algorithm to find out the shortest path to the goal state
def best_first_search():
    output_file.write("Solving maze using Best First Search:\n")
    # if the input constructs a valid 2d array(maze) then the search is performed
    if maze_row != 0:
        # open list contains coordinates of those states/squares which are yet to be expanded
        open_list = list()
        # closed list contains coordinates of those states/squares which are already expanded and no better paths to these states are found
        closed_list = list()
        # expanded_states contains the list of states that are expanded atleast ones. This list can contain the same state more than once
        expanded_states = list()

        # enqueue the start state and add it to the open_list
        start = (0,0)
        open_list.append(start)

        while len(open_list) != 0:
            # pop the coordinate with minimum cost
            curr_pos = pop_min(open_list)
            # if the popped state is the goal state then write the shortest path and count of expanded state to the output file
            if maze[curr_pos[0]][curr_pos[1]] == 'G':
                # print the shortest path
                print_shortest_path()
                # print the number of states expanded by the algorithm when finding the path
                output_file.write("Count of expanded states:\n")
                output_file.write(str(len(expanded_states)) + "\n")
                return
            else:
                # if the current state is not the goal state then append it to expanded_states list and assign its value to content_curr_pos
                expanded_states.append(curr_pos)
                content_curr_pos = int(maze[curr_pos[0]][curr_pos[1]])
                # expand current state and add each of it's successor to successor queue
                successor_queue = list()
                # left_child
                if curr_pos[1]-content_curr_pos >= 0:
                    left_child = (curr_pos[0], curr_pos[1]-content_curr_pos)
                    successor_queue.append(left_child)
                # right_child
                if curr_pos[1]+content_curr_pos < maze_col:
                    right_child = (curr_pos[0], curr_pos[1]+content_curr_pos)
                    successor_queue.append(right_child)
                # top_child
                if curr_pos[0]-content_curr_pos >= 0:
                    top_child = (curr_pos[0]-content_curr_pos, curr_pos[1])
                    successor_queue.append(top_child)
                # bottom_child
                if curr_pos[0]+content_curr_pos < maze_row:
                    bottom_child = (curr_pos[0]+content_curr_pos, curr_pos[1])
                    successor_queue.append(bottom_child)
                
                for successor in successor_queue:
                    # for each state it's cost is the heauristic cost from that state to the goal state
                    successor_cost = heuristic(successor, goal_coordinate)
                    # if the current heuristic cost of the successor being examined is greater than the newly calculated cost and
                    # the state is already in the open list then update the value in cost_matrix and parent_matrix
                    if successor in open_list:
                        if cost_matrix[successor[0]][successor[1]] > successor_cost:
                            cost_matrix[successor[0]][successor[1]] = successor_cost
                            parent_matrix[successor[0]][successor[1]] = curr_pos
                      
                    elif successor in closed_list:
                         # if the current heuristic cost of the successor being examined is greater than the newly calculated cost and
                         # the state is in the closed list then move it to open list and update the value in cost_matrix and parent_matrix
                        
                        if cost_matrix[successor[0]][successor[1]] > successor_cost:
                            closed_list.remove(successor)
                            open_list.append(successor)
                            cost_matrix[successor[0]][successor[1]] = successor_cost
                            parent_matrix[successor[0]][successor[1]] = curr_pos
                    else:
                        # if the successor being examined is a newly discovered state then append it to the open list and assign its corresponding
                        # cost and parent to cost_matrix and parent_matrix respectively
                        open_list.append(successor)
                        cost_matrix[successor[0]][successor[1]] = successor_cost
                        parent_matrix[successor[0]][successor[1]] = curr_pos
                # after examining each of the successors add current state to the closed list
                closed_list.append(curr_pos)
        # if the last popped state is not the goal state, then it means goal state is not found
        if maze[curr_pos[0]][curr_pos[1]] != 'G':
            output_file.write("Goal is not found!!!\n") 
    else:
        return
# a_star() implements the A* algorithm to find out the shortest path to the goal state. This algorithm is the same as Best First Search 
# except for the calculation of state cost
def a_star():
    output_file.write("Solving maze using A*:\n")
    if maze_row != 0:
        open_list = list()
        closed_list = list()
        expanded_states = list()
        start = (0,0)
        open_list.append(start)
        while len(open_list) != 0:
            # pop the coordinate with minimum cost
            curr_pos = pop_min(open_list)
            if maze[curr_pos[0]][curr_pos[1]] == 'G':
                # print the shortest path
                print_shortest_path()
                # print the number of states expanded by the algorithm when finding the path
                output_file.write("Count of expanded states:\n")
                output_file.write(str(len(expanded_states)) + "\n")
                return
            else:
                expanded_states.append(curr_pos)
                content_curr_pos = int(maze[curr_pos[0]][curr_pos[1]])
                successor_queue = list()
                # left_child
                if curr_pos[1]-content_curr_pos >= 0:
                    left_child = (curr_pos[0], curr_pos[1]-content_curr_pos)
                    successor_queue.append(left_child)
                # right_child
                if curr_pos[1]+content_curr_pos < maze_col:
                    right_child = (curr_pos[0], curr_pos[1]+content_curr_pos)
                    successor_queue.append(right_child)
                # top_child
                if curr_pos[0]-content_curr_pos >= 0:
                    top_child = (curr_pos[0]-content_curr_pos, curr_pos[1])
                    successor_queue.append(top_child)
                # bottom_child
                if curr_pos[0]+content_curr_pos < maze_row:
                    bottom_child = (curr_pos[0]+content_curr_pos, curr_pos[1])
                    successor_queue.append(bottom_child)
                
                for successor in successor_queue:
                    # *** only the cost calculation is different from Best First Search ***
                    # cost of each state is the sum of cost to traverse to its parent from the start state, cost from the parent to that state
                    # and heuristic cost from the state to the goal state
                    successor_cost = g_score_matrix[curr_pos[0]][curr_pos[1]] + 1 + heuristic(successor, goal_coordinate)
                    if successor in open_list:
                        if cost_matrix[successor[0]][successor[1]] > successor_cost:
                            cost_matrix[successor[0]][successor[1]] = successor_cost
                            g_score_matrix[successor[0]][successor[1]] = g_score_matrix[curr_pos[0]][curr_pos[1]] + 1
                            parent_matrix[successor[0]][successor[1]] = curr_pos
                      
                    elif successor in closed_list:
                        
                        if cost_matrix[successor[0]][successor[1]] > successor_cost:
                            closed_list.remove(successor)
                            open_list.append(successor)
                            cost_matrix[successor[0]][successor[1]] = successor_cost
                            g_score_matrix[successor[0]][successor[1]] = g_score_matrix[curr_pos[0]][curr_pos[1]] + 1
                            parent_matrix[successor[0]][successor[1]] = curr_pos
                    else:
                        open_list.append(successor)
                        cost_matrix[successor[0]][successor[1]] = successor_cost
                        g_score_matrix[successor[0]][successor[1]] = g_score_matrix[curr_pos[0]][curr_pos[1]] + 1
                        parent_matrix[successor[0]][successor[1]] = curr_pos
                closed_list.append(curr_pos)
        if maze[curr_pos[0]][curr_pos[1]] != 'G':
            output_file.write("Goal state not found!!!") 
    else:
        return

def get_sort_key_cost(coordinate):
    return cost_matrix[coordinate[0]][coordinate[1]]
def pop_min(open_list):
    open_list.sort(key = get_sort_key_cost)
    return open_list.pop(0)


# count_expanded_states keeps track of the expanded states when finding all unique paths from the start state to the goal state
count_expanded_states = 0
path_count = 1
# method to print all unique paths
def print_all_unique_Paths(source, destination): 
    # This function runs only for 6x6 and 8x8 maze
    if len(maze) != 6 and len(maze) !=8:
        return
    output_file.write("Printing all unique paths:\n")
    # Mark all the vertices as not visited 
    for i in range (0, len(maze)):
        for j in range (0, len(maze[0])):
            visited_flags[i][j] = 0
    # Create an array to store paths 
    path = [] 
    # Call the recursive helper function to print all paths 
    all_unique_paths_util(source, destination, path)
    # write the count of expanded states
    output_file.write("Count of Expanded States when Finding All Unique Paths:" + str(count_expanded_states) +"\n")

def all_unique_paths_util(source, destination, path):
    # Mark the current node as visited and store in path 
    visited_flags[source[0]][source[1]] = 1
    path.append(source)
    
    # If current vertex is same as destination, then print 
    # current path[] 
    if source == destination:
        global path_count 
        output_file.write("Unique path "+ str(path_count) + ":\n")
        path_count += 1
        output_file.write(str(path) + "\n") 
    else: 
        # increment the count of expanded states
        global count_expanded_states
        count_expanded_states+=1
        # If current vertex is not destination 
        # Recur for all the vertices adjacent to this vertex 
        content_curr_pos = int(maze[source[0]][source[1]])
        # left_child
        if source[1]-content_curr_pos >= 0 and visited_flags[source[0]][source[1]-content_curr_pos] == 0:
            left_child = (source[0], source[1]-content_curr_pos)
            all_unique_paths_util(left_child, destination, path)
          
        # right_children
        if source[1]+content_curr_pos < maze_col and visited_flags[source[0]][source[1]+content_curr_pos] == 0:
            right_child = (source[0], source[1]+content_curr_pos)
            all_unique_paths_util(right_child, destination, path)
            
                
        # top_children
        if source[0]-content_curr_pos >= 0 and visited_flags[source[0]-content_curr_pos][source[1]] == 0:
            top_child = (source[0]-content_curr_pos, source[1])
            all_unique_paths_util(top_child, destination, path)
            
                
        # bottom_children
        if source[0]+content_curr_pos < maze_row and visited_flags[source[0]+content_curr_pos][source[1]] == 0:
            bottom_child = (source[0]+content_curr_pos, source[1])
            all_unique_paths_util(bottom_child, destination, path)
         
                      
    # Remove current vertex from path[] and mark it as unvisited 
    path.pop() 
    visited_flags[source[0]][source[1]] = 0
      
   
# utility functions
def print_shortest_path():
    output_file.write("Shortest Path:\n")
    shortest_path = list()
    shortest_path.append(goal_coordinate)
    parent = parent_matrix[goal_coordinate[0]][goal_coordinate[1]]
    shortest_path.append(parent)
    while parent != (0,0):
        parent = parent_matrix[parent[0]][parent[1]]
        shortest_path.append(parent)
    output_file.write(str(list(reversed(shortest_path))) + "\n")


# Execute the solver------------------------------------------------------------------------------------
#read the input file
if len(sys.argv) == 3:
    algorithm = sys.argv[1]
    filename = sys.argv[2]
    read_file(filename)
    # get the maze row and maze col
    maze_row = len(maze)
    maze_col = len(maze[0])
    output_file.write("Calculating output for a " + str(maze_row) + "x" + str(maze_col) + " maze:\n")
    # find out the coordinate of the goal state and the max_jump
    max_jump = 0
    for i in range (0, maze_row):                                        
        for j in range (0, maze_col):     
            if maze[i][j] == 'G':
                goal_coordinate = (i,j) 
            else:
                if int(maze[i][j]) > max_jump:
                    max_jump = int(maze[i][j])

    initialization()
    if algorithm == "BFS":
        # BFS
        bfs_dfs(1)
    elif algorithm == "DFS":
        # DFS
        clear_data()
        bfs_dfs(2)
    elif algorithm == "BestFirst":
        # Best First Search
        clear_data()
        best_first_search()
    elif algorithm == "AStar":
        # A*
        clear_data()
        a_star()
    # print all unique paths from start state to goal state and the count of expanded states in this process
    # print_all_unique_Paths(source, destination) will be executed only for 6x6 and 8x8 mazes
    clear_data()
    print_all_unique_Paths((0,0), goal_coordinate)


else:
    print("please provide correct number of arguments(Algorithm and input filename)")







