import java.io.*;
import java.lang.Exception;
import java.lang.Integer;
import java.lang.StringBuffer;
import java.util.ArrayList;
import java.util.PriorityQueue;

public class Search{
	/**Class containing main method and input file
	 * parsing to graph
	 */
	public static void main(String args[]){
		if (args.length < 2){
			System.out.println("Error: include search type and test file path name");
			System.exit(0);
		}
		
		try{
			/**Parsing input*/
			BufferedReader in = new BufferedReader(new FileReader(args[1]));
			String mapInput;
			String[] splitInput;
			ArrayList<int[]> tempMap = new ArrayList<int[]>();
			int goalRow = 0;
			int goalColumn = 0;
			while((mapInput = in.readLine()) != null){
				splitInput = mapInput.split(",");
				int[] holding = new int[splitInput.length];
				for(int i = 0; i < splitInput.length; i++)
				{
					if (splitInput[i].equals("G")){
						splitInput[i] = "-1";
						goalColumn = i;
					}
					holding[i] = Integer.parseInt(splitInput[i]);
				}
				tempMap.add(holding);
				goalRow = tempMap.indexOf(holding);
			}
			in.close();
			int width = tempMap.get(0).length;
			int height = tempMap.size();
			
			/**Creating graph*/
			Node[][] initial = new Node[height][width];
			for (int i = 0; i < height; i++){
				for (int j = 0; j < width; j++){
					Node current = new Node(tempMap.get(i)[j], i, j, false);
					initial[i][j] = current;
				}
			}
			
			Map finalMap = new Map(initial, goalRow, goalColumn);
			String answer = new String();
			
			int counter = 1;
			if (args[0].equals("dfs")){
				StringBuffer starting = new StringBuffer();
				answer = finalMap.dfsSearch(initial[0][0], starting, answer, counter);
			}
			else if (args[0].equals("bfs")){
				ArrayList<Node> currentRow = new ArrayList<Node>();
				currentRow.add(initial[0][0]);
				ArrayList<StringBuffer> pathList = new ArrayList<StringBuffer>();
				answer = finalMap.bfsSearch(currentRow, pathList, answer);
			}
			else if (args[0].equals("best-first")){
				StringBuffer holdAnswer = new StringBuffer();
				answer = finalMap.bestFirstSearch(initial[0][0], holdAnswer, answer);
			}
			else if (args[0].equals("astar")){
				PriorityQueue<Node> allOptions = new PriorityQueue<Node>();
				int currentPath = 0;
				answer = finalMap.aStarSearch(initial[0][0], allOptions, answer, currentPath);
			}
			else{
				System.out.println("Error: please choose one of the following: dfs, bfs, best-first, astar.");
				System.exit(0);
			}
			
			System.out.println(answer);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}
