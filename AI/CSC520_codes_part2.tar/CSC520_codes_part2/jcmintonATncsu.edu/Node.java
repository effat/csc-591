public class Node implements Comparable<Node>{
	/** Class to contain graph node move cost, graph position, and
	 * heuristic information
	 */
	private int moveCost;
	private int heuristic;
	private int gofn;
	private int row;
	private int column;
	private boolean used;
	private boolean heuristicTest;
	
	private Node prevNode;
	
	/**Constructors*/
	Node(){
		setMoveCost(0);
		setHeuristic(-1);
		setGofN(0);
		setRow(-1);
		setColumn(-1);
		setUsed(false);
		setHeuristicTest(false);
		setPrevNode(null);
	}
	
	Node(int curCost, int curRow, int curColumn, boolean isUsed){
		setMoveCost(curCost);
		setHeuristic(-1);
		setGofN(0);
		setRow(curRow);
		setColumn(curColumn);
		setUsed(isUsed);
		setHeuristicTest(false);
		setPrevNode(null);
	}
	
	Node(Node aNode){
		setMoveCost(aNode.getMoveCost());
		setHeuristic(aNode.getHeuristic());
		setGofN(aNode.getGofN());
		setRow(aNode.getRow());
		setColumn(aNode.getColumn());
		setUsed(aNode.getUsed());
		setHeuristicTest(aNode.getHeuristicTest());
		setPrevNode(aNode.getPrevNode());
	}
	
	/**Getters*/
	public int getMoveCost(){
		return moveCost;
	}
	
	public int getHeuristic(){
		return heuristic;
	}
	
	public int getGofN() {
		return gofn;
	}
	
	public int getRow(){
		return row;
	}
	
	public int getColumn(){
		return column;
	}
	
	public boolean getUsed(){
		return used;
	}
	
	public boolean getHeuristicTest(){
		return heuristicTest;
	}
	
	public Node getPrevNode() {
		return prevNode;
	}
	
	/**Setters*/
	public void setMoveCost(int curCost){
		moveCost = curCost;
	}
	
	public void setHeuristic(int curHeuristic){
		heuristic = curHeuristic;
	}
	
	public void setGofN(int curGofN) {
		gofn = curGofN;
	}
	
	public void setRow(int curRow){
		row = curRow;
	}
	
	public void setColumn(int curColumn){
		column = curColumn;
	}
	
	public void setUsed(boolean isUsed){
		used = isUsed;
	}
	
	public void setHeuristicTest(boolean isTested){
		heuristicTest = isTested;
	}
	
	public void setPrevNode(Node aNode) {
		prevNode = aNode;
	}

	/** Implementation of Comparable interface,
	 * used to sort priority queue for A* search
	 * Inputs: Node aNode
	 * Outputs: -1 if this is less than aNode, 1 if this
	 * is greater than aNode, 0 if the relevant nodes are equal
	 * Note: Does not implement true equality. Only g(n) and h(n)
	 * are considered.
	 */
	public int compareTo(Node aNode) {
		if (getHeuristic() + getGofN() < aNode.getHeuristic() + aNode.getGofN()) {
			return -1;
		}
		if (getHeuristic() + getGofN() > aNode.getHeuristic() + aNode.getGofN()) {
			return 1;
		}
		return 0;
	}
}
