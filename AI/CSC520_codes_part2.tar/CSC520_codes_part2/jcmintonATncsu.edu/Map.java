import java.lang.StringBuffer;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Stack;

/**Class to contain graph functions
 */
public class Map{
	private Node[][] total;
	private int goalRow;
	private int goalColumn;
	
	/**Constructors*/
	Map(){
		setTotal(null);
		setGoalRow(-1);
		setGoalColumn(-1);
	}
	
	Map(Node[][] anArray, int curRow, int curColumn){
		setTotal(anArray);
		setGoalRow(curRow);
		setGoalColumn(curColumn);
	}
	
	public Node[][] getTotal(){
		return total;
	}
	
	public int getGoalRow(){
		return goalRow;
	}
	
	public int getGoalColumn(){
		return goalColumn;
	}
	
	public void setTotal(Node[][] curArray){
		total = curArray;
	}
	
	public void setGoalRow(int aRow){
		goalRow = aRow;
	}
	
	public void setGoalColumn(int aColumn){
		goalColumn = aColumn;
	}
	
	/** Implementation of depth-first search
	 * Inputs: Node aNode, StringBuffer starting, String answer, int counter
	 * Outputs: string containing path to goal
	 */
	public String dfsSearch(Node aNode, StringBuffer starting, String answer, int counter){
		if (answer.length() > 0){
			return answer;
		}
		
		aNode.setUsed(true);
		String temp = aNode.getRow() + "," + aNode.getColumn() + "; ";
		starting.append(temp);
		
		if (aNode.getMoveCost() == -1){
			answer = starting.toString();
			return answer;
		}
		
		if ((aNode.getRow() - aNode.getMoveCost() >= 0) &&
			(!total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			answer = dfsSearch(total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()], starting, answer, counter+1);
		}
		if ((aNode.getColumn() + aNode.getMoveCost() < total[aNode.getRow()].length) && 
			(!total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].getUsed())){
			answer = dfsSearch(total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()], starting, answer, counter+1);
		}
		
		if ((aNode.getRow() + aNode.getMoveCost() < total.length) && 
			(!total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			answer = dfsSearch(total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()], starting, answer, counter+1);
		}
		if ((aNode.getColumn() - aNode.getMoveCost() >= 0) && 
			(!total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].getUsed())){
			answer = dfsSearch(total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()], starting, answer, counter+1);
		}
		
		int index = starting.lastIndexOf(temp);
		if (index != -1){
			starting.delete(index, starting.length());
		}
		starting.delete(index, starting.length()); 
		aNode.setUsed(false);
		return answer;
	}
	
	/** Implementation of breadth-first search
	 * Inputs: ArrayList<Node> nodeList, ArrayList<StringBuffer> pathList, String answer
	 * Outputs: string containing path to goal
	 */
	public String bfsSearch(ArrayList<Node> nodeList, ArrayList<StringBuffer> pathList, String answer){
		if (answer.length() > 0){
			return answer;
		}
		StringBuffer prevPath = new StringBuffer();
		ArrayList<Node> tempList = new ArrayList<Node>();
		ArrayList<StringBuffer> tempString = new ArrayList<StringBuffer>();
		for (int i = 0; i < nodeList.size(); i++){
			nodeList.get(i).setUsed(true);
			String curNode = nodeList.get(i).getRow() + "," + nodeList.get(i).getColumn() + "; ";
			if (pathList.size() == 0){
				prevPath.append(curNode);
			}
			else{
				prevPath = pathList.get(i);
				prevPath.append(curNode);
			}
			if (nodeList.get(i).getMoveCost() == -1){
				answer = prevPath.toString();
				return answer;
			}
			
			if ((nodeList.get(i).getRow() - nodeList.get(i).getMoveCost() >= 0) &&
				(!total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()].getUsed())){
				tempList.add(total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()]);
				String hold1 = prevPath.toString();
				tempString.add(new StringBuffer(hold1));
			}
			if ((nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost() < total[nodeList.get(i).getRow()].length) && 
				(!total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()].getUsed())){
				tempList.add(total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()]);
				String hold1 = prevPath.toString();
				tempString.add(new StringBuffer(hold1));
			}
			if ((nodeList.get(i).getRow() + nodeList.get(i).getMoveCost() < total.length) && 
				(!total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()].getUsed())){
				tempList.add(total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()]);
				String hold1 = prevPath.toString();
				tempString.add(new StringBuffer(hold1));
			}
			if ((nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost() >= 0) && 
				(!total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()].getUsed())){
				tempList.add(total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()]);
				String hold1 = prevPath.toString();
				tempString.add(new StringBuffer(hold1));
			}
			prevPath.delete(0, prevPath.length());
		}
		nodeList = tempList;
		pathList = tempString;
		
		answer = bfsSearch(nodeList, pathList, answer);
		return answer;
	}
	
	/** Implementation of greedy best-first search, based on
	 * depth-first search with the heuristic function used to choose
	 * direction.
	 * Inputs: Node aNode, StringBuffer holdAnswer, String answer
	 * Outputs: string containing path to goal
	 */
	public String bestFirstSearch(Node aNode, StringBuffer holdAnswer, String answer){
		if (answer.length() > 0){
			return answer;
		}
		
		aNode.setUsed(true);
		String temp = aNode.getRow() + "," + aNode.getColumn() + "; ";
		holdAnswer.append(temp);
		
		if (aNode.getMoveCost() == -1){
			answer = holdAnswer.toString();
			return answer;
		}
		
		ArrayList<Node> tempList = new ArrayList<Node>();
		if ((aNode.getRow() - aNode.getMoveCost() >= 0) &&
			(!total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			tempList.add(total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()]);
		}
		if ((aNode.getColumn() + aNode.getMoveCost() < total[aNode.getRow()].length) && 
			(!total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].getUsed())){
			tempList.add(total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()]);
		}
		
		if ((aNode.getRow() + aNode.getMoveCost() < total.length) && 
			(!total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			tempList.add(total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()]);
		}
		if ((aNode.getColumn() - aNode.getMoveCost() >= 0) && 
			(!total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].getUsed())){
			tempList.add(total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()]);
		}
		
		for (int i = 0; i < tempList.size(); i++) {
			if (tempList.get(i).getHeuristic() == -1) {
				int heuristic = 0;
				int counter = 0;
				ArrayList<Node> nodeList = new ArrayList<Node>();
				boolean isFound = false;
				nodeList.add(tempList.get(i));
				tempList.get(i).setHeuristic(calcHeuristic(nodeList, heuristic, counter, isFound));
				for (int j = 0; j < total.length; j++) {
					for (int k = 0; k < total[j].length; k++) {
						total[j][k].setHeuristicTest(false);
					}
				}
			}
		}
		
		for (int i = 0; i < tempList.size(); i++) {
			for (int j = 0; j < tempList.size() - 1; j++) {
				if (tempList.get(j).getHeuristic() > tempList.get(j+1).getHeuristic()) {
					Node holding = tempList.get(j);
					tempList.set(j, tempList.get(j+1));
					tempList.set(j+1, holding);
				}
			}
		}
		
		for (int i = 0; i < tempList.size(); i++) {
			//System.out.println(tempList.get(i).getHeuristic());
			answer = bestFirstSearch(tempList.get(i), holdAnswer, answer);
		}
		
		int index = holdAnswer.lastIndexOf(temp);
		if (index != -1){
			holdAnswer.delete(index, holdAnswer.length());
		}
		holdAnswer.delete(index, holdAnswer.length());
		aNode.setUsed(false);
		return answer;
	}
	
	/**Implementation of A* search, based on 
	 * uniform-cost search with the heuristic function added to
	 * g(n)
	 * Inputs: Node aNode, PriorityQueue<Node> allOptions, String answer, int currentPath
	 * Outputs: string containing path to goal
	 */
	public String aStarSearch(Node aNode, PriorityQueue<Node> allOptions, String answer, int currentPath){
		
		aNode.setUsed(true);
		
		if (aNode.getMoveCost() == -1){
			Stack<Node> pathFind = new Stack<Node>();
			pathFind.push(aNode);
			while(aNode.getPrevNode() != null) {
				aNode = aNode.getPrevNode();
				pathFind.push(aNode);
			}
			while (!pathFind.isEmpty()) {
				Node holding = pathFind.pop();
				answer = answer + holding.getRow() + "," + holding.getColumn() + "; ";
			}
			//answer = "Found it.";
			return answer;
		}
		
		//ArrayList<Node> tempList = new ArrayList<Node>();
		if ((aNode.getRow() - aNode.getMoveCost() >= 0) &&
			(!total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].setGofN(aNode.getGofN() + aNode.getMoveCost());
			total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].setPrevNode(aNode);
			if (total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].getHeuristic() == -1)
			{
				int heuristic = 0;
				int counter = 0;
				ArrayList<Node> nodeList = new ArrayList<Node>();
				boolean isFound = false;
				nodeList.add(total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()]);
				total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()].setHeuristic(calcHeuristic(nodeList, heuristic, counter, isFound));
				for (int j = 0; j < total.length; j++) {
					for (int k = 0; k < total[j].length; k++) {
						total[j][k].setHeuristicTest(false);
					}
				}
			}
			allOptions.add(total[aNode.getRow() - aNode.getMoveCost()][aNode.getColumn()]);
		}
		if ((aNode.getColumn() + aNode.getMoveCost() < total[aNode.getRow()].length) && 
			(!total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].getUsed())){
			total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].setGofN(aNode.getGofN() + aNode.getMoveCost());
			total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].setPrevNode(aNode);
			if (total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].getHeuristic() == -1)
			{
				int heuristic = 0;
				int counter = 0;
				ArrayList<Node> nodeList = new ArrayList<Node>();
				boolean isFound = false;
				nodeList.add(total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()]);
				total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()].setHeuristic(calcHeuristic(nodeList, heuristic, counter, isFound));
				for (int j = 0; j < total.length; j++) {
					for (int k = 0; k < total[j].length; k++) {
						total[j][k].setHeuristicTest(false);
					}
				}
			}
			allOptions.add(total[aNode.getRow()][aNode.getColumn() + aNode.getMoveCost()]);
		}
		
		if ((aNode.getRow() + aNode.getMoveCost() < total.length) && 
			(!total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].getUsed())){
			total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].setGofN(aNode.getGofN() + aNode.getMoveCost());
			total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].setPrevNode(aNode);
			if (total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].getHeuristic() == -1)
			{
				int heuristic = 0;
				int counter = 0;
				ArrayList<Node> nodeList = new ArrayList<Node>();
				boolean isFound = false;
				nodeList.add(total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()]);
				total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()].setHeuristic(calcHeuristic(nodeList, heuristic, counter, isFound));
				for (int j = 0; j < total.length; j++) {
					for (int k = 0; k < total[j].length; k++) {
						total[j][k].setHeuristicTest(false);
					}
				}
			}
			allOptions.add(total[aNode.getRow() + aNode.getMoveCost()][aNode.getColumn()]);
		}
		if ((aNode.getColumn() - aNode.getMoveCost() >= 0) && 
			(!total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].getUsed())){
			total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].setGofN(aNode.getGofN() + aNode.getMoveCost());
			total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].setPrevNode(aNode);
			if (total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].getHeuristic() == -1)
			{
				int heuristic = 0;
				int counter = 0;
				ArrayList<Node> nodeList = new ArrayList<Node>();
				boolean isFound = false;
				nodeList.add(total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()]);
				total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()].setHeuristic(calcHeuristic(nodeList, heuristic, counter, isFound));
				for (int j = 0; j < total.length; j++) {
					for (int k = 0; k < total[j].length; k++) {
						total[j][k].setHeuristicTest(false);
					}
				}
			}
			allOptions.add(total[aNode.getRow()][aNode.getColumn() - aNode.getMoveCost()]);
		}
		
		answer = aStarSearch(allOptions.remove(), allOptions, answer, currentPath+aNode.getMoveCost());
		
		aNode.setUsed(false);
		return answer;
	}
	
	/**Method to calculate heuristic
	 * Heuristic is based on number of moves to get to the goal if diagonal movement is allowed
	 * Inputs: ArrayList of Nodes, int heuristic, boolean isFound
	 * Outputs: The value of the heuristic function for the starting node as an integer
	 */
	public int calcHeuristic(ArrayList<Node> nodeList, int heuristic, int counter, boolean isFound){
		//System.out.println(nodeList.size());
		if (isFound){
			return heuristic;
		}
		if (counter == 5){
			//System.out.println(heuristic + " is heuristic");
			return 6;
		}
		ArrayList<Node> tempList = new ArrayList<Node>();
		for (int i = 0; i < nodeList.size(); i++){
			nodeList.get(i).setHeuristicTest(true);
			if (nodeList.get(i).getMoveCost() == -1){
				isFound = true;
				return heuristic;
			}
			//System.out.println(nodeList.get(i).getRow() + " " + nodeList.get(i).getColumn());
			if ((nodeList.get(i).getRow() - nodeList.get(i).getMoveCost() >= 0) &&
				(!total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()]);
			}
			if ((nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost() < total[nodeList.get(i).getRow()].length) && 
				(!total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()]);
			}
			if ((nodeList.get(i).getRow() + nodeList.get(i).getMoveCost() < total.length) && 
				(!total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn()]);
			}
			if ((nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost() >= 0) && 
				(!total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()]);
			}
			
			if ((nodeList.get(i).getRow() - nodeList.get(i).getMoveCost() >= 0) &&
				(nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost() >= 0) &&
				(!total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()]);
			}
			if ((nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost() < total[nodeList.get(i).getRow()].length) && 
				(nodeList.get(i).getRow() - nodeList.get(i).getMoveCost() >= 0) &&
				(!total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() - nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()]);
			}
			if ((nodeList.get(i).getRow() + nodeList.get(i).getMoveCost() < total.length) && 
				(nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost() < total[nodeList.get(i).getRow()].length) &&
				(!total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() + nodeList.get(i).getMoveCost()]);
			}
			if ((nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost() >= 0) && 
				(nodeList.get(i).getRow() + nodeList.get(i).getMoveCost() < total.length) &&
				(!total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()].getHeuristicTest())){
				tempList.add(total[nodeList.get(i).getRow() + nodeList.get(i).getMoveCost()][nodeList.get(i).getColumn() - nodeList.get(i).getMoveCost()]);
			}
		}
		nodeList = tempList;
		
		counter++;
		heuristic++;
		heuristic = calcHeuristic(nodeList, heuristic, counter, isFound);
		
		tempList = null;
		return heuristic;
	}
}
