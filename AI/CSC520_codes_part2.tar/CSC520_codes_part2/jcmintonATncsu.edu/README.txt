README - Assignment 1: Search
Julia Minton - jcminton
Artificial Intelligence

========================================================================
To compile:
Run javac Search.java Node.java Map.java in the terminal corresponding
to the user's operating system. Use the path names for each .java file.

========================================================================
To run:
Run java Search <search-type> <maze file name> in the terminal 
corresponding to the user's operating system. Use the path names for the
.class file and the maze file. The possible options for the search-type
argument are:
	dfs (for depth-first search)
	bfs (for breadth-first search)
	best-first (for greedy best-first search)
	astar (for A* search)
Any other input will produce an error message. Giving an invalid file
name or path name for the maze will produce a FileIOException.

========================================================================
Output:
The program prints the final path to the console. Each node in the path
is represented by the row and column number, separated by a comma.
Semicolons (followed by a space) are used to separate each column.

For example: the output for 4x4Maze-maze.txt is "0,0; 2,0; 2,1; 3,1;",
meaning that the algorithm traversed row 0, column 0; row 2, column 0;
row 2, column 1; and row 3, column 1. The last listed node is always the
goal. 

========================================================================
Classes:
There are three classes included in this project: Search, Node, and Map.

	1. Search contains the main method for the program. It reads the
	command line arguments and subsequently reads in the information
	from the maze file. It then creates Node objects with each integer
	and uses them to instantiate a Map object. The first argument is
	used to determine which algorithm to run.
	
	2. Node is a container class for any information pertaining to nodes
	in the maze. It contains the location (row and column), move cost,
	heuristic, and current path from start (g(n)) for a single maze
	node. It also contains boolean markers to avoid infinite loops in
	searches, as well as a reference to the previous Node in the path
	for A* searches.
	
	3. Map is a class containing the entire graph, as well as the
	location of the goal and methods for each search algorithm (as well
	as the heuristic function). These will be discussed in greater
	detail in the algorithms section.

========================================================================
Algorithms:
This program implements depth-first search, breadth-first search,
greedy best-first search, and A* search algorithms.

	1. Depth-first search (dfs): Beginning at the starting node (0,0),
	the dfsSearch() method recursively checks any adjacent nodes for the
	goal, continually checking the deepest node first. This method 
	checks north, then east, then south, then west. Each iteration of 
	the method appends a representation of the row and column of the 
	current node to a StringBuffer object. If the current node is a dead
	end, the method removes the current node row and column from the
	StringBuffer. When the goal is found, the method returns the
	string contained in the StringBuffer.
	
	2. Breadth-first search (bfs): Beginning at the starting node (0,0),
	the bfsSearch() method recursively adds every adjacent node to an
	ArrayList of nodes. Each node in the current ArrayList is 
	subsequently called by bfsSearch(). The method also appends a 
	representation of the row and column of the current node to a 
	StringBuffer object. Each branch in the ArrayList has a separate 
	StringBuffer. When the goal is found, the method
	returns the string contained in the current StringBuffer.
	
	3. Greedy best-first search (best-first): Beginning at the starting
	node, bestFirstSearch() uses the same implementation as dfsSearch();
	however, instead of checking nodes in order of north, east, south,
	and west, bestFirstSearch() checks nodes in order from smallest to
	largest heuristic.
		a. The heuristic function in this program is the same
		implementation as bfsSearch(); however, it allows diagonal
		movement as well as horizontal and vertical movement. The method
		has an integer (called heuristic) that increases by one every
		time the method runs recursively. The method returns this
		integer when either the goal is found or the value of heuristic 
		reaches 5 (at which point it returns 6). The latter is to
		prevent excessive use of resources by the heuristic function.
	
	4. A* search (astar): Beginning at the starting node, aStarSearch() 
	first checks the current node for the goal state. After the initial
	check, the method calculates the path from the start to each
	adjacent node (g(n)) using the current node's g(n) and move cost. 
	The adjacent nodes also mark their previous node as the current
	node. Each adjacent node is added to a PriorityQueue; the queue 
	orders nodes from smallest to largest using the sum g(n) + h(n). The
	method recursively runs on each popped node from the queue until the
	goal is found. The method then adds each node in the actual path to 
	a Stack (using the trail of previous nodes to trace the path). Each 
	node in the stack, when popped, adds a representation of its row and
	column to a string. The method then returns the string.
