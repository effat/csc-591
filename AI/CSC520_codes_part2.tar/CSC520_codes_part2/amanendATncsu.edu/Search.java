/*
Name: Ankit Manendra
Unity ID: amanend
Assignment 1, Question 4
CSC 520, Spring 2019
*/


import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Search {

    class Node
    {
        int x, y, dist;
        String parent,value,goal;

        Node(int x, int y, int dist, String val, String par,String goalString) {
            this.x = x;
            this.y = y;
            this.dist = dist;
            this.value=val;
            this.parent=par;
            this.goal=goalString;
        }
    };

    //This function is used to check if the current node is valid or not and if it has been visited or already in the frontier
    public boolean isValid(List<List<String>> grid, boolean visited[][], int row, int col, Map<String,Node> nodeMap){
        int rowLen=grid.size();
        int colLen=grid.get(0).size();
        return (row >=0) && (row < rowLen) && (col >= 0) && (col < colLen) && !visited[row][col] && !nodeMap.containsKey(String.valueOf(row)+","+String.valueOf(col));
    }


//**********************Breadth First Search********(Start)*****************************
    public void BFS(List<List<String>> grid, String goalStr){

        int statesExpandedShort=0; // this stores all the states expanded while searching the first path

        int rowSize=grid.size();
        int colSize=grid.get(0).size();
        boolean visited[][] = new boolean[rowSize][colSize];  //this array will hold true values for visited nodes
        String parNode[][] = new String[rowSize][colSize];

        //creating a queue
        Queue<Node> q = new ArrayDeque<>();
        visited[0][0]=true;     //this is the explored array which stores all the states we have already seen and expanded

        //we store every node that we add to the queue to this map, so we dont visit the cell which is already or have been in the frontier
        //we need this map to check for nodes which are in frontier but not yet visited
        Map<String,Node> nodeMap = new HashMap();

        String parent="0,0";        //for first node

        Node newNode = new Node(0,0,0, grid.get(0).get(0),parent,goalStr);
        q.add(newNode);
        nodeMap.put(String.valueOf(0)+","+String.valueOf(0),newNode);

        while (!q.isEmpty()){

            Node node = q.poll();
            int i=node.x;
            int j=node.y;

            if (nodeMap.containsKey(String.valueOf(i) + "," + String.valueOf(j)))
                nodeMap.remove(String.valueOf(i) + "," + String.valueOf(j));

            int dist=node.dist;
            String cellValue = node.value;

            visited[i][j]=true;     // set this cell to visited


            statesExpandedShort++;


            if (cellValue.equals("G")){
                break;
            }

            int intCellValue = Integer.valueOf(cellValue);

            // we create an array of possible actions that can be performed
            int row[]={-intCellValue,intCellValue,0,0};
            int col[] ={0,0,-intCellValue,intCellValue};


            //iterating over all these possible actions
            for (int k = 0; k < 4; k++)
            {
                int newRow=i+row[k];
                int newCol=j+col[k];
                String parentNode=String.valueOf(i)+","+String.valueOf(j);//adding parent node

                if (isValid(grid, visited, newRow, newCol,nodeMap))
                {
                    parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);

                    Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol), parentNode,goalStr);
                    q.add(newNode1);
                    nodeMap.put(String.valueOf(newRow) + "," + String.valueOf(newCol), newNode1);
                }
            }
        }

        System.out.println("*****Breadth First Search*****");

        int rowGoal=Integer.valueOf(goalStr.split(",")[0]);
        int colGoal=Integer.valueOf(goalStr.split(",")[1]);
        printPath(parNode,rowGoal,colGoal);
        System.out.println("\nTotal number of states expanded when finding shortest path: "+statesExpandedShort);

    }
    //**********************Breadth First Search********(End)*****************************

    //**********************Depth First Search********(Start)*****************************

     public void DFS(List<List<String>> grid, String goalStr){

         int statesExpandedShort=0; // this stores all the states expanded while searching the first path

         int rowSize=grid.size();
         int colSize=grid.get(0).size();
         boolean visited[][] = new boolean[rowSize][colSize];
         String parNode[][] = new String[rowSize][colSize];

         //creating a stack
         Stack<Node> q = new Stack<>();
         visited[0][0]=true;     //this is the expored array which stores all the states we have already seen and expanded

         //we store every node that we add to the queue to this map, so we dont visit the cell which is already or have been in the frontier
         Map<String,Node> nodeMap = new HashMap();

         String parent="0,0";

         Node newNode = new Node(0,0,0, grid.get(0).get(0),parent,goalStr);
         q.add(newNode);
         nodeMap.put(String.valueOf(0)+","+String.valueOf(0),newNode);

         while (!q.isEmpty()){

             Node node = q.pop();
             int i=node.x;
             int j=node.y;

             if (nodeMap.containsKey(String.valueOf(i) + "," + String.valueOf(j)))
                 nodeMap.remove(String.valueOf(i) + "," + String.valueOf(j));

             int dist=node.dist;
             String cellValue = node.value;

             visited[i][j]=true;     // set this cell to visited

             statesExpandedShort++;

             // we keep track of total states expanded untill the first goal has been found
             //if goal found for first time, set the boolean variable to true
             if (cellValue.equals("G")){//goalStr.equals(String.valueOf(i)+","+String.valueOf(j))){
                 break;
             }


             int intCellValue = Integer.valueOf(cellValue);

             // we create an array of possible actions that can be performed
             int row[]={-intCellValue,intCellValue,0,0};
             int col[] ={0,0,-intCellValue,intCellValue};


             //iterating over all these possible actions
             for (int k = 0; k < 4; k++)
             {
                 int newRow=i+row[k];
                 int newCol=j+col[k];
                 String parentNode=String.valueOf(i)+","+String.valueOf(j);//adding parent node

                 if (isValid(grid, visited, newRow, newCol,nodeMap))
                 {
                     parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);

                         Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol), parentNode,goalStr);
                         q.add(newNode1);
                         nodeMap.put(String.valueOf(newRow) + "," + String.valueOf(newCol), newNode1);
                 }
             }
         }

         System.out.println("\n*****Depth First Search*****");

         int rowGoal=Integer.valueOf(goalStr.split(",")[0]);
         int colGoal=Integer.valueOf(goalStr.split(",")[1]);
         printPath(parNode,rowGoal,colGoal);
         System.out.println("\nTotal number of states expanded when finding shortest path: "+statesExpandedShort);


         //Here we are finding all unique paths for 6x6 and 8x8 mazes
         if (((rowSize==6 && colSize==6) || (rowSize==8 && colSize==8))) {
             boolean[][] visitedAllPath = new boolean[rowSize][colSize];
             Set<String> exploredSet = new HashSet<>();
             int[] totalPathandStates = new int[2];
             int totalPaths[] = findAllUniquePaths(grid, 0, 0, goalStr, visitedAllPath, totalPathandStates, exploredSet);

             System.out.println("\nTotal Number of Unique Paths: " + totalPaths[0]);
             System.out.println("\nTotal number of states expanded when finding all path: " + totalPathandStates[1]);
         }
    }

    //checks valid nodes for the findAllUniquePaths method
    private static boolean isValidCellAllPath(List<List<String>> grid,int row, int col,boolean[][] visited)
    {
        int rowLen=grid.size();
        int colLen=grid.get(0).size();
        return (row >=0) && (row < rowLen) && (col >= 0) && (col < colLen) && (!visited[row][col]);
    }

    public int[] findAllUniquePaths(List<List<String>> grid,int row, int col,String goalStr,boolean visited[][],int[] count,Set<String> exploredSet){
        exploredSet.add(String.valueOf(row)+","+String.valueOf(col)); //this will store all the cell coordinates which have been explored yet
        count[1]=exploredSet.size();//stores the number of explored cells
        if ((String.valueOf(row)+","+String.valueOf(col)).equals(goalStr)){
            count[0]++; //if a goal is found, increment the count
            return count;
        }
        visited[row][col]=true;
        String cellValue=grid.get(row).get(col);
        int intCellValue=Integer.valueOf(cellValue);
        int rowMoves[]={-intCellValue,intCellValue,0,0};
        int colMoves[] ={0,0,-intCellValue,intCellValue};

        for (int k = 0; k < 4; k++)
        {
            int newRow=row+rowMoves[k];
            int newCol=col+colMoves[k];

            String findKey=String.valueOf(newRow) + "," + String.valueOf(newCol);
            if (isValidCellAllPath(grid,newRow, newCol,visited))
            {
                count=findAllUniquePaths(grid,newRow,newCol,goalStr,visited,count,exploredSet);
            }
        }
        visited[row][col]=false;
        return count;

    }

//**********************Depth First Search********(End)*****************************

//**********************Best First Search********(Start)*****************************

    public void BestFirst(List<List<String>> grid, String goalStr){
        int statesExpandedShort=0;
        int rowSize=grid.size();
        int colSize=grid.get(0).size();
        boolean visited[][] = new boolean[rowSize][colSize];
        String parNode[][] = new String[rowSize][colSize];

        //creating a queue
        int capacity=rowSize*colSize;
        Queue<Node> nodePQueue = new PriorityQueue<>(capacity, nodeComparatorBF);

        visited[0][0]=true;
        Map<String,Node> nodeMap = new HashMap();

        String parent="0,0";
        Node newNode = new Node(0,0,0,grid.get(0).get(0),parent,goalStr);
        nodePQueue.add(newNode);
        nodeMap.put(String.valueOf(0)+","+String.valueOf(0),newNode);

        while (!nodePQueue.isEmpty()){
            Node node = nodePQueue.poll();

            int i=node.x;
            int j=node.y;
            int dist=node.dist;
            String cellValue = node.value;

            if (nodeMap.containsKey(String.valueOf(i) + "," + String.valueOf(j)))
                nodeMap.remove(String.valueOf(i) + "," + String.valueOf(j));


            visited[i][j]=true;

            statesExpandedShort++;

            if (cellValue.equals("G")){
                break;
            }

            int intCellValue=Integer.valueOf(cellValue);

            //up,down,left,right
            int row[]={-intCellValue,intCellValue,0,0};
            int col[] ={0,0,-intCellValue,intCellValue};


            for (int k = 0; k < 4; k++)
            {
                int newRow=i+row[k];
                int newCol=j+col[k];
                String parentNode=String.valueOf(i)+","+String.valueOf(j);//adding parent node

                String findKey=String.valueOf(newRow) + "," + String.valueOf(newCol);

                if (isValid(grid, visited, newRow, newCol,nodeMap))
                {
                    //update parent of next node
                    parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);

                    Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol),parentNode,goalStr);
                    nodePQueue.add(newNode1);
                    nodeMap.put(String.valueOf(newRow)+","+String.valueOf(newCol),newNode1);

                }
                //if node is in frontier with higher cost, then update its cost and parent
                if ((nodeMap.containsKey(findKey)
                        && (nodeMap.get(findKey).dist>dist+1))){
                    parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);
                    Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol),parentNode,goalStr);
                    nodeMap.put(String.valueOf(newRow)+","+String.valueOf(newCol),newNode1);
                }
            }
        }

        int rowGoal=Integer.valueOf(goalStr.split(",")[0]);
        int colGoal=Integer.valueOf(goalStr.split(",")[1]);
        System.out.println("\n*****Best First Search*****");
        printPath(parNode,rowGoal,colGoal);
        System.out.println("\nTotal number of states expanded when finding shortest path: "+statesExpandedShort);
    }

//comparator for Best First - for implementing priority queue
    public static Comparator<Node> nodeComparatorBF = new Comparator<Node>(){

        @Override
        public int compare(Node n1, Node n2) {
            //if the goal node is in the priority queue, then fetch it
            if (n2.value.equals("G"))
                return 1;
            else if (n1.value.equals("G"))
                return -1;

            //extracting the row and column of goal cell
            int gRow=Integer.valueOf(n1.goal.split(",")[0]);
            int gCol=Integer.valueOf(n1.goal.split(",")[0]);

            //if the node is in the same row or column of goal then assign a cost of 1, else 2
            int heurN1 = (gRow==n1.x || gCol==n1.y) ? 1 : 2; //if the goal is in same row or column,give cost of 1 else 2
            int heurN2 = (gRow==n2.x || gCol==n2.y) ? 1 : 2;

            //if the value is still same, then for tiebreaker, calculate the manhattan distance and subtract the jump value inside it
            if (heurN1==heurN2){
                heurN1=Math.abs(gRow-n1.x) + Math.abs(gCol-n1.y) - Integer.valueOf(n1.value);
                heurN2=Math.abs(gRow-n2.x) + Math.abs(gCol-n2.y) - Integer.valueOf(n2.value);
            }

            if (heurN1 > heurN2)
                return 1;
            else if (heurN1 < heurN2)
                return -1;
            else return 0;
        }
    };

    //**********************Best First Search********(End)*****************************

    //**********************A Star Search********(Start)*****************************

    public void ASTAR(List<List<String>> grid, String goalStr){
        int statesExpandedShort=0;
        int rowSize=grid.size();
        int colSize=grid.get(0).size();
        boolean visited[][] = new boolean[rowSize][colSize];
        String parNode[][] = new String[rowSize][colSize];

        //creating a queue
        int capacity=rowSize*colSize;
        Queue<Node> nodePQueue = new PriorityQueue<>(capacity, nodeComparatorASTAR);

        visited[0][0]=true;
        Map<String,Node> nodeMap = new HashMap();

        String parent="0,0";
        Node newNode = new Node(0,0,0,grid.get(0).get(0),parent,goalStr);
        nodePQueue.add(newNode);
        nodeMap.put(String.valueOf(0)+","+String.valueOf(0),newNode);

        while (!nodePQueue.isEmpty()){
            Node node = nodePQueue.poll();

            int i=node.x;
            int j=node.y;
            int dist=node.dist;
            String cellValue = node.value;

            if (nodeMap.containsKey(String.valueOf(i) + "," + String.valueOf(j)))
                nodeMap.remove(String.valueOf(i) + "," + String.valueOf(j));


            visited[i][j]=true;

            statesExpandedShort++;

            if (cellValue.equals("G")){
                break;
            }

            int intCellValue=Integer.valueOf(cellValue);

            //up,down,left,right
            int row[]={-intCellValue,intCellValue,0,0};
            int col[] ={0,0,-intCellValue,intCellValue};


            for (int k = 0; k < 4; k++)
            {
                int newRow=i+row[k];
                int newCol=j+col[k];
                String parentNode=String.valueOf(i)+","+String.valueOf(j);//adding parent node

                String findKey=String.valueOf(newRow) + "," + String.valueOf(newCol);

                if (isValid(grid, visited, newRow, newCol,nodeMap))
                {
                    //update parent of next node
                    parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);

                    Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol),parentNode,goalStr);
                    nodePQueue.add(newNode1);
                    nodeMap.put(String.valueOf(newRow)+","+String.valueOf(newCol),newNode1);

                }
                //if node is in frontier with higher cost, then update its cost and parent
                if ((nodeMap.containsKey(findKey)
                        && (nodeMap.get(findKey).dist>dist+1))){
                    parNode[newRow][newCol] = String.valueOf(i) + "," + String.valueOf(j);
                    Node newNode1 = new Node(newRow, newCol, dist + 1, grid.get(newRow).get(newCol),parentNode,goalStr);
                    nodeMap.put(String.valueOf(newRow)+","+String.valueOf(newCol),newNode1);
                }
            }
        }

        int rowGoal=Integer.valueOf(goalStr.split(",")[0]);
        int colGoal=Integer.valueOf(goalStr.split(",")[1]);
        System.out.println("\n*****A Star Search*****");
        printPath(parNode,rowGoal,colGoal);
        System.out.println("\nTotal number of states expanded when finding shortest path: "+statesExpandedShort);
    }


    //comparator for A Star - for implementing priority queue
    public static Comparator<Node> nodeComparatorASTAR = new Comparator<Node>(){

        @Override
        public int compare(Node n1, Node n2) {

            //if the goal node is in the priority queue, then fetch it
            if (n2.value.equals("G"))
                return 1;
            else if (n1.value.equals("G"))
                return -1;

            int gRow=Integer.valueOf(n1.goal.split(",")[0]);
            int gCol=Integer.valueOf(n1.goal.split(",")[0]);

            int heurN1 = (gRow==n1.x || gCol==n1.y) ? (1+n1.dist) : (2+n1.dist); //if the goal is in same row or column,give cost of 1 else 2
            int heurN2 = (gRow==n2.x || gCol==n2.y) ? (1+n2.dist) : (2+n2.dist);

            if (heurN1==heurN2){
                heurN1=n1.dist+Math.abs(gRow-n1.x) + Math.abs(gCol-n1.y) - Integer.valueOf(n1.value);
                heurN2=n2.dist+Math.abs(gRow-n2.x) + Math.abs(gCol-n2.y) - Integer.valueOf(n2.value);
            }

            if (heurN1 > heurN2)
                return 1;
            else if (heurN1 < heurN2)
                return -1;
            else return 0;
        }
    };

    //**********************A Star Search********(End)*****************************


    //this function prints the shortest path to goal for all functions using the parNodes array
    public void printPath(String[][] parNodes , int row, int col){
        if (row==0 && col==0) {
            System.out.println("Path to Goal: \n");
            System.out.println(String.valueOf(row)+","+String.valueOf(col));
            return;
        }

        int rowPar=Integer.valueOf(parNodes[row][col].split(",")[0]);
        int colPar=Integer.valueOf(parNodes[row][col].split(",")[1]);

        printPath(parNodes,rowPar,colPar);
        System.out.println(String.valueOf(row)+","+String.valueOf(col));

    }

    public static void main(String[] args) {

        String algorithm=args[0];
        File file = new File(args[1]);


        //File file = new File("D:\\NCSU 2nd Sem\\AI 520\\TrainingMazes\\4x4Maze-maze.txt");
        List<List<String>> grid = new ArrayList<>();
        String goalCell = "";
        int maxJump=0;
        try{
            Scanner scan = new Scanner(file);
            int row=0;
            while (scan.hasNextLine()){
                int col=0;
                String str = scan.nextLine();
                str.replaceAll(" ","");
                List<String> newList = new ArrayList<>();
                for (String modStr:str.split(",")){
                    if (modStr!=",") {
                        if (modStr.equals("G")) {
                            goalCell = String.valueOf(row) + ',' + String.valueOf(col);
                        }
                        else {
                            if (Integer.valueOf(modStr) > maxJump){
                                maxJump=Integer.valueOf(modStr);
                            }
                        }
                        newList.add(modStr);
                        col++;
                    }
                }
                row++;
                grid.add(newList);
            }

            Search search = new Search();
            if (algorithm.equals("BFS")) {
                search.BFS(grid, goalCell);
            }
            else if (algorithm.equals("DFS")) {
                search.DFS(grid, goalCell);
            }
            else if (algorithm.equals("BestFirst")) {
                search.BestFirst(grid, goalCell);
            }
            else if (algorithm.equals("AStar")) {
                search.ASTAR(grid, goalCell);
            }
            else System.out.println("Incorrect Algorithm/File");
            /*search.BFS(grid,goalCell);
            search.DFS(grid,goalCell);
            search.BestFirst(grid,goalCell);
            search.ASTAR(grid,goalCell);
            */
        }
        catch (FileNotFoundException error){
            error.printStackTrace();
        }
    }

}
