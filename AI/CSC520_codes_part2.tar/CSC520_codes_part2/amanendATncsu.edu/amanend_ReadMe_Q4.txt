Read Me File for Question 4 (Assignment 1)


*********************How to run this program**********************************

To run this code, in the command prompt/terminal, goto the respective drive where this code is, and then run the following command:

> javac Search.java

This will compile the code.

Next run the following command:

>  java Search "algorithm_name" "file_location"
Here, the algorithm name could be "BFS", "DFS", "BestFirst" or "AStar"
Also, the file location would be the location in your computer where the training mazes are

For eg: java Search "AStar" "D:\\NCSU 2nd Sem\\AI 520\\TrainingMazes\\4x4Maze-maze.txt"


*********************How to read the output**********************************

> For every algorithm, the first line always states the name of the search algorithm applied. After that, it prints the shortest path (here first found) to goal. This is the answer to part a.
> It prints the path in the same way as was demonstrated in the sample output file.
> It then prints the number of states explored while finding the shortest path. This is the answer to part b.
> Next, for 6x6 and 8x8 maze and for the DFS algorithm, it prints the total number of unique paths found to the goal. And in the next line, it prints the total number of states expanded when finding all these paths. These are the answers to part c and d.


************************************Details about the structure of the code**********************************************

First of all, I have created a node class which would correspond to every cell in the maze. This class has following attributes:
> x : The x coordinate of the cell
> y: The y coordinate of the cell
> dist: This stores the cost of coming to this node from the starting node
> parent: This stores the coordinate of the parent node of this node
> value: This holds the jump value mentioned in this node
> goal: This holds the coordinates of the goal cell

* I have created seperate methods for every algorithm and all of these uses a "isValid" method. This method takes some input related to the current node/cell and return a boolean value if this is a valid node or not. It checks if this coordinates are within the maze or outside of it. It also checks if this node has been visited earlier or not. Also, it checks if this node is in the frontier or not.


> Now I will describe briefly how all of my search algorithms have been programmed.


********************************Breadth First Search***********************************************************************

> I have used a queue for this algorithm, and initially added the starting node. Now in a while loop, I dequeu and extract a node. 
> Next, I mark the current node as visited and increment the "statesExpandedShort" variable's value. 
> Next, check if this is the goal node then break this while loop. Else proceed to next step.
> Next for every algorithm, I have used a row and col array where I have stored the possible actions that the agent can take i.e. move up/down/left/right. 
> Next , iterate over all these actions and check if the resulting node is valid. If its a valid node, enqueu this node and also add to a map i.e. nodeMap which is used to check if my current node is already in the frontier and not visited yet. We also, update the parent node of the next node.
> when we are out of elements in the queue, we call the printPath function. This is a recursive function which uses the "parNode" array to find out the parent nodes of every node untill it reach the starting node and correspondingly prints the path.
> One thing to note is that I have taken care of the fact that the goal check needs to be done while I am visiting a node and not while I am still deliberating the or looking at the next node based on my current action. This was specifically stressed upon in the lecture by the professor.


********************************Depth First Search***********************************************************************

DFS is implemented the exact same way as BFS, jsut that I have used a stack instead of a queue.
Besides, for the (c) and (d) part of the problem. I have used DFS. I have used a "findAllUniquePaths" method which uses DFS recursively. This method is exhaustive in the sense that it checks for each and every possibility to find a path to the goal. 
> In my DFS method, I have checked if the current maze is a 6x6 or a 8x8 and if it is, then I have called the "findAllUniquePaths" method to find every path to the goal and also find the total number of states explored while doing that.


********************************Best First Search***********************************************************************

This is again similar to BFS however instead of using a normal queue, I am using a priority queue.
> The heuristic I have chosen for this is that: If I have 2 choices and any one of them lies in the same row or column as in the goal then give that node a cost of 1 and the other as 2. This way it never overestimates the cost. Also, to resolve tie-breakers, I have found the manhattan distance and subtracted the jump value in the corresponding node so as I get the closer of the two nodes from the goal. (This has been explained much better in the solution pdf).

> To implement the priority queue, I have overriden the comparator and used the heuristic values. There are two comparators. "nodeComparatorBF" for Best first search and "nodeComparatorASTAR" for A star algorithm.
> One more change for the Best first search algorithm from the BFS algorithm is that when I am visiting a certain node and the next node is not visited, however its in the frontier, I check if the cost of reaching that node is greater than what could be the cost of reaching that node from current node. If its greater, then I have replaced the cost and the parent for that node.


********************************A Star Search***********************************************************************

> This is almost similar to the best first search. The only difference for this is in the comparator which apart from considering the heuristic, also considers the cost of reaching the current node from the starting node.