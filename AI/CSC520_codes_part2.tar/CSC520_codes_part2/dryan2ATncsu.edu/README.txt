This program was executed on the NC State VCL platform (CSC520_VCL).  All maze files and the java executable (NumberMaze.jar) should be located in the same directory.  To execute, enter the following command:

java -jar NumberMaze.jar <algorithm> <mazefile>

The following are valid algorithm selections:

BFS - executes the Breadth First Search Algorithm
DFS - executes the Depth First Search Algorithm
BestFirst - executes the Greedy Best First Search Algorithm
Astar - executes the A* algorithm
AllPaths - calculates the total number of unique paths through the maze

Each algorithm prints the total number of expanded states to standard output, and also generates a text file containing the solution determined by the algorithm.  The text file will have the same name as the input file, but with (algorithm)-solution.txt appended to the file name.  The file will consist of the coordinates of all of the cells in the maze traversal printed on a new line.