import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Class to implement a number-maze solver using state-space search with DFS, BFS, Best
 * First, and A* algorithms. A number-maze is a matrix representation for a maze problem.
 * Each cell in the maze contains a number or a "G" indicating the goal state. The solver
 * starts the maze at the entry point at cell 0,0. At each cell it can move up, down,
 * left, or right, the number of cells listed in the current cell, unless it hits an
 * edge. A number maze is complete when it has been traversed through to the goal state
 * marked "G".  The code takes two arguments:  one specifying the text file containing
 * the maze information, the other specifying the algorithm to use ("DFS", "BFS", "Best
 * First", or "Astar").  When executed, the maze file is read and the maze is constructed.
 * Then, using the specified algorithm, the maze is solved and the solution steps are
 * output to a text file (original file name appended with "-solution").  Each line of the
 * output file contains the coordinates of each cell in the solution traversal.  
 * 
 * @author Dan Ryan, CSC520, Spring '19
 *
 */
public class MazeSolver {

	/**
	 * Entry point for the program
	 * 
	 * @param args Command line arguments, should be 2 (maze file and algorithm)
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.print("Input Error:  Must input 2 arguments (maze file and search algorithm)\n");
			return;
		}

		String algorithm = args[0];
		String mazeFile = args[1];
		
		Maze maze = new Maze();
		maze.buildMaze(mazeFile);
		
		if (algorithm.equalsIgnoreCase("DFS")) {
			LinkedList<Cell> solution = runDFS(maze);
			String outputFilename = mazeFile.substring(0, mazeFile.indexOf(".txt")) + "(DFS)";
			printSolution(solution, outputFilename);
		}
		else if (algorithm.equalsIgnoreCase("BFS")) {
			LinkedList<Cell> solution = runBFS(maze);
			String outputFilename = mazeFile.substring(0, mazeFile.indexOf(".txt")) + "(BFS)";
			printSolution(solution, outputFilename);
		}
		else if (algorithm.equalsIgnoreCase("BestFirst")) {
			LinkedList<Cell> solution = runBestFirst(maze);
			String outputFilename = mazeFile.substring(0, mazeFile.indexOf(".txt")) + "(BestFirst)";
			printSolution(solution, outputFilename);
		}
		else if (algorithm.equalsIgnoreCase("Astar")) {
			int numOfLookAheadSteps = 5;
			LinkedList<Cell> solution = runAStar(maze, numOfLookAheadSteps);
			String outputFilename = mazeFile.substring(0, mazeFile.indexOf(".txt")) + "(Astar)";
			printSolution(solution, outputFilename);
		}
		else if (algorithm.equalsIgnoreCase("AllPaths"))
			findAllPaths(maze);
		else
			System.out.print("Invalid Algorithm Selected\n");
		
		return;
	}
	
	/**
	 * Execute number-maze solver using state-space search with DFS algorithm
	 * 
	 * @param maze The maze to solve
	 * @return The maze solution determined by the DFS algorithm
	 */
	public static LinkedList<Cell> runDFS(Maze maze) {
		LinkedList<Cell> solution = new LinkedList<Cell>();
		Cell origin = maze.getCell(0, 0);
		solution.add(origin);
		
		boolean goalFound = false;
		int expandedStates = 0;
		
		while (!goalFound) {
			// Get the current cell
			Cell currentCell = solution.getLast();
			int currentRow = currentCell.getRow();
			int currentCol = currentCell.getCol();
			int currentStep = currentCell.getStep();
			maze.markVisited(currentRow, currentCol);
			
			// Test the current cell
			if (currentCell.isGoal())
				goalFound = true;
			else {
				// Expand nodes
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				if (northCell != null && !northCell.beenVisited()) { //Try the north cell first
					solution.add(northCell);
					expandedStates++;
				} else if (southCell != null && !southCell.beenVisited()) { //Try the south cell second
					solution.add(southCell);
					expandedStates++;
				} else if (westCell != null && !westCell.beenVisited()) { //Try the west cell third
					solution.add(westCell);
					expandedStates++;
				} else if (eastCell != null && !eastCell.beenVisited()) { //Try the east cell last
					solution.add(eastCell);
					expandedStates++;
				} else { //Reached a dead-end, backtrack
					solution.removeLast();
				}
			}
		}
		
		System.out.printf("The number of states expanded = %d\n", expandedStates);
		
		return solution;
	}

	/**
	 * Execute number-maze solver using state-space search with BFS algorithm
	 * 
	 * @param maze The maze to solve
	 * @return The maze solution determined by the BFS algorithm
	 */
	public static LinkedList<Cell> runBFS(Maze maze) {
		LinkedList<LinkedList<Cell>> paths = new LinkedList<LinkedList<Cell>>();
		
		LinkedList<Cell> origin = new LinkedList<Cell>();
		origin.add(maze.getCell(0, 0));
		paths.add(origin);
		
		boolean goalFound = false;
		int expandedStates = 0;
		
		LinkedList<Cell> currentPath = null;
		
		while (!goalFound) {
			// Pop the first path off the queue
			currentPath = paths.pop();
			Cell currentCell = currentPath.getLast();
			int currentRow = currentCell.getRow();
			int currentCol = currentCell.getCol();
			int currentStep = currentCell.getStep();
			
			// Test the current cell
			if (currentCell.isGoal())
				goalFound = true;
			else {
				// Expand nodes
				expandedStates++;
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				// As long as the cells are not already in the path, branch another path
				if (northCell != null && !currentPath.contains(northCell)) {
					LinkedList<Cell> northPath = new LinkedList<Cell>(currentPath);
					northPath.add(northCell);
					paths.add(northPath);
				}
					
				if (southCell != null && !currentPath.contains(southCell)) {
					LinkedList<Cell> southPath = new LinkedList<Cell>(currentPath);
					southPath.add(southCell);
					paths.add(southPath);
				}
				
				if (westCell != null && !currentPath.contains(westCell)) {
					LinkedList<Cell> westPath = new LinkedList<Cell>(currentPath);
					westPath.add(westCell);
					paths.add(westPath);
				}
				
				if (eastCell != null && !currentPath.contains(eastCell)) {
					LinkedList<Cell> eastPath = new LinkedList<Cell>(currentPath);
					eastPath.add(eastCell);
					paths.add(eastPath);
				}
			}	
		}
		
		System.out.printf("The number of states expanded = %d\n", expandedStates);
		
		return currentPath;
	}
	
	/**
	 * Runs the BFS algorithm until all paths have been exhausted and counts the number of unique
	 * paths that reach the goal state.
	 * 
	 * @param maze The maze to solve
	 */
	public static void findAllPaths(Maze maze) {
		Queue<LinkedList<Cell>> paths = new LinkedList<LinkedList<Cell>>();
		
		LinkedList<Cell> origin = new LinkedList<Cell>();
		origin.add(maze.getCell(0, 0));
		paths.add(origin);
		
		int numOfPaths = 0;
		int expandedStates = 0;
		
		LinkedList<Cell> currentPath = null;
		
		// Same as BFS, but don't stop when you find a solution, run all paths
		while (!paths.isEmpty()) {
			// Pop the first path off the queue
			currentPath = paths.poll();
			Cell currentCell = currentPath.getLast();
			int currentRow = currentCell.getRow();
			int currentCol = currentCell.getCol();
			int currentStep = currentCell.getStep();
			
			// Test the current cell
			if (currentCell.isGoal())
				numOfPaths++;
			else {
				// Expand nodes
				expandedStates++;
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				// As long as the cells are not already in the path, branch another path
				if (northCell != null && !currentPath.contains(northCell)) {
					LinkedList<Cell> northPath = new LinkedList<Cell>(currentPath);
					northPath.add(northCell);
					paths.add(northPath);
				}
					
				if (southCell != null && !currentPath.contains(southCell)) {
					LinkedList<Cell> southPath = new LinkedList<Cell>(currentPath);
					southPath.add(southCell);
					paths.add(southPath);
				}
				
				if (westCell != null && !currentPath.contains(westCell)) {
					LinkedList<Cell> westPath = new LinkedList<Cell>(currentPath);
					westPath.add(westCell);
					paths.add(westPath);
				}
				
				if (eastCell != null && !currentPath.contains(eastCell)) {
					LinkedList<Cell> eastPath = new LinkedList<Cell>(currentPath);
					eastPath.add(eastCell);
					paths.add(eastPath);
				}
			}	
		}
		
		System.out.printf("The number of unique paths through the graph = %d\n", numOfPaths);
		System.out.printf("The number of states expanded = %d\n", expandedStates);
	}
	
	/**
	 * Execute number-maze solver using state-space search with Greedy Best First algorithm
	 * 
	 * @param maze The maze to solve
	 * @return The maze solution determined by the best first algorithm
	 */
	public static LinkedList<Cell> runBestFirst(Maze maze) {
		LinkedList<Cell> solution = new LinkedList<Cell>();
		Cell origin = maze.getCell(0, 0);
		solution.add(origin);
		
		boolean goalFound = false;
		int expandedStates = 0;
		
		while (!goalFound) {
			// Get the current cell
			Cell currentCell = solution.getLast();
			int currentRow = currentCell.getRow();
			int currentCol = currentCell.getCol();
			int currentStep = currentCell.getStep();
			maze.markVisited(currentRow, currentCol);
			
			// Test the current cell
			if (currentCell.isGoal())
				goalFound = true;
			else {
				// Expand nodes
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				// Create an array of the potential moves for sorting
				Cell moves[] = new Cell[4];
				moves[0] = southCell;
				moves[1] = northCell;
				moves[2] = westCell;
				moves[3] = eastCell;
				
				// Create an array of distances for sorting.  If null, distance = max
				double distances[] = new double[4];
				if (moves[0] != null)
					distances[0] = moves[0].getDistance();
				else
					distances[0] = Double.MAX_VALUE;
				if (moves[1] != null)
					distances[1] = moves[1].getDistance();
				else
					distances[1] = Double.MAX_VALUE;
				if (moves[2] != null)
					distances[2] = moves[2].getDistance();
				else
					distances[2] = Double.MAX_VALUE;
				if (moves[3] != null)
					distances[3] = moves[3].getDistance();
				else
					distances[3] = Double.MAX_VALUE;
				
				// Sort the arrays
				for (int i = 0; i < 4; i++) {
					for (int j = i + 1; j < 4; j++) {
						if (distances[i] > distances[j]) {
							double tempDist = distances[i];
							Cell tempCell = moves[i];
							distances[i] = distances[j];
							moves[i] = moves[j];
							distances[j] = tempDist;
							moves[j] = tempCell;
						}
					}
				}
				
				boolean validMove = false;
				
				// Select the best move
				for (int i = 0; i < 4; i++) {
					if (moves[i] != null && !moves[i].beenVisited()) {
						solution.add(moves[i]);
						expandedStates++;
						validMove = true;
						break;
					}
				}
				
				if (!validMove) //Reached a dead-end, backtrack
					solution.removeLast();
			}
		}
		
		System.out.printf("The number of states expanded = %d\n", expandedStates);
		
		return solution;
	}
	
	/**
	 * Execute number-maze solver using state-space search with A* algorithm.  The A* algorithm is a
	 * best first algorithm with an added heuristic function.  The heuristic used here evaluates potential
	 * moves by looking ahead a specified number of moves and choosing the initial move that leads to the
	 * shortest possible remaining distance to the goal after the projected moves.  
	 * 
	 * @param maze The maze to solve
	 * @param lookAheadSteps The number of steps to look ahead
	 * @return The maze solution determined by the DFS algorithm
	 */
	public static LinkedList<Cell> runAStar(Maze maze, int lookAheadSteps) {
		LinkedList<Cell> solution = new LinkedList<Cell>();
		Cell origin = maze.getCell(0, 0);
		solution.add(origin);
		
		boolean goalFound = false;
		int expandedStates = 0;
		
		while (!goalFound) {
			// Get the current cell
			Cell currentCell = solution.getLast();
			int currentRow = currentCell.getRow();
			int currentCol = currentCell.getCol();
			int currentStep = currentCell.getStep();
			maze.markVisited(currentRow, currentCol);
			
			// Test the current cell
			if (currentCell.isGoal())
				goalFound = true;
			else {
				// Expand nodes
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				double northDistance = Double.MAX_VALUE;
				double southDistance = Double.MAX_VALUE;
				double westDistance = Double.MAX_VALUE;
				double eastDistance = Double.MAX_VALUE;
				
				// Get the look ahead distances
				if (northCell != null && !northCell.beenVisited())
					northDistance = getLookAheadDistance(northCell, solution, maze, lookAheadSteps);
				if (southCell != null && !southCell.beenVisited())
					southDistance = getLookAheadDistance(southCell, solution, maze, lookAheadSteps);
				if (westCell != null && !westCell.beenVisited())
					westDistance = getLookAheadDistance(westCell, solution, maze, lookAheadSteps);
				if (eastCell != null && !eastCell.beenVisited())
					eastDistance = getLookAheadDistance(eastCell, solution, maze, lookAheadSteps);
				
				// Find the shortest potential distance
				double shortestDistance = northDistance;
				Cell bestCell = northCell;
				
				if (southDistance < shortestDistance) {
					shortestDistance = southDistance;
					bestCell = southCell;
				}
				if (westDistance < shortestDistance) {
					shortestDistance = westDistance;
					bestCell = westCell;
				}
				if (eastDistance < shortestDistance) {
					shortestDistance = eastDistance;
					bestCell = eastCell;
				}

				// Move to the best cell
				solution.add(bestCell);
				expandedStates++;
			}
		}
		
		System.out.printf("The number of states expanded = %d\n", expandedStates);
		
		return solution;
	}
	
	/**
	 * Heuristic to be used for A* search.  Starting at the specified cell, the algorithm looks ahead
	 * the number of specified steps and returns the shortest possible distance to the goal state.  To
	 * calculate the distance, the algorithm expands all possible paths starting at the specified cell
	 * and examines the resulting distance of each path.  The expansion is analogous to BFS and as the
	 * number of steps approaches the total number of cells in the maze, the algorithm becomes a full
	 * BFS.
	 * 
	 * @param startingCell The starting point for all potential paths
	 * @param solution The current solution path to the maze up to this point
	 * @param numOfSteps The number of steps to look ahead
	 * @param maze The maze to solve
	 * @return The shortest possible distance to the goal state, starting at the current cell and projecting
	 * the look ahead steps
	 */
	public static double getLookAheadDistance(Cell startingCell, LinkedList<Cell> solution, Maze maze, int numOfSteps) {
		LinkedList<Cell> lookAheadPaths = new LinkedList<Cell>();
		
		// Need a list of the cells we hypothetically traverse so we can clear their visited flags at the end
		LinkedList<Cell> cellsToClear = new LinkedList<Cell>();
		
		lookAheadPaths.add(startingCell);
		
		// Decrement steps since we've already expanded once
		numOfSteps--;
		
		boolean deadEnd = false;
		boolean goalFound = false;
		
		for (int i = 0; i < numOfSteps; i++) {
			int size = lookAheadPaths.size();
			
			// Hit a dead end
			if (size == 0)
				deadEnd = true;
			
			for (int j = 0; j < size; j++) {
				Cell currentCell = lookAheadPaths.pop();
				currentCell.markVisited();
				cellsToClear.add(currentCell);
				
				// Test for goal cell
				if (currentCell.isGoal())
					goalFound = true;
				
				int currentRow = currentCell.getRow();
				int currentCol = currentCell.getCol();
				int currentStep = currentCell.getStep();
				
				// Expand nodes
				int southRow = currentRow + currentStep;
				int eastCol = currentCol + currentStep;
				int northRow = currentRow - currentStep;
				int westCol = currentCol - currentStep;
				
				// Get the next cells
				Cell southCell = maze.getCell(southRow, currentCol);
				Cell eastCell = maze.getCell(currentRow, eastCol);
				Cell northCell = maze.getCell(northRow, currentCol);
				Cell westCell = maze.getCell(currentRow, westCol);
				
				// If the cells are valid, add them to the potential paths
				if (northCell != null && !northCell.beenVisited())
					lookAheadPaths.add(northCell);
				if (southCell != null && !southCell.beenVisited())
					lookAheadPaths.add(southCell);
				if (westCell != null && !westCell.beenVisited())
					lookAheadPaths.add(westCell);
				if (eastCell != null && !eastCell.beenVisited())
					lookAheadPaths.add(eastCell);
			}
		}
		
		// Clear the visited flags
		for (int i = 0; i < cellsToClear.size(); i++)
			cellsToClear.get(i).clearVisited();
		
		// If goal found, return 0
		if (goalFound)
			return 0;
		
		// If dead end, return max
		if (deadEnd)
			return Double.MAX_VALUE;
		
		// If goal found, return 0
		if (lookAheadPaths.size() == 0)
			return 0;
		
		double shortestDistance = lookAheadPaths.get(0).getDistance();
		
		// Find the shortest distance
		for (int i = 1; i < lookAheadPaths.size(); i++) {
			if (lookAheadPaths.get(i).getDistance() < shortestDistance)
				shortestDistance = lookAheadPaths.get(i).getDistance();
		}
		
		return shortestDistance;
	}
	
	/**
	 * Writes the solution to the maze to an output file.  The output file is named by
	 * taking the input filename and appending "-solution".  The output file consists
	 * of the coordinates of each cell in the maze traversal printed out on a separate
	 * line in the order that they are taken.
	 * 
	 * @param solution The list of cells in the traversal solution
	 * @param filename The name of the input file
	 */
	public static void printSolution(LinkedList<Cell> solution, String filename) {
		String outputFilename = filename + "-solution.txt";
		
		PrintStream output = null;
		
		try {
			output = new PrintStream(new File(outputFilename));
		} catch (FileNotFoundException e) {
			System.out.print("Error. Problem creating file\n");
			e.printStackTrace();
		}
		
		for (int i = 0; i < solution.size(); i++) {
			Cell c = solution.get(i);
			output.printf("%d,%d\n", c.getRow(), c.getCol());
		}
		
		output.close();
	}
}
