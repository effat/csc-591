/**
 * Class used to represent each cell of the maze.  Each cell contains its row index,
 * column index, step size, a boolean flag to denote if it is the Goal cell or not,
 * and a boolean flag to denote if the cell has been visited that will be used when
 * traversing the maze.
 *
 * @author Dan Ryan, CSC520, Spring '19
 */
public class Cell {
	/** The row index of this Cell */
	private int row;
	/** The col index of this Cell */
	private int col;
	/** The step value of this Cell */
	private int step;
	/** Is this the goal cell */
	private boolean isGoal;
	/** Has this cell been visited */
	private boolean beenVisited;
	/** The distance from this cell to the goal cell */
	private double distance;
	
	/**
	 * Default constructor for Cell objects
	 * 
	 * @param step The step size of this cell
	 * @param isGoal True, if this is the Goal cell.  Otherwise, false.
	 */
	public Cell(int row, int col, int step, boolean isGoal) {
		this.row = row;
		this.col = col;
		this.step = step;
		this.isGoal = isGoal;
		this.beenVisited = false;
		this.distance = 0;
	}
	
	/**
	 * Getter method for the isGoal variable
	 * 
	 * @return True, if this is the goal cell.  False, otherwise.
	 */
	public boolean isGoal() {
		return this.isGoal;
	}
	
	/**
	 * Getter method for the beenVisited variable
	 * 
	 * @return True, if this cell has already been visited.  False, otherwise.
	 */
	public boolean beenVisited() {
		return this.beenVisited;
	}
	
	/**
	 * Getter method for the distance variable.
	 * 
	 * @return The distance from this cell to the goal cell.  0, if this is the goal cell.
	 */
	public double getDistance() {
		return this.distance;
	}
	
	/**
	 * Setter method for the distance variable.
	 * 
	 * @param dist The distance from this cell to the goal cell.  0, if this is the goal cell.
	 */
	public void setDistance(double dist) {
		this.distance = dist;
	}
	
	/**
	 * Gets the row index for this cell
	 * 
	 * @return The row index for this cell
	 */
	public int getRow() {
		return this.row;
	}
	
	/**
	 * Gets the column index for this cell
	 * 
	 * @return The column index for this cell
	 */
	public int getCol() {
		return this.col;
	}
	
	/**
	 * Gets the step size associated with this cell
	 * 
	 * @return The step size for this cell
	 */
	public int getStep() {
		return this.step;
	}
	
	/**
	 * Marks that this cell has been visited.
	 */
	public void markVisited() {
		this.beenVisited = true;
	}
	
	/**
	 * Clears this cell as been visited.
	 */
	public void clearVisited() {
		this.beenVisited = false;
	}
}
