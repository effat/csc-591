import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class used to represent a Maze.  Each maze contains an array of cells representing
 * a grid pattern.  The number of Rows and Columns for the maze are stored as member
 * variables for each maze.
 *
 * @author Dan Ryan, CSC520, Spring '19
 */
public class Maze {
	/** Number of rows in the maze */
	private int numRows;
	/** Number of columns in the maze */
	private int numCols;
	/** An array containing all the cells in the maze */
	private ArrayList<Cell> cells;
	
	/**
	 * Default constructor for a Maze.  Creates an empty maze.
	 */
	public Maze() {
		this.numRows = 0;
		this.numCols = 0;
		this.cells = new ArrayList<Cell>();
	}
	
	/**
	 * Reads the text file containing maze information and constructs the maze.  The maze file
	 * should contain rows of comma separated text representing the step size for each cell in 
	 * the maze
	 * 
	 * @param mazeFile A string containing the name of the csv text maze file.
	 */
	public void buildMaze(String mazeFile) {
		Scanner input = null;
		
		// Open the Maze File
		try {
			input = new Scanner(new File(mazeFile));
		} catch (FileNotFoundException e) {
			System.out.print("Error. Maze file not found\n");
			e.printStackTrace();
		}
		
		// Initialize the number of rows, columns
		numRows = 0;
		numCols = 0;
		
		int goalRow = 0;
		int goalCol = 0;
		
		// Read each row
		while (input.hasNextLine()) {
			String line = input.nextLine();
			
			//Reset the number of columns, arrayIndex
			numCols = 0;
			
			Scanner linescan = new Scanner(line);
			linescan.useDelimiter(",");
			
			// Read each column of this row
			while (linescan.hasNext()) {
				String cellInfo = linescan.next();
				
				Cell newCell = null;
				
				// Construct a new cell (check for Goal cell)
				if (cellInfo.equals("G")) {
					newCell = new Cell(numRows, numCols, 0, true);
					goalRow = numRows;
					goalCol = numCols;
				}
				else {
					int cellStep = Integer.parseInt(cellInfo);
					newCell = new Cell(numRows, numCols, cellStep, false);
				}
				
				numCols++;
				
				// Add new cell to the array
				cells.add(newCell);
			}
			
			numRows++;
			
			linescan.close();
		}
		
		// Calculate the distance for each cell
		for (int i = 0; i < cells.size(); i++) {
			int cellRow = cells.get(i).getRow();
			int cellCol = cells.get(i).getCol();
			
			double distance = Math.sqrt(Math.pow((goalRow-cellRow), 2) + Math.pow((goalCol-cellCol), 2));
			
			cells.get(i).setDistance(distance);
		}
	}
	
	/**
	 * Returns the cell located at the specified row/column.  If the specified row or
	 * column is outside the bounds of the maze, returns null. 
	 * 
	 * @param row Row index of the cell to retrieve
	 * @param col Column index of the cell to retrieve
	 * @return The Cell located at the specified row/column.  Null, if outside the maze bounds.
	 */
	public Cell getCell(int row, int col) {
		if (row >= numRows || row < 0 || col >= numCols || col < 0)
			return null;
		
		int index = (row * numCols) + col;
		
		return cells.get(index);
	}
	
	/**
	 * Marks the cell located at the specified row/column as being visited to avoid loops
	 * when traversing the maze.
	 * 
	 * @param row Row index of the cell to mark
	 * @param col Column index of the cell to mark
	 */
	public void markVisited(int row, int col) {
		if (row >= numRows || row < 0 || col >= numCols || col < 0)
			return;
		
		int index = (row * numCols) + col;
		
		cells.get(index).markVisited();
	}
}
