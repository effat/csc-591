import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

//This class serves as the driver function to call diffrent graph traversing algorithms

public class Main {

    //stack for putting all the nodes
    static Vector<Node> nodes;
    //stack for holding the graph
    static Vector<Vector<String>> grid;

    public static void main(String[] args){


        String algorithm = args[0];
        String inputFileName = args[1];
        try {
            buildGraph(inputFileName);
            switch (algorithm){
                case "bfs" : {
                    bfs();
                    break;
                }
                case "dfs" : {
                    dfs();
                    break;
                }
                case "bfirst" : {
                    bestFirst();
                    break;
                }
                case "astar" : {
                    aStar();
                    break;
                }
                case "all" : {
                    allPathWithBfs();
                    break;
                }
                default:
                    System.out.println("Invalid algorithm selected");

            }
        }catch (FileNotFoundException e){
            System.out.println("File not found");
        }





    }

    //finds path using breadth first search algorithm
    public static void bfs(){

        Vector <Node> frontier = new Vector<>();
        Vector <Node> visited = new Vector<>();
        Vector<Edge> edges = new Vector<>();
        Vector <Node> path = new Vector<>();
        Node source = nodes.get(0);
        int statesExpanded =1;

        frontier.add(nodes.get(0));
        while(frontier.size()!=0){
            Node head = frontier.firstElement();
            frontier.remove(0);
            visited.add(head);
            statesExpanded++;
            if (head.cost==-1){
                path.add(head);
                Node parent = getEdgeWithChild(head,edges).parent;
                path.add(parent);
                while(parent!=source){
                    parent = getEdgeWithChild(parent,edges).parent;
                    path.add(parent);
                }
                break;
            }
            for (Node n :
                    head.neighbors) {
                if (!visited.contains(n) && !frontier.contains(n)) {
                    Edge e = new Edge(head,n);
                    edges.add(e);
                    frontier.add(n);
                }
            }
        }

        Collections.reverse(path);
        for (Node n :
                path) {
            System.out.println(n.name+",");

        }
        System.out.println("States expanded: "+statesExpanded);
    }


    //finds path using depth first search algorithm

    public static void dfs(){

        Vector<Node> visited = new Vector<>();
        Vector<Node> frontier = new Vector<>();
        Vector<Edge> edges = new Vector<>();
        Vector <Node> path = new Vector<>();

        Node head = nodes.firstElement();
        int statesExpanded =1;

        frontier.add(head);

        while(!frontier.isEmpty()){

            Node n = frontier.firstElement();
            frontier.remove(0);
            visited.add(n);

            //if goal node reached
            if(n.cost==-1){
                //System.out.println("Goal reached");
                path.add(n);

                //keep edges for backtracking path
                Node parent = getEdgeWithChild(n,edges).parent;
                path.add(parent);
                while(parent!=head){
                    parent = getEdgeWithChild(parent,edges).parent;
                    path.add(parent);
                }
                break;

            }

            statesExpanded++;

            //explore neighbor nodes
            for (Node neighbor :
                    n.neighbors) {
                if (!visited.contains(neighbor)) {
                    Edge e = new Edge(n,neighbor);
                    edges.add(e);
                    frontier.add(0,neighbor);
                }
            }
        }

        //since we backtraced from the goal we need to reverse the stack to find flow
        Collections.reverse(path);
        for (Node n :
                path) {
            System.out.println(n.name+",");

        }
        System.out.println("States expanded: "+statesExpanded);



    }

    //path finding algorithm with heuristic called best first search
    public static void bestFirst(){

        Vector<Node> visited = new Vector<>();
        Vector<Node> frontier = new Vector<>();
        Vector<Edge> edges = new Vector<>();
        Vector <Node> path = new Vector<>();

        Node head = nodes.firstElement();
        int statesExpanded =1;

        computeHeurestic();

        frontier.add(head);

        while(!frontier.isEmpty()){

            //sort the stack using heuristic value
            Collections.sort(frontier, new NodeComparator());
            Node n = frontier.firstElement();
            frontier.remove(0);
            visited.add(n);

            //goal node found
            if(n.cost==-1){
                //System.out.println("Goal reached");
                path.add(n);
                Node parent = getEdgeWithChild(n,edges).parent;
                path.add(parent);
                while(parent!=head){
                    parent = getEdgeWithChild(parent,edges).parent;
                    path.add(parent);
                }
                break;

            }

            statesExpanded++;

            //explore the neighbors
            for (Node neighbor :
                    n.neighbors) {
                if (!visited.contains(neighbor)) {
                    Edge e = new Edge(n,neighbor);
                    edges.add(e);
                    frontier.add(0,neighbor);
                }
            }
        }

        Collections.reverse(path);
        for (Node n :
                path) {
            System.out.println(n.name+",");

        }
        System.out.println("States expanded: "+statesExpanded);



    }

    //path finding algorithm using heuristic function using A* search
    public static void aStar(){

        Vector<Node> visited = new Vector<>();
        Vector<Node> frontier = new Vector<>();
        Vector<Edge> edges = new Vector<>();
        Vector <Node> path = new Vector<>();

        Node head = nodes.firstElement();
        int statesExpanded =1;
        frontier.add(head);

        computeHeurestic();

        while(!frontier.isEmpty()){

            //sort the stack using heuristic values + path distance to neighbor which uis inserted during adding neighbors to the queue
            Collections.sort(frontier,new NodeComparator());
            Node n = frontier.firstElement();
            frontier.remove(0);
            visited.add(n);

            //goal node reached?
            if(n.cost==-1){
                //System.out.println("Goal reached");
                path.add(n);
                Node parent = getEdgeWithChild(n,edges).parent;
                path.add(parent);
                while(parent!=head){
                    parent = getEdgeWithChild(parent,edges).parent;
                    path.add(parent);
                }
                break;

            }

            statesExpanded++;

            for (Node neighbor :
                    n.neighbors) {
                if (!visited.contains(neighbor)) {
                    Edge e = new Edge(n,neighbor);
                    edges.add(e);
                    //adding path cost to a neighbor and heuristic cost from neighbor to goal. Uniform path cost so adding 1
                    int pathCost =1;
                    n.heurestic= n.heurestic+pathCost;
                    frontier.add(0,neighbor);
                }
            }
        }

        Collections.reverse(path);
        for (Node n :
                path) {
            System.out.println(n.name+",");

        }
        System.out.println("States expanded: "+statesExpanded);



    }

    //using bfs traverse all the possible paths
    public static void allPathWithBfs(){

        Vector <Vector<Node>> paths = new Vector<>();
        Vector <Vector<Node>> solutions = new Vector<>();
        Node source = nodes.get(0);
        int statesExpandedforShortestPath =0;
        int statesExpanded =1;
        boolean shortestPathFound = false;

        Vector<Node> initial_path = new Vector<>();
        initial_path.add(source);
        paths.add(initial_path);

        while(paths.size()!=0){

            Vector<Node> path = paths.firstElement();
            Node tail = path.lastElement();
            paths.remove(0);
            statesExpanded++;
            if(!shortestPathFound) statesExpandedforShortestPath++;
            if (tail.cost==-1){
                solutions.add(path);
                shortestPathFound = true;


            }
            else{
                for (Node n :
                        tail.neighbors) {
                    if (!path.contains(n)) {
                        Vector<Node> newPath = new Vector<>();
                        for (Node node :
                                path) {
                            newPath.add(node);
                        }
                        newPath.add(n);
                        paths.add(newPath);

                    }
                }
            }

        }

        printPath(solutions.firstElement());
        System.out.println("Possible solutions: "+solutions.size());
        System.out.println("States expanded for Shortest Path: "+statesExpandedforShortestPath);
        System.out.println("Total States expanded: "+statesExpanded);
    }

    //compute a heuristic value on every node using djkstra's algorithm from goal node
    static void computeHeurestic(){

        Vector<Node> unvisited = new Vector<>();
        Vector<Node> visited = new Vector<>();
        for (Node x :
                nodes) {
            if(x.cost==-1){
                x.heurestic=0;

            }
            unvisited.add(x);
        }


        while(!unvisited.isEmpty()){
            Collections.sort(unvisited,new NodeComparator());
            Node first = unvisited.firstElement();
            unvisited.remove(0);
            visited.add(first);
            for (Node n :
                    first.parents) {
                int heurestic = first.heurestic + 1;
                if(heurestic< n.heurestic) n.heurestic = heurestic;
            }
        }

    }

    //method for printing a path
    static void printPath(Vector<Node> path){
        for (Node node : path
             ) {
            System.out.println(node.name);
        }
    }


    //method for building the graph out of the input
    static void buildGraph(String fileName) throws FileNotFoundException {

        File file = new File(fileName);
        FileReader fr = new FileReader(file);
        Scanner sc = new Scanner(file);
        int r=0, c =0;
        nodes = new Vector<>();
        grid = new Vector<>();

        while(sc.hasNextLine()){

            r++;
            String input = sc.nextLine();
            String [] values = input.split(",");
            c = values.length;
            Vector v = new Vector();
            for (String s:values
                 ) {
                v.add(s);
            }
            grid.add(v);

        }
        for (int i = 0; i < grid.size(); i++) {
            for (int j = 0; j < grid.get(i).size(); j++) {
                String element = grid.get(i).get(j);

                if (!element.equalsIgnoreCase("G")){

                    int val = Integer.parseInt(element);
                    String name = i+","+j;
                    Node n = new Node(name,val,i,j);
                    nodes.add(n);

                }
                else{

                    String name = i+","+j;
                    Node n = new Node(name,-1,i,j);
                    nodes.add(n);

                }

                //System.out.print(grid.get(i).get(j)+",");
            }
            System.out.println();


        }

        for (Node n :
                nodes) {
            int val = n.cost;

            //skip adding neighbors if its goal state
            if (val==-1) continue;


            //up move possible
            if(n.x-val>=0){
                n.neighbors.add(getNode(n.x-val,n.y));
                getNode(n.x-val,n.y).parents.add(n);
            }
            //down move possible
            if(n.x+val<r){
                n.neighbors.add(getNode(n.x+val,n.y));
                getNode(n.x+val,n.y).parents.add(n);
            }
            //left move possible
            if(n.y-val>=0){
                n.neighbors.add(getNode(n.x,n.y-val));
                getNode(n.x,n.y-val).parents.add(n);
            }
            //right move possible
            if(n.y+val<c){
                n.neighbors.add(getNode(n.x,n.y+val));
                getNode(n.x,n.y+val).parents.add(n);
            }
        }

    }

    //returns edge for a given parent value
    public static Edge getEdgeWithParent(Node n, Vector<Edge> edges){
        for (Edge e :
                edges) {
            if(e.parent == n) return e;
        }
        return null;
    }

    //returns edge for a given child value
    public static Edge getEdgeWithChild(Node n, Vector<Edge> edges){

        for (Edge e :
                edges) {
            if(e.child == n) return e;
        }
        return null;
    }

    //return a specific node using provided cordinates
    public static Node getNode(int x, int y){
        for (Node n :
                nodes) {
            if (n.x == x && n.y == y) return n;
        }
        return null;
    }

}

//class for maintaining edges
class Edge{
    Node parent;
    Node child;

    public Edge(Node parent, Node child) {
        this.parent = parent;
        this.child = child;
    }
}

//class for maintaining nodes
class Node {

    String name;
    int x;
    int y;
    int cost;
    Vector<Node> neighbors;
    Vector<Node> parents;
    int heurestic;

    public Node(String name, int cost, int x, int y) {
        this.name = name;
        this.cost = cost;
        this.x = x;
        this.y = y;
        this.heurestic = Integer.MAX_VALUE;
        neighbors = new Vector<>();
        parents = new Vector<>();
    }

}

//comparator for sorting nodes queue using heuristic value
class NodeComparator implements Comparator<Node>
{
    public int compare(Node o1, Node o2)
    {
        if(o1.heurestic<o2.heurestic) return -1;
        else if(o1.heurestic>o2.heurestic) return 1;
        else return 0;
    }
}