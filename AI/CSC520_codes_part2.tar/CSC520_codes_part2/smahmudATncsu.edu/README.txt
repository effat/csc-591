The compiled code is in MyCode.jar file
Run it using the command:
java -jar MyCode.jar <algorithm> <file>

i.e java -jar MyCode.jar bfs 4x4.txt

-Dont forget to put input files in the same directory as the jar
-Dont forget to include extension of the input file
-Following keywords for desired algorithms: bfs(BFS), dfs(DFS), bfirst(Best first search), astar(A* search), all(Print all possible path count using bfs)