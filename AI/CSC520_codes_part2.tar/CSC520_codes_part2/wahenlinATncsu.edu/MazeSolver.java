import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Stack;

/**
 * A class to solve the number maze problem using various search algorithms. The program accepts a maze
 * input file in text format as well as a specification for which search algorithm to use to traverse the maze.
 * The program outputs the solution to the console.
 *
 * @author Will Henline
 *
 */
public class MazeSolver {

	private Node goal;


	/**
	 * Reads the input Maze file, builds the graph of Nodes, and uses the specified search algorithm to
	 * search the graph.
	 *
	 * @param args algorithm, maze input file
	 */
	public static void main(String[] args) {
		MazeSolver solver = new MazeSolver();
		Node head = solver.createMaze(args[1]);
		switch (args[0]) {
		case "BFS":
			System.out.println(solver.BFS(head));
			break;
		case "DFS":
			System.out.println(solver.DFS(head));
			break;
		case "BestFirst":
			System.out.println(solver.bestFirst(head));
			break;
		case "AStar":
			System.out.println(solver.aStar(head));
			break;
		case "UP":
			System.out.println(solver.uniquePaths(head));
			break;
		default:
			System.out.println("Error: No algorithm specified\n Options are BFS, DFS, BestFirst, and AStar");
		}

	}

	/**
	 * Implementation of the breadth first search algorithm. The Stack is used for tracing
	 * the Nodes back to the most recently expanded parent in order to determine the path
	 * found by the breadth first traversal.
	 *
	 * @param head initial position of the solver
	 * @return sequence of cell positions to reach the goal
	 */
	private String BFS(Node head) {
		LinkedList<Node> queue = new LinkedList<Node>();
		Stack<Node> stack = new Stack<Node>();
		head.visited();
		queue.add(head);
		int nodesExpanded = 0;
		StringBuilder bfs = new StringBuilder();
		while (!queue.isEmpty()) {
			Node curr = queue.poll();
			stack.push(curr);
			if (curr.getVal() == -1) {
				bfs.append(curr.toString() + "\n");
				stack.pop();
				while (!stack.isEmpty()) {
					Node next = stack.pop();
					if (curr.getParents().contains(next)) {
						bfs.insert(0, next.toString() + "\n");
						curr = next;
					}
				}
				bfs.append("\n");
				bfs.append(nodesExpanded + " nodes expanded");
				return bfs.toString();
			}
			for (Node c : curr.getChildren()) {
				if (!c.hasBeenVisited()) {
					c.visited();
					queue.add(c);
					nodesExpanded++;
				}
			}
		}

		return "Fail";
	}


	/**
	 * Depth-first search of the maze to determine a path from the initial state
	 * to the goal.
	 *
	 * @param head beginnning Node
	 * @return string indicating the path from the initial state to the goal
	 */
	private String DFS(Node head) {
		Stack<Node> stack = new Stack<Node>();
		LinkedList<Node> queue = new LinkedList<Node>();
		dfsRecursive(head, stack, queue);
		StringBuilder dfs = new StringBuilder();
		int nodesExpanded = stack.size();
		Node curr = stack.pop();
		while (curr.getVal() != -1) {
			curr = stack.pop();
		}
		dfs.append(curr.toString() + "\n");
		while (!curr.toString().equals("0, 0")) {
			for (Node n: queue) {
				if (curr.getParents().contains(n)) {
					dfs.insert(0, n.toString() + "\n");
					curr = n;
					break;
				}
			}

		}
		dfs.append("\n");
		dfs.append(nodesExpanded + " nodes expanded");
		return dfs.toString();
	}

	/**
	 * Recursive helper function for DFS. Stack and Queue are not for the algorithm
	 * traversal but do determine the path from the initial state once the goal is
	 * found by the DFS search.
	 *
	 * @param curr current Node
	 * @param stack maintains stack of Nodes for path
	 * @param queue maintains queue of Nodes for path
	 */
	private void dfsRecursive(Node curr, Stack<Node> stack, LinkedList<Node> queue) {
		curr.visited();
		stack.push(curr);
		queue.add(curr);
		if (curr.getVal() == -1) {
			return;
		}
		for (Node c: curr.getChildren()) {
			if (!c.hasBeenVisited()) {
				dfsRecursive(c, stack, queue);

			}

		}

	}


	/**
	 * Best first algorithm that traverses the maze using a priority queue that
	 * ranks nodes based on distance to the goal node.
	 *
	 * @param head initial state
	 * @return String of path from initial state to goal
	 */
	private String bestFirst(Node head) {
		PriorityQueue<Node> queue = new PriorityQueue<Node>();
		StringBuilder bfs = new StringBuilder();
		Stack<Node> path = new Stack<Node>();
		queue.add(head);
		head.visited();
		while (!queue.isEmpty()) {
			Node n = queue.poll();
			path.push(n);
			if (n.getVal() == -1) {
				int nodesExpanded = path.size();
				Node curr = path.pop();
				bfs.append(curr.toString() + "\n");
				while (!path.isEmpty()) {
					Node next = path.pop();
					if (curr.getParents().contains(next)) {
						bfs.insert(0, next.toString() + "\n");
						curr = next;
					}
				}
				bfs.append("\n");
				bfs.append(nodesExpanded + " nodes expanded");
				return bfs.toString();
			} else {
				for (Node c: n.getChildren()) {
					if (!c.hasBeenVisited()) {
						c.visited();
						queue.add(c);
					}
				}
			}

		}

		return "Fail";
	}

	/**
	 * A* search algorithm that incorporates the cost to get to a Node as well
	 * as that Node's distance to the goal as a heuristic function for cost.
	 * Priority queue ranks Nodes by cost for expansion order.
	 *
	 * @param head initial state
	 * @return String of path from initial state to goal
	 */
	private String aStar(Node head) {
		PriorityQueue<Node> queue = new PriorityQueue<Node>();
		StringBuilder aStar = new StringBuilder();
		Stack<Node> path = new Stack<Node>();
		queue.add(head);
		head.visited();
		updateCost(head);
		while (!queue.isEmpty()) {
			Node n = queue.poll();
			path.push(n);
			if (n.getVal() == -1) {
				int nodesExpanded = path.size();
				Node curr = path.pop();
				aStar.append(curr.toString() + "\n");
				while (!path.isEmpty()) {
					Node next = path.pop();
					if (curr.getParents().contains(next)) {
						aStar.insert(0, next.toString() + "\n");
						curr = next;
					}
				}
				aStar.append("\n");
				aStar.append(nodesExpanded + " nodes expanded");
				return aStar.toString();
			} else {
				for (Node c: n.getChildren()) {
					if (!c.hasBeenVisited()) {
						c.visited();
						updateCost(c);
						queue.add(c);
					}
				}
			}

		}

		return "Fail";
	}

	/**
	 * Helper function to update the cost of a Node to reach the goal.
	 *
	 * @param n Node to update cost
	 */
	private void updateCost(Node n) {
		if (n.getDistanceToGoal() != n.getVal()) {
			int cost = n.getDistanceToGoal();
			cost += n.getVal() - n.getDistanceToGoal();
			n.setCost(cost);
		} else {
			n.setCost(1);
		}
		n.setDistanceToGoal(n.getDistanceToGoal() + n.getCost());
	}

	/**
	 * Algorithm to find the number of unique paths from the initial state to the goal.
	 *
	 * @param head initial state
	 * @return number of unique paths from initial state to the goal
	 */
	private String uniquePaths(Node head) {
		HashSet<LinkedList<Node>> pathSet = new HashSet<LinkedList<Node>>();
		LinkedList<Node> path = new LinkedList<Node>();
		ArrayList<Node> expanded = new ArrayList<Node>();
		findAllPaths(head, this.goal, pathSet, path, expanded);
		return pathSet.size() + " unique paths \n" + expanded.size() + " nodes expanded";
	}

	/**
	 * Recursive helper function to find all unique paths from the initial state to the goal.
	 *
	 * @param head initial state
	 * @param goal goal state
	 * @param stats number of paths and nodes expanded
	 */
	private void findAllPaths(Node head, Node goal, HashSet<LinkedList<Node>> pathSet, LinkedList<Node> path, ArrayList<Node> expanded) {
		head.visited();
		if (!expanded.contains(head)) {
			expanded.add(head);
		}
		if (head.equals(goal)) {
			head.visited = false;
			pathSet.add(path);
			return;
		}

		for (Node c: head.getChildren()) {
			if (!c.hasBeenVisited()) {
				path.add(c);
				findAllPaths(c, goal, pathSet, path, expanded);
				path.remove(c);
			}
		}
		head.visited = false;
	}



	/**
	 * Builds the maze from the given input file. Children Nodes act as edges
	 * between Nodes indicating what cells are accessible from a given Node.
	 *
	 * @param fileName Maze input file name
	 * @return head of Nodes representing the maze and its connections
	 */
	private Node createMaze(String fileName) {
		int goalRow = 0, goalCol = 0;
		Scanner fileScanner = null;

		try {
			fileScanner = new Scanner(new File(fileName));
		} catch (FileNotFoundException e) {
			System.err.println(e);
			System.exit(1);
		}
		Node[][] maze = new Node[50][50];
		int numRows = 0, numCols = 0;
		while (fileScanner.hasNextLine()) {
			String next = fileScanner.nextLine();
			String[] split = next.split(",");
			numCols = split.length;
			for (int i = 0; i < numCols; i++) {
				if (split[i].equals("G")) {
					maze[numRows][i] = new Node(-1, numRows, i);
				} else {
					maze[numRows][i] = new Node(Integer.parseInt(split[i]), numRows, i);
				}
			}
			numRows++;
		}
		fileScanner.close();

		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				Node curr = maze[i][j];
				int val = curr.getVal();
				if (val == -1) {
					goalRow = i;
					goalCol = j;
					curr.setDistanceToGoal(0);
					this.goal = curr;
					continue;
				}
				if (i - val >= 0) {
					Node c = maze[i - val][j];
					c.addParent(curr);
					curr.addChild(c);;
				}
				if (i + val < numRows) {
					Node c = maze[i + val][j];
					c.addParent(curr);
					curr.addChild(c);;
				}
				if (j - val >= 0) {
					Node c = maze[i][j - val];
					c.addParent(curr);
					curr.addChild(c);
				}
				if (j + val < numCols) {
					Node c = maze[i][j + val];
					c.addParent(curr);
					curr.addChild(c);
				}
			}

		}

		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				Node n = maze[i][j];
				int colDiff = Math.abs(goalCol - j);
				int rowDiff = Math.abs(goalRow - i);
				int d = colDiff + rowDiff;
				if (goalRow != j) {
					d -= colDiff;
				}
				n.setDistanceToGoal(d);
			}
		}

		return maze[0][0];
	}





	/**
	 * Defines the Node object for representing cells in the Maze that have different integer values
	 * and cells accessible to that Node via hops.
	 *
	 * @author Will Henline
	 *
	 */
	private class Node implements Comparable<Object> {

		/** Integer value of the Node */
		private int val;
		/** List of all Nodes accessible to this Node */
		private ArrayList<Node> children;
		/** Boolean value indicating if this Node has been visited */
		private boolean visited;
		/** Indicates the Nodes row in the maze */
		private int row;
		/** Indicates the Nodes column in the maze */
		private int col;
		/** Parent Node used for determining path through Maze */
		private ArrayList<Node> parents;
		/** Saves the cost for the distance to the goal for this Node using the relaxed movement constraint heuristic */
		private int distanceToGoal;
		/** Cost to reach a given Node */
		private int cost;


		/**
		 * Constructs a new Node given a value.
		 *
		 * @param val Integer value of the Node
		 */
		public Node(int val, int row, int col) {
			this.val = val;
			this.children = new ArrayList<Node>();
			this.visited = false;
			this.parents = new ArrayList<Node>();
			this.row = row;
			this.col = col;
		}

		/**
		 * Adds a parent Node for this Node
		 *
		 * @param p parent Node to be set
		 */
		public void addParent(Node p) {
			this.parents.add(p);
		}


		/**
		 * Returns the parent Nodes for this Node
		 *
		 * @return
		 */
		public ArrayList<Node> getParents() {
			return this.parents;
		}

		/**
		 * Adds a child Node to the list of children for this Node
		 *
		 * @param c Node to add
		 */
		public void addChild(Node c) {
			this.children.add(c);
		}

		/**
		 * Returns the value of the Node.
		 *
		 * @return value of the Node
		 */
		public int getVal() {
			return this.val;
		}

		/**
		 * Returns the cost value for the Node.
		 *
		 * @return cost
		 */
		public int getCost() {
			return this.cost;
		}

		/**
		 * Sets the cost for the Node
		 *
		 * @param cost
		 */
		public void setCost(int cost) {
			this.cost = cost;
		}

		/**
		 * Returns the list of children for this Node.
		 *
		 * @return list of children for this Node
		 */
		public ArrayList<Node> getChildren() {
			return this.children;
		}

		/**
		 * Returns this Nodes distance to the goal using the defined heuristic.
		 *
		 * @return distance to goal
		 */
		public int getDistanceToGoal() {
			return this.distanceToGoal;
		}

		/**
		 * Sets this Nodes distance to the goal
		 *
		 * @param d distance to the goal
		 */
		public void setDistanceToGoal(int d) {
			this.distanceToGoal = d;
		}
		/**
		 * Returns the visited boolean value indicating if the Node has
		 * been visited or not.
		 *
		 * @return boolean value visited
		 */
		public boolean hasBeenVisited() {
			return this.visited;
		}

		/**
		 * Marks this Node as visited.
		 */
		public void visited() {
			this.visited = true;
		}

		/**
		 * Returns the String formatted position of Node in the maze
		 */
		public String toString() {
			return row + ", " + col;
		}

		/**
		 * Method to sort Nodes by distance to the goal for the priority queue
		 */
		@Override
		public int compareTo(Object arg) {
			Node n = (Node) arg;
			if (this.getDistanceToGoal() > n.getDistanceToGoal()) {
				return 1;
			} else if (this.getDistanceToGoal() < n.getDistanceToGoal()) {
				return -1;
			}
			return 0;
		}
	}

}
