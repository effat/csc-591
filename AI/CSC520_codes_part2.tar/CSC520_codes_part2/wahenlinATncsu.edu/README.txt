MazeSolver
CSC 520
Assignment 1

Will Henline, wahenlin

README
------------------------------------------------------------------


This code implements the Breadth-first, Depth-first, Best First and A*
search algorithms in order to find a path through a maze from the initial
state to the goal state.

The code is contained in one class file for convenience

The following commands were run on the NCSU remote servers using Putty

------------------------------------------------------------------
To unzip:

unzip Assignment1.zip


To compile:

javac MazeSolver.java


To run:

java MazeSolver <algorithm> <maze file>


An example command of running the code:

java MazeSolver BFS 4x4Maze-maze.txt


------------------------------------------------------------------

The program will output the path from the initial position to the goal state
by each position in the maze and output the number of states expanded during the
search.

The maze files are located within the zip file so they should not need absolute
path to find the file. 

Algorithm options are:

BFS - Breadth-first search
DFS - Depth-first search
BestFirst - Best First seaarch
AStar - A* search
UP - unique paths for the 6x6 and 8x8 mazes

To accomodate other maze files either add them to the local directory
to be run like the example command or use an absolute path to the file.


