
/*This file takes in input from command line arguments.
 * Argument 0 - Algorithm to run: BFS, DFS, AStar, BestFit and DFSAll(to get number of unique paths)
 * Argument 1 - File name for input (path needs to specified in the code on line 55.
 * 
 * */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

class Node {// State of each cell in the matrix
	int row;
	int col;
	int val;
	Node parent;
	int heuristic;
	boolean flag;

	Node(int i, int j, int value, Node par) {
		row = i;
		col = j;
		val = value;
		parent = par;
		heuristic = Integer.MAX_VALUE;
		flag = true;
	}

	Node(int i, int j, int value, Node par, int heu) {
		row = i;
		col = j;
		val = value;
		parent = par;
		heuristic = heu;
		flag = true;
	}
}

public class BFS {

	static boolean states[][]; static int stateCount=0;// to count states expanded

	public static void main(String[] args) throws FileNotFoundException {
		/* Code to read the input file and save it as a matrix */
		File inputF = new File("D:/SEM 2/AI/Assigments/1/TrainingMazes/" + args[1]); // change path to input file, when
		FileInputStream fis = new FileInputStream(inputF);
		List<String> lines = new ArrayList<>();
		String line = "";
		int rows = 0;
		int cols = 0;

		try (BufferedReader br = new BufferedReader(new InputStreamReader(fis))) {
			while ((line = br.readLine()) != null) {
				lines.add(line);
				rows++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Maze: "+args[0]+" File: "+args[1]);
		String temp[] = lines.get(0).split(",");
		cols = temp.length;
		int matrix[][] = new int[rows][cols];
		int gi = -1, gj = -1;
		for (int i = 0; i < rows; i++) {
			String temp1[] = lines.get(i).split(",");
			for (int j = 0; j < cols; j++) {
				if (temp1[j].equals("G")) {
					matrix[i][j] = -100; // Goal to be reached
					gi = i;
					gj = j;
				} else
					matrix[i][j] = Integer.parseInt(temp1[j]);
			}
		}

		/* switch case statements to call the desired algorithm to run */
		switch (args[0]) {
		case "BFS":
			bfs(matrix, rows, cols);
			break;
		case "DFS":
			dfs(matrix, rows, cols);
			break;
		case "DFSAll":
			dfsAll(matrix, rows, cols);
			break;
		case "AStar":
			astar(matrix, rows, cols, gi, gj);
			break;
		case "BestFit":
			bestfit(matrix, rows, cols, gi, gj);
			break;
		}
		/*End of main class*/
	}

	/* Method to run breadth first search Algorithm */
	public static void bfs(int matrix[][], int rows, int cols) {
		//System.out.println("BFS");
		boolean visited[][] = new boolean[rows][cols]; //Array to check if the cell has been visited or not
		Queue<Node> qn = new LinkedList<Node>(); //Queue for BFS to run
		qn.add(new Node(0, 0, matrix[0][0], null));
		visited[0][0] = true;
		int countStates=0;
		while (qn.peek() != null) {
			/* Dequeue from head of the queue FIFO */
			Node curNode = (Node) qn.remove();
			countStates++; /* When dequeue increment countStates */
			/* If the goal cell is reached, print the path in the reverse order and terminate the algorithm */
			if (curNode.val == -100) {
				Node temp = curNode;
				System.out.println("path");
				while (temp != null) {
					System.out.print(temp.row + "," + temp.col+" ");
					temp = temp.parent;
				}
				/* print all states expanded */
				System.out.println("All states expanded: " +countStates);//statesCount(visited, rows, cols));
				return; 
			}
			/* If the goal is not reached enqueue all the children nodes to the queue if they are unvisited
			 * temp[][] contains all the next reachable cells from the current cell */
			int temp[][] = get_next_move(curNode.row, curNode.col, curNode.val, rows, cols);
			for (int i = 0; i < 4; i++) {
				if ((temp[i][0] != -1 || temp[i][1] != -1) && visited[temp[i][0]][temp[i][1]] == false) {
					/* If cell not already visited add to the queue*/
					Node newNode = new Node(temp[i][0], temp[i][1], matrix[temp[i][0]][temp[i][1]], curNode);
					qn.add(newNode);
					visited[temp[i][0]][temp[i][1]] = true;
				}
			}
		}
		/* End of BFS algorithm */
	}

	/*Start of DFS algorithm using stack */
	public static void dfs(int matrix[][], int rows, int cols) {
		boolean visited[][] = new boolean[rows][cols]; //Array to check if the cell has been visited or not
		Stack<Node> stack = new Stack<Node>(); //Stack to keep track of the frontier
		stack.push(new Node(0, 0, matrix[0][0], null));
		visited[0][0] = true;
		int countStates=0;
		while (!stack.empty()) {
			/* Pop the topmost element from the stack */
			Node curNode = (Node) stack.pop();
			countStates++; /* When dequeue increment countStates */
			/* If the goal cell is reached, print the path and terminate the algorithm */
			if (curNode.val == -100) {
				Node temp = curNode;
				System.out.println("path");
				while (temp != null) {
					System.out.print(temp.row + "," + temp.col+" ");
					temp = temp.parent;
				}
				System.out.println("All states Expanded: " + countStates);//statesCount(visited, rows, cols));
				return;
			}
			/* If the goal is not reached push all the children nodes to the stack if they are unvisited
			 * temp[][] contains all the next reachable cells from the current cell */
			int temp[][] = get_next_move(curNode.row, curNode.col, curNode.val, rows, cols);
			for (int i = 3; i >= 0; i--) { /* Reverse order of states explores as adding to a stack */
				if ((temp[i][0] != -1 || temp[i][1] != -1) && visited[temp[i][0]][temp[i][1]] == false) {
					/* If cell not already visited push to the stack */
					Node newNode = new Node(temp[i][0], temp[i][1], matrix[temp[i][0]][temp[i][1]], curNode);
					stack.push(newNode);
					visited[temp[i][0]][temp[i][1]] = true;
				}
			}
		}
		/*End of DFS algorithm*/
	}

	/* Helper function to count the visited states */
	public static int statesCount(boolean states[][], int rows, int cols) {
		int count = 0;
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				if (states[i][j] == true)
					count++;

		return count;
	}

	/* Start of BestFit algorithm */
	public static void bestfit(int matrix[][], int rows, int cols, int gi, int gj) {
		boolean visited[][] = new boolean[rows][cols]; //Array to check if the cell has been visited or not
		int heuristic[][] = calculateHeuristic(matrix, rows, cols, gi, gj); //Call function to calculate the heuristic for all cells
		PriorityQueue<Node> qn = new PriorityQueue<Node>(rows * cols, idComparator); //Priority queue to extract elements based on min heuristic values
		qn.add(new Node(0, 0, matrix[0][0], null, 0));
		visited[0][0] = true;
		int count = 0;
		while (qn.peek() != null) {
			/* Dequeue the least heuristic cell */
			Node curNode = (Node) qn.poll();
			count++; /* When dequeue increment countStates */
			/* If the goal cell is reached, print the path and terminate the algorithm */
			if (curNode.val == -100) {
				Node temp = curNode;
				System.out.println("path");
				while (temp != null) {
					System.out.print(temp.row + "," + temp.col+" ");
					temp = temp.parent;
				}
				System.out.println("All states expanded: " + count);
				return;
			}
			/* If the goal is not reached enqueue all children nodes if they are unvisited
			 * temp[][] contains all the next reachable cells from the current cell */
			int temp[][] = get_next_move(curNode.row, curNode.col, curNode.val, rows, cols);
			for (int i = 0; i < 4; i++) {
				if ((temp[i][0] != -1 || temp[i][1] != -1) && visited[temp[i][0]][temp[i][1]] == false) {
					/* If cell not visited add to the queue */
					Node newNode = new Node(temp[i][0], temp[i][1], matrix[temp[i][0]][temp[i][1]], curNode,heuristic[temp[i][0]][temp[i][1]]);
					qn.add(newNode);
					visited[temp[i][0]][temp[i][1]] = true;
				}
			}
		}
		/* End of BestFit Algorithm*/
	}

	/* Helper function to calculate the heuristics for bestfirst and astar algorithms
	 * Based on the number of turns the goal cell can be reached in */
	public static int[][] calculateHeuristic(int matrix[][], int rows, int cols, int gi, int gj) {
		int heuristic[][] = new int[rows][cols];
		heuristic[0][0] = 0;
		/* If row or column is equal then hops is 1 else it is 2 */
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				if (i == 0 && j == 0)
					continue;
				else {
					if (i == gi || j == gj)
						heuristic[i][j] = 1;
					else
						heuristic[i][j] = 2;
				}
		return heuristic;
	}

	/* Helper function to calculate hops from a cell (a,b) to cell (c,d) */
	public static int pathCost(int a, int b, int c, int d) {
		if (a == c || b == d)
			return 1;
		else
			return 2;
	}

	/* Start of AStar Algorithm */
	public static void astar(int matrix[][], int rows, int cols, int gi, int gj) {
		boolean visited[][] = new boolean[rows][cols]; //Array to check if the cell has been visited or not
		int heuristic[][] = calculateHeuristic(matrix, rows, cols, gi, gj); //Call function to calculate the heuristic for all cells
		/* Priority queue to extract elements based on min heuristic values */
		PriorityQueue<Node> qn = new PriorityQueue<Node>(rows * cols, idComparator); 
		qn.add(new Node(0, 0, matrix[0][0], null, 0));
		visited[0][0] = true;

		int distance[][] = new int[rows][cols]; //Stores and updates the minimum distance from source to the cell (i,j)
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				distance[i][j] = Integer.MAX_VALUE;
		int count=0;
		while (qn.peek() != null) {
			/* Dequeue the least heuristic cell */
			Node curNode = (Node) qn.poll();
			if (curNode.flag == true) { //Valid entry in the queue
				/* If the goal cell is reached, print the path and terminate the algorithm */
				count++; /* When dequeued element is valid increment countStates */
				if (curNode.val == -100) {
					Node temp = curNode;
					System.out.println("path");
					while (temp != null) {
						System.out.print(temp.row + "," + temp.col+" ");
						temp = temp.parent;
					}
					System.out.println("All states expanded: " +count );
					return;
				}
				/* If the goal is not reached enqueue all children nodes if the distance to visit them from curNode is shorter
				 * temp[][] contains all the next reachable cells from the current cell */
				int temp[][] = get_next_move(curNode.row, curNode.col, curNode.val, rows, cols);
				for (int i = 0; i < 4; i++) {
					/* If direction is possible and the distance to reach that node is smaller -
					 * update the distance and update the heuristic value in queue
					 * pathcost calculates the intermediate cost from current node to child node and adds it to the heuristic */
					if ((temp[i][0] != -1 || temp[i][1] != -1)
							&& distance[temp[i][0]][temp[i][1]] > distance[curNode.row][curNode.col]
									+ pathCost(curNode.row, curNode.col, temp[i][0], temp[i][1])) {
						/* Remove the old distance from the queue and add the new distance */
						removeQ(qn, temp[i][0], temp[i][1]);
						distance[temp[i][0]][temp[i][1]] = distance[curNode.row][curNode.col]
								+ pathCost(curNode.row, curNode.col, temp[i][0], temp[i][1]);
						Node newNode = new Node(temp[i][0], temp[i][1], matrix[temp[i][0]][temp[i][1]], curNode,
								distance[temp[i][0]][temp[i][1]] + heuristic[temp[i][0]][temp[i][1]]);
						qn.add(newNode);
						visited[temp[i][0]][temp[i][1]] = true;

					}
				}

			}
		}
		/* End of Astar algorithm */
	}
	
	/* Algorithm to find all the unique paths using recursive DFS */
	public static void dfsAll(int matrix[][], int rows, int cols) {
		boolean visited[][] = new boolean[rows][cols]; //Array to check if the cell has been visited or not
		states = new boolean[rows][cols]; //to count the states explored
		int count = dfsAllUtil(matrix, rows, cols, visited, 0, new Node(0, 0, matrix[0][0], null)); //helper function for recursive call
		System.out.println("All unique paths: " + count);
		System.out.println("All states Expanded: " + stateCount);
		System.out.println("All unique cells expanded in maze: "+statesCount(states, rows, cols));
	}

	/* Helper function to recursively search the matrix using DFS */
	public static int dfsAllUtil(int matrix[][], int rows, int cols, boolean visited[][], int count, Node curNode) {
		visited[curNode.row][curNode.col] = true;
		states[curNode.row][curNode.col] = true;
		/* Increment unique paths if goal is reached */
		if (curNode.val == -100) {
			count++;
		} else {
			/* If the goal is not reached call DFS on all children nodes if they are unvisited
			 * temp[][] contains all the next reachable cells from the current cell */
			int temp[][] = get_next_move(curNode.row, curNode.col, curNode.val, rows, cols);
			stateCount++; /* increment states */
			for (int i = 3; i >= 0; i--) {
				if ((temp[i][0] != -1 || temp[i][1] != -1) && visited[temp[i][0]][temp[i][1]] == false) {
					Node newNode = new Node(temp[i][0], temp[i][1], matrix[temp[i][0]][temp[i][1]], curNode);
					count = dfsAllUtil(matrix, rows, cols, visited, count, newNode);
				}
			}
		}
		visited[curNode.row][curNode.col] = false;
		return count;
	}/* End of DFSAll algorithm */

	/* Helper function to remove elements from the priority queue by making the flag value false - invalid entry */
	public static void removeQ(PriorityQueue<Node> qn, int i, int j) {
		Iterator itr = qn.iterator();
		while (itr.hasNext()) {
			Node temp = (Node) itr.next();
			if (temp.row == i && temp.col == j && temp.flag == true) {
				// queue.remove(temp);
				temp.flag = false;
			}
		}
	}

	/* Function to get all possible children nodes from current node */
	public static int[][] get_next_move(int iCur, int jCur, int value, int rows, int cols) {
		/* 0 up 1 down 2 left 3 right
		 * 0 contains row 1 contains col
		 * -1 if direction is not possible */
		int dir[][] = new int[4][2];
		if (iCur - value >= 0) { // UP
			dir[0][0] = iCur - value;// row
			dir[0][1] = jCur;// col
		} else {
			dir[0][0] = -1;// row
			dir[0][1] = -1;// col
		}

		if (iCur + value < rows) { // Down
			dir[1][0] = iCur + value;// row
			dir[1][1] = jCur;// col
		} else {
			dir[1][0] = -1;// row
			dir[1][1] = -1;// col
		}

		if (jCur - value >= 0) { // left
			dir[2][0] = iCur;// row
			dir[2][1] = jCur - value;// col
		} else {
			dir[2][0] = -1;// row
			dir[2][1] = -1;// col
		}

		if (jCur + value < cols) { // right
			dir[3][0] = iCur;// row
			dir[3][1] = jCur + value;// col
		} else {
			dir[3][0] = -1;// row
			dir[3][1] = -1;// col
		}

		return dir;

	}
	/* Comparator for priority queue to remove elements based on their heuristic value */
	public static Comparator<Node> idComparator = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			return (int) (c1.heuristic - c2.heuristic);
		}
	};
}
