This document explains the flow of the code and the working of the 4 different algorithms.

Input:
The complete path to the input file needs to be specified on line 56. Otherwise File not Found exception will be thrown.
The file is named "BFS.java" and takes 2 command line arguments as described below.

Output:
Prints the output to the console.
First Line - Prints the algorithm used and the input file name.
Second Line - prints the term "path"
Third Line - Prints the path in reverse order. Each cell is printed (row,column) seperated by a space. Print the total number of states expanded.

A Node class representing a cell in the maze is defined with artibutes as row, coloumn, parent, value and heuristic.
Row, column and value are read from the input file.

The main class (named "BFS") takes in 2 command line arguments. To Run use 2 command line arguments as described below:
Arg[0] contains the algorithm to be run. The options are
"BFS" - To run BFS
"DFS" - To run DFS
"AStar - To run AStar
"BestFit" - To run BestFit
"DFSAll" - To get the number of unique paths using DFS algorithm

Arg[1] contains the file name to read the input file
The complete path to the file needs to be specified on line 56. Otherwise File not Found exception will be thrown.

The main class reads the input file, process the maze and stores it in 2D array (matrix).
It stores the location of the goal state to be used in calculating heuristic later.

This is followed by a switch case statement for calling the corresponding function according to arg[0].

BFS:
The first function defined is the "bfs" function. It does a search of the maze using a queue which is FIFO approach as discussed in class. 
Once the goal cell is reached, it simply prints the path in the reverse order starting from goal cell to the start cell. 
(Can get reverse order by storing it in a list and reversing the list. But this has not been implemented) 
The number of states visited is also tracked using a boolean (visited) 2D array and printed.

DFS:
Similar to BFS DFS uses a Stack that has a LIFO structure as discussed in class. 
Once the goal cell is reached, it simply prints the path in the reverse order starting from goal cell to the start cell. 
(Can get reverse order by storing it in a list and reversing the list. But this has not been implemented) 
The number of states visited is also tracked using a boolean (visited) 2D array and printed.

BestFit:
The cost of the path is the number of hops to reach the goal state.
So, in consistence with the cost above, the heuristic used for the BestFit Algorithm is the minimum number of hops, i.e, the changes in direction required to reach a goal node from the current node.
This heuristic is admissable as it is optimistic, it can never over-estimate as the heuristic always calculates the minimum number of hops required. 
If the column or rows of 2 cells match then the min hops would be 1. Else it would be 2, always forms a rectangle, so one change in direction => 2 hops.

The algorithm first computes all the heuristic values using the above logic and stores it in an array (heuristic). 
The code is impemented using a priorityQueue with the comparator on the heuristic values.
The dequeue operation always returns the node with the minimum heuristic. 
The node removed from the queue is explored and its children and enqueued back into the queue.
Once the goal cell is reached, it simply prints the path in the reverse order starting from goal cell to the start cell. 
(Can get reverse order by storing it in a list and reversing the list. But this has not been implemented) 
The number of states visited is also tracked using a boolean (visited) 2D array and printed.

AStar:
The cost of the path is the number of hops to reach the goal state.
So, in consistence with the cost above, the heuristic used for the AStar Algorithm is the minimum number of hops, i.e, the changes in direction required to reach a goal node from the current node.
This heuristic is admissable as it is optimistic, it can never over-estimate as the heuristic always calculates the minimum number of hops required. 
If the column or rows of 2 cells match then the min hops would be 1. Else it would be 2, always forms a rectangle, so one change in direction => 2 hops. This will give us the required h(n).
For g(n) a helper function (pathCost) is used to calculate pathcost between 2 nodes.

The algorithm first computes all the heuristic values (h(n)) using the above logic and stores it in an array (heuristic). 
The code is impemented using a priorityQueue with the comparator on the heuristic values.
When enqueue is done, the value of the heusristic is calculated as path h(currentNode)+pathCost(from currentNode to child Node)+h(ChildNode). 
If this value is lower than the current heuristic value of the childNode, the value of the heuristic is updated in the matrix as well as the Queue.
This ensures that the dequeue operation always returns the node with the minimum heuristic in the order of enqueue  . 
The node removed from the queue is explored and its children and enqueued back into the queue with the above logic.
Once the goal cell is reached, it simply prints the path in the reverse order starting from goal cell to the start cell. 
(Can get reverse order by storing it in a list and reversing the list. But this has not been implemented) 
The number of states visited is also tracked using a boolean (visited) 2D array and printed.

DFSAll:
This algorithm uses a recursive DFS using the helper funtion (DfsAllUtil) to calculate all the unique paths in the maze. 
The working is similar to the DFS algorithm described above, except thatt his algorithm does not terminate after reaching goal state, but finds more paths.
Once the goal cell is reached, it simply increments the count of the unique paths. 
The number of states visited is also tracked using a boolean (states) 2D array and printed.

The code also has a few helper functions used by many algorithms
statesCount - Takes a bollean array and counts the number of states visited
calculateHeuristic - Helper function to calculate the heuristics for bestfirst and astar algorithms based on the number of hops the goal cell can be reached in.
pathCost - Helper function to calculate hops from a cell (a,b) to cell (c,d)
removeQ -Helper function to remove elements from the priority queue by making the flag value false - invalid entry. used in AStar
get_next_move - Function to get all possible children nodes from current node.

Lastly, a comparator based on heuristic value(to pull the minimum value) is defined for the priority queue.



