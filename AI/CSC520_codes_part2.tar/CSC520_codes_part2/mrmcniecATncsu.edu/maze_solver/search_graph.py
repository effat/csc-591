import logging
logger = logging.getLogger(__name__)

# Matt McNiece
# mrmcniec @ ncsu . edu
# NCSU CSC 520 AI
# Homework 1 - Number Maze Solver

# Module represents a search graph and the search nodes
# Abstracts away state and actions to make algorithm implementation simpler

class SearchNode(object):
    def __init__(self, parent, action, cost=0, state="Not-Explored"):
        self.state = None      # State of node
        self.parent = parent     # Node that generated this node
        self.action = None    # Action applied to parent to generate node
        self.path_cost = cost  # Cost of path from root to this node
        self.set_state(state)
        self.set_action(action)

    def set_state(self, new_state):
        states = ['Expanded', 'Generated', 'Not-Explored']
        if new_state in states:
            self.state = new_state
        else:
            raise KeyError(f"{new_state} not valid state, options are {states}")

    def set_action(self, new_action):
        actions = ["Up", "Down", "Left", "Right", None]
        if new_action in actions:
            self.action = new_action
        else:
            raise Keyerror(f"{new_action} not valid action, options are {actions}")

    def __repr__(self):
        return str({
            "state": self.state,
            "parent": self.parent,
            "action": self.action,
            "path_cost": self.path_cost
        })


class SearchGraph(object):
    def __init__(self, width, height):
        self.graph = dict()
        self._gen_dictionary(width, height)

    def _gen_dictionary(self, width, height):
        logger.debug(f"Generating Graph For {width}x{height} maze")
        self.graph = dict()
        for i in range(width):
            for j in range(height):
                self.graph[(i, j)] = SearchNode(parent=None, action=None, cost=None, state="Not-Explored")
