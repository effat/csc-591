# Matt McNiece
# mrmcniec @ ncsu . edu
# NCSU CSC 520 AI
# Homework 1 - Number Maze Solver

import click
import logging
from collections import deque

# Module is the CLI for the maze solver, handles file input, console output, and calling
# appropriate algorihtms

# mrmcniec written imports
from maze import Maze
from search_graph import SearchNode, SearchGraph
from searches import bfs, dfs, astar, best_first

# Set Up Loigging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
formatter = logging.Formatter(
    '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

@click.command()
# @click.option('-f', '--filename', help="Filename of number maze file", required=True)
# @click.option('-a', '--algorithm', type=click.Choice(["BFS", "DFS", "BestFirst", "AStar"]),
#               help="Algorithm to use", required=True)
@click.argument('filename')
@click.argument('algorithm')
@click.option('-d', '--debug', is_flag=True)
def cli(filename, algorithm, debug):
    supported_algorithms = ["BFS", "DFS", "BestFirst", "AStar"]
    if algorithm not in supported_algorithms:
        logger.critical(f"Unsupported algorithm requested {algorithm}, must choose from {supported_algorithms}")
        exit(-1)

    if debug:
        logger.setLevel(logging.DEBUG)

    logger.debug(f"CLI Called With filename={filename}, alg={algorithm}, debug={debug}")

    # Load File Contents
    with open(filename, 'r') as fp:
        file_contents = [line.strip() for line in fp]

    # Convert Strings to Integers, Leave 'G'
    # data[row][column], remeber 0 index
    file_contents = [item.split(',') for item in file_contents]
    for idx, row in enumerate(file_contents):
        file_contents[idx] = [
            int(item) if item != 'G' else item for item in row]

    logger.debug(f"Loaded Maze from File: {file_contents}")

    maze = Maze(file_contents)

    # Viz Maze
    if debug:
        maze.pretty()
        nodes_to_try = [(0, 0), (2, 2)]
        for node in nodes_to_try:
            logger.debug(f"Node {node} - Up   : {maze.up(*node)}")
            logger.debug(f"Node {node} - Down : {maze.down(*node)}")
            logger.debug(f"Node {node} - Left : {maze.left(*node)}")
            logger.debug(f"Node {node} - Right: {maze.right(*node)}")

    # Initilize the Queue
    queue = deque()
    logger.debug(f"Inital Deque: {queue}")

    # Initialize the Search Graph
    search_graph = SearchGraph(maze.width, maze.height)

    # Call Appropriate Solver Function
    if algorithm == "BFS":
        result = bfs(maze, queue, search_graph)
    elif algorithm == "DFS":
        result = dfs(maze, queue, search_graph)
    elif algorithm == "BestFirst":
        result = best_first(maze, search_graph)
    elif algorithm == "AStar":
        result = astar(maze, queue, search_graph)
    else:
        logger.error(f"Unsupported algorithm, {algorithm}")
        exit(-1)

    logger.debug(f"Got result {result.graph}")

    # Post-Run Analysis
    print(f"---Using {algorithm} found path through {filename}---")

    # Trace The path
    goal_position = maze.goal_position
    current_node = goal_position
    path = [current_node]
    while current_node != (0, 0):
        path.insert(0, result.graph[current_node].parent)
        current_node = path[0]
    print(f"Path from (0, 0) to {goal_position}: {path}")
    print(f"Path Cost: {result.graph[goal_position].path_cost}")

    # States Expanded
    states_expanded = 0
    for key in result.graph:
        if result.graph[key].state == "Expanded":
            states_expanded += 1
    print(f"Expanded {states_expanded} Nodes")


if __name__ == "__main__":
    cli()
