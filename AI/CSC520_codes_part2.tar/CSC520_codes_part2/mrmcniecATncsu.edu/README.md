CSC 520 - Artificial Intelligence

Assignment 1 - Number Mazes + Search

mrmcniec @ ncsu . edu

Matt McNiece

# Number Mazes

## Running Instructions

### Create Virtual Enviornment
```bash
virtualenv -p python3 mazes_venv
source mazes_venv/bin/activate
pip install -r requirements.txt
```

### Run Single Maze/Algo
```bash
python maze_solver/maze_solver.py TrainingMazes/12x12a-maze.txt AStar
```

### Run All Algos on All TrainingMazes
```bash
./test_all.sh
```

## Thoughts to Add All Paths
* Queue tracks nodes
* Graph only keeps root node pointer, rest of stuff is all children
* Add (0, 1) to node