CSC 520 Assignment 01

## How to run using .jar file ##

	General command:
		java -jar mhaque3.jar <Name of algorithm> <File name>

	Example:
		java -jar mhaque3.jar Astar 25x25-maze.txt

	Name of algorithm: 
			 BFS 
			 DFS
			 BestFS
			 Astar

	Input File location: 
		Keep the test files in a directory named "TrainingMazes" that should be located at the same directory of .jar file
			   

## Output Format ##

	For 6x6 & 8x8 mazes:
		Prints all possible path and state expanded count 

		Prints the optimum path and state expanded count for specified algorithm

	For other mazes:
		
		Prints the optimum path and state expanded count for specified algorithm





