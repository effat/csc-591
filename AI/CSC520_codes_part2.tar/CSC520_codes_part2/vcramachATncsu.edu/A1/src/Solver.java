import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.ArrayBlockingQueue;


public class Solver {

	//public Node(int r,int c, int cost,String jump)
	//For reference
	static int num_states=0;
	static int flag;
	static int option;
	static int pathCount;
	static int [][] states; 
	static ArrayList<String[]> m;
	static 
	
	public void writeResult(Node goal, String filename, String algorithm)
	{
		ArrayList<String> coor = new ArrayList<String>();

		try{
			PrintWriter writer;
			//If solution to (a) or (b) subpart, create new file each time writeResult is called.
		
		  writer= new PrintWriter(algorithm+"_solution_"+filename); 
		  while(goal!=null)
			{
				coor.add(goal.r + "," + goal.c +"; ");
				goal=goal.parent;
			}
			
			Collections.reverse(coor); //to order the nodes from start to end
			int i=0;
			while(i<coor.size())
			{
			writer.write(coor.get(i));
			++i;
			}
			writer.write("\n");
			writer.write("Number of states = " + num_states + "\n"); 
			writer.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
		
	}

	public Node BestFirst(ArrayList<String[]> maze, Node start, Node goal)
	{
		
		return null;
	}
	
	public Node AStar(ArrayList<String[]> maze,Node start, Node goal)
	{
		Set<Node> visited = new HashSet<Node>();
		PriorityQueue<Node> q = new PriorityQueue<Node>(); // Node implements comparable and implements compareTo
		int rows = maze.size();
		int cols = maze.get(0).length;
		
		boolean found = false;
		q.add(start);
		while(!q.isEmpty() && found==false)
		{
			
			Node curr = q.peek();
			if(curr.c>=0 && curr.r<maze.get(0).length && curr.r>=0 && curr.c<maze.size())
			{
				int x = curr.r;
				int y = curr.c;
				int jump = Integer.parseInt(maze.get(curr.r)[curr.c]);
				
				//Needs to check cost increase and add heuristic
				q.add(new Node(x-jump,y,curr.cost+1, maze.get(x)[y], curr)); //up 
				q.add(new Node(x+jump,y,curr.cost+1, maze.get(x)[y], curr)); //down
				q.add(new Node(x,y-jump,curr.cost+1, maze.get(x)[y], curr)); //left
				q.add(new Node(x,y+jump,curr.cost+1, maze.get(x)[y], curr)); //right
				
			}
			q.remove();
		}
		
		return null;
	}
	
	public Node BFS(ArrayList<String[]> maze,Node start)
	{
		num_states=0;
		int jump,x,y,cost,i,j;
		int rows = maze.size();
		int cols = maze.get(0).length;
		Queue<Node> q=new LinkedList<Node>();
		int[][] visited= new int[rows][cols];	//2d array to keep track of visited nodes
		for(i=0;i<rows;++i)
		{
			for(j=0;j<cols;++j)
			{
				visited[i][j]=0; //Nodes which haven't been visited are set as 0
			}
		}
		q.add(start); //Add starting node to queue
		while(q.size()!=0)
		{
			Node parent = q.peek();
			x=parent.r;
			y=parent.c;
			if(x>=0 && x<rows && y>=0 && y<cols && visited[x][y]!=1) //Check if the node in the queue is within the maze dimensions
			{
				
			if(maze.get(x)[y].equals("G")) return parent; //return if node is goal and we only want one path [(a) and (b)]
			++num_states;
			
			jump = Integer.parseInt(maze.get(x)[y]);
			
			//Adding all nodes that can be jumped to into the queue
			q.add(new Node(x-jump,y,parent.cost+1, maze.get(x)[y], parent)); //up 
			q.add(new Node(x+jump,y,parent.cost+1, maze.get(x)[y], parent)); //down
			q.add(new Node(x,y-jump,parent.cost+1, maze.get(x)[y], parent)); //left
			q.add(new Node(x,y+jump,parent.cost+1, maze.get(x)[y], parent)); //right
			
			visited[x][y]=1;
			}
			q.remove();
			
		}
		
		return null;
	}
	
	public Node DFS(ArrayList<String[]> maze, Node start)
	{
		num_states=0;
		int jump,x,y,cost,i,j;
		int rows = maze.size();
		int cols = maze.get(0).length;
		int[][] visited= new int[rows][cols];
		Stack<Node> s = new Stack<Node>();//2d array to keep track of visited nodes
		for(i=0;i<rows;++i)
		{
			for(j=0;j<cols;++j)
			{
				visited[i][j]=0; //Nodes which haven't been visited are set as 0
			}
		}
		s.push(start);
		while(!s.isEmpty())
		{
			Node parent = s.peek();
			s.pop();
			x=parent.r;
			y=parent.c;
			if(x>=0 && x<rows && y>=0 && y<cols && visited[x][y]!=1)//Check if the node in the queue is within the maze dimensions
			{
				
			if(maze.get(x)[y].equals("G")) return parent; //the number of states 
			++num_states;
			
			jump = Integer.parseInt(maze.get(x)[y]);
			//Adding all nodes that can be jumped to onto stack
			s.add(new Node(x-jump,y,parent.cost+1, maze.get(x)[y], parent)); //up 
			s.add(new Node(x+jump,y,parent.cost+1, maze.get(x)[y], parent)); //down
			s.add(new Node(x,y-jump,parent.cost+1, maze.get(x)[y], parent)); //left
			s.add(new Node(x,y+jump,parent.cost+1, maze.get(x)[y], parent)); //right
			visited[x][y]=1;
			}
			
		}
		return null;
	}
	
	public void  DFSunique(ArrayList<String[]> maze, Node start)
	{
		int i,j,k;
		m=maze;
		int rows = maze.size();
		int cols = maze.get(0).length;
		int[][] visited= new int[rows][cols]; //2d node visited array for the purpose of the recursive calls
		states = new int[rows][cols]; //2d array to keep track of the nodes which have been explored(number of explored states)
		for(i=0;i<rows;++i)
		{
			for(j=0;j<cols;++j)
			{
				visited[i][j]=0; //Nodes which haven't been visited are set as 0
				states[i][j]=0;
			}
		}
		pathCount=0;
		pathCounter(visited,0,0);
		
	}
	//recursive calls for dfs
	public void pathCounter(int[][] visited,int row, int col)
	{
		visited[row][col]=1; //2d array to keep track of the visited nodes in the current path being checked
		states[row][col]=1;
		if(m.get(row)[col].contains("G"))
		{
			++pathCount;//Increase global pathcount if the node is the goal
		}
		else{
			
		int jump = Integer.parseInt(m.get(row)[col]);
		//conditions for each state being valid and recursive calls for each of them 
		if(row-jump>=0 && visited[row-jump][col]==0)
		{
			pathCounter(visited,row-jump,col); //state above
		}
		if(row+jump<m.size() && visited[row+jump][col]==0)
		{
			pathCounter(visited,row+jump,col); //state below
		}
		if(col-jump>=0 && visited[row][col-jump]==0)
		{
			pathCounter(visited,row,col-jump); //state to the left
		}
		if(col+jump<m.get(0).length && visited[row][col+jump]==0)
		{
			pathCounter(visited,row,col+jump); //state to the right
		}
		}
		visited[row][col]=0;
	}
	public static void main(String[] args) {
		String algorithm = null,file=null;
		option =Integer.parseInt(args[0]); //Input is the option referring to the question to be answered
		if(option==1)//conditional extra arguments
		{
		algorithm = args[1]; //Reads the algorithm that is to be used
		file = args[2]; //File containing input maze
		}
		ArrayList<String[]> maze = new ArrayList<String[]>(); //contains the maze data
		
		if(option==1) //The user wants solutions for subpart (a) and (b)
		//Reading the maze file
		{
			try {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line;
				while ((line = br.readLine()) != null) {
					String[] x = line.split(","); //Parsing text file to create maze 
					maze.add(x);
				}
			}catch(Exception e){
				System.out.println("Error in file read");
			}
			
			Solver solver = new Solver();// Initialize Solver object to call algorithms
		
			Node start = new Node(0,0,0, maze.get(0)[0],null); //initialize start position
			Node goal;
			//The algorithm function is called based on the respective command line arguments
			if(algorithm.matches("BFS")) goal = solver.BFS(maze,start);
		
			else if(algorithm.matches("DFS")) goal = solver.DFS(maze, start);
		
			else goal = solver.BFS(maze, start);
		
			/*while(goal!=null)
			{
			System.out.println(goal.r + "," + goal.c+";");
			goal=goal.parent;
			}*/
			solver.writeResult(goal,file,algorithm);
		}
		else
		{ 
			//Solving both 6x6 and 8x8 to get all unique non cycling paths
			try {
				BufferedReader br = new BufferedReader(new FileReader("6x6Maze.txt"));
				String line;
				while ((line = br.readLine()) != null) {
					String[] x = line.split(","); //Parsing text file to create maze 
					maze.add(x);
				}
				br.close();
			}catch(Exception e){
				System.out.println("Error in file read");
			}
			num_states=0;
			Solver solver = new Solver();// Initialize Solver object to call algorithms
			Node start = new Node(0,0,0, maze.get(0)[0],null); // start position
			solver.DFSunique(maze, start); //calls DFS on 6x6
			for(int i=0;i<6;++i)
			{
				for(int j=0;j<6;++j)
				{
					if(states[i][j]==1)++num_states; //check the count of cells which have been visited
				}
			}
			System.out.println("For the 6x6 maze " + pathCount);
			System.out.println("Number of states :" + num_states);
			pathCount=0; //Reset the value of pathCount to 0 so we can run the same algorithm for 8x8
			
			
			maze=new ArrayList<String[]>();//reset maze so it does not append
			try {
				BufferedReader br = new BufferedReader(new FileReader("8x8-maze.txt"));
				String line;
				while ((line = br.readLine()) != null) {
					String[] x = line.split(","); //Parsing text file to create maze 
					maze.add(x);
				}
				br.close();
			}catch(Exception e){
				System.out.println("Error in file read");
			}
			
			num_states=0;
			start = new Node(0,0,0, maze.get(0)[0],null); // start position
			solver.DFSunique(maze, start); //calls BFS on 8x8
			for(int i=0;i<8;++i)
			{
				for(int j=0;j<8;++j)
				{
					if(states[i][j]==1)++num_states; //check count of cells which have been visited
				}
			}
			System.out.println("For the 8x8 maze " + pathCount);
			System.out.println("Number of states :" + num_states);
			}
	}
	}



