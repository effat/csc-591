
public class Node implements Comparable<Node>{
	//class to represent each state visited
		int r; //Row coordinate
		int c; //Column coordinate
		int cost; //The cost of reaching the current node
		int heuristic; //cost based on heuristic chosen
		Node parent; //Parent of the current node
	
		//Node constructor
		public Node(int r,int c, int cost,String jump, Node parent)
		{
			this.r=r;
			this.c=c;
			this.parent=parent;
			this.cost = cost;
			
		}
		//overload constructor for Node requiring heuristic
		public Node(int r,int c, int cost,String jump, Node parent, int heuristic)
		{
			this.r=r;
			this.c=c;
			this.parent=parent;
			this.cost = cost;
			this.heuristic = heuristic;
			
		}

		@Override
		public int compareTo(Node node) {
			// TODO Auto-generated method stub
			return this.cost+this.heuristic-node.cost-node.heuristic;	//greater then -> positive, less than->negative
		}
	}
