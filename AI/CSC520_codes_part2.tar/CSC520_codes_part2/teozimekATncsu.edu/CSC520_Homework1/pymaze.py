# Name:  Tim Ozimek
# Unity ID:  teozimek
#
# *** NOTE ***
# >>> This is a Python 3.6(.4) program.  You must run with python3 via the command line as described
# >>> below.  As may be known, Python3+ is not backwards compatible with versions before 3.0.  This
# >>> program uses newer features of the language and will not work on older interpreters.
#
# The code has been tested on Cygwin.
#
# This program is called via python3 as:
#
# Usage:  python3 pymaze.py <algorithm> <maze_file>
#     <algorithm> = one of BFS,DFS,BestFirst,AStar
#     <maze_file> = valid text file in correct maze format
#
# An output solution file will be generated with name <input_file_path>.<algorithm>.solution
# It will contain the sequence of steps from start to goal of the number maze.
#
# The algorithm implements 4 search routines:
#   BFS       = Breadth First Search
#   DFS       = Depth First Search
#   BestFirst = Best First (Greedy)
#   AStar     = A Star Algorithm
#
# The heuristic used in BestFirst and AStar is described in the accompanying paper.  It is
# admissible and consistent.
#
# I learned Python in a day or two to crank this out.   My apologies if things could be done
# better.  Constructive criticism is welcome.
#
# The code is simple structured code.  Since I was just learning Python I did not explore its
# object oriented features.  I coded in a style that limits function size to digestible morsels.
# In my years of coding, generally its recommended to let the code document itself.  That's what
# I strived to do here.

import sys 

# Globals -- Most are self-explanatory

shortest_path              = []    # Shortest path part of solution in sequence (array of two entry arrays)
expanded_node_count        = 0  
unique_expanded_node_count = 0
dfs_current_path           = []    # DFS uses global for recursive routines
dfs_shortest_path          = []
dfs_path_found             = 0     
total_unique_paths         = 0   
dfs_e_current_path         = []    # Exhaustive search uses DFS, this holds the current path sequence
dfs_e_shortest_path        = []
dfs_e_path_found           = 0

# Helpful command line message.
def usage( ):
    print("Usage:  python3 pymaze.py <algorithm> <maze_file>")
    print("  <algorithm> = one of BFS,DFS,BestFirst,AStar")
    print("  <maze_file> = valid text file in correct maze format")

# Verify command line arguments.
def validate_command_line( command_line ):
    if( len(command_line) != 3 ):
        print( "Error:  Expecting two arguments after program call." )
        usage( )
        return( False )
    if( sys.argv[1] in ["BFS", "DFS", "BestFirst", "AStar"] ):
        return( [sys.argv[1], sys.argv[2]] )
    else:
        print( f"Error: Invalid <algorithm> option => {sys.argv[1]}" )
        usage( )
        return( False )

# Initialize dictionary that will track the node connections as algorithms run.
def initialize_path_lookup( path_lookup, rows, columns ):
    for r in range(0, rows):
        for c in range(0, columns):
            path_lookup[r, c] = -1

# Get the row and column of the goal node in the maze.
def find_goal_node( maze, rows, columns ):
    for r in range(0, rows):
        for c in range(0, columns):
            if( maze[r][c] == "G" ):
                return( [r,c] )

# A spine is defined as a row and column that contain the goal node.  The heuristic
# optimistically computes potential distance to goal with one lookahead.
def compute_spine_node_costs( goal_row, goal_col, maze, rows, columns, heuristic ):
    for r in range(0, rows):
        if( r != goal_row ):
            node_value = int(maze[r][goal_col])
            if( ((r - node_value) == goal_row) or ((r + node_value) == goal_row) ):
                heuristic[r,goal_col] = 1
            else:
                heuristic[r,goal_col] = 2
    for c in range(0, columns):
        if( c != goal_col ):
            node_value = int(maze[goal_row][c])
            if( ((c - node_value) == goal_col) or ((c + node_value) == goal_col) ):
                heuristic[goal_row,c] = 1
            else:
                heuristic[goal_row,c] = 2

# A non-spine node is any node that is not a spine or goal node.  Optimism and one deep
# lookahead is used to compute
def compute_non_spine_node_costs( goal_row, goal_col, maze, rows, columns, heuristic ):
    # Place all spine tuples in list
    spine_nodes = []
    for r in range(0, rows):
        if( r != goal_row ):
            spine_nodes.append( (r, goal_col) )
    for c in range(0, columns):
        if( c != goal_col ):
            spine_nodes.append( (goal_row, c) )            
    # Examine all non-spine nodes and compute cost
    for r in range(0, rows):
        for c in range(0, columns):
            if( (maze[r][c] == "G") or ((r,c) in spine_nodes) ):
                continue
            node_value = int(maze[r][c])
            if( ((r+node_value,c) in spine_nodes) or
                ((r-node_value,c) in spine_nodes) or
                ((r,c+node_value) in spine_nodes) or
                ((r,c-node_value) in spine_nodes) ):
                heuristic[r,c] = 2
            else:
                heuristic[r,c] = 3

# Compute the heuristic value for each node in the maze.  Store in a dictionary indexed
# by (row, column) tuple.
def compute_node_costs( maze, rows, columns, heuristic ):
    [goal_row, goal_col] = find_goal_node( maze, rows, columns )
    heuristic[goal_row,goal_col] = 0
    compute_spine_node_costs( goal_row, goal_col, maze, rows, columns, heuristic )
    compute_non_spine_node_costs( goal_row, goal_col, maze, rows, columns, heuristic )
                
# Return legal adjacent nodes in correct search order from given node:  Up, Down, Left, Right
# Must be sure that node coordinates are within the maze boundaries.
def build_child_nodes( node, node_moves, rows, columns ):
    child_nodes = []
    up_row = node[0] - node_moves
    down_row = node[0] + node_moves
    left_col = node[1] - node_moves
    right_col = node[1] + node_moves
    if( up_row >= 0 ):
        child_nodes.append([up_row,node[1]])
    if( down_row < rows ):
        child_nodes.append([down_row,node[1]])
    if( left_col >= 0 ):
        child_nodes.append([node[0],left_col])
    if( right_col < columns ):
        child_nodes.append([node[0],right_col])
    return( child_nodes )

# Trace from the last node of the solution through the path_lookup dictionary until
# the first node is found.  Store node elements in the shortest_path list as a 2 element array
# per each node.
def construct_shortest_path( node, path_lookup ):
    while( 1 ):
        shortest_path.insert(0, node)
        node = path_lookup[node[0],node[1]]
        if( node == [0,0] ):
            shortest_path.insert(0, node)
            return( True )

# Algorithm for Breadth First Search taken directly from the book.
# Note that the book expands nodes before checking for the goal as described there.
def run_bfs( maze, rows, columns ):
    global expanded_node_count
    node = [0,0]
    if( maze[node[0]][node[1]] == "G" ):
        return( node )
    frontier = [node]
    explored = []
    path_lookup = {}
    initialize_path_lookup( path_lookup, rows, columns )
    while( 1 ):
        if( len(frontier) == 0 ):
            return False
        node = frontier.pop()
        explored.append(node)
        node_moves = int(maze[node[0]][node[1]])
        expanded_node_count = expanded_node_count + 1
        child_nodes = build_child_nodes( node, node_moves, rows, columns )
        for n in child_nodes:
            if( not((n in frontier) or (n in explored)) ):
                path_lookup[n[0],n[1]] = node
                if( maze[n[0]][n[1]] == "G" ):
                    construct_shortest_path(n, path_lookup)
                    return(True)
                frontier.insert(0, n)

# Run a recursive DFS algorithm until the first path from start to finish is uncovered.
def run_dfs( maze, rows, columns, node ):
    global expanded_node_count
    global dfs_current_path
    global shortest_path
    global dfs_path_found
    dfs_current_path.append( node )
    if( maze[node[0]][node[1]] == "G" ):
        dfs_path_found = 1
        shortest_path = dfs_current_path        
        return( True )
    node_moves = int(maze[node[0]][node[1]])
    expanded_node_count = expanded_node_count + 1
    child_nodes = build_child_nodes( node, node_moves, rows, columns )
    for n in child_nodes:
        if( n in dfs_current_path ):
            continue
        if( run_dfs( maze, rows, columns, n ) == True ):
            return( True )
    dfs_current_path.pop()
    return( False )

# A version of the DFS algorithm that exhaustively searches for all legal paths in the maze.
# Exactly the same as the book describes and a continuation of the above DFS algorithm.
def run_dfs_exhaustive( maze, rows, columns, node ):
    global unique_expanded_node_count
    global dfs_e_current_path
    global dfs_e_shortest_path
    global dfs_e_path_found
    global total_unique_paths
    dfs_e_current_path.append( node )
    if( maze[node[0]][node[1]] == "G" ):
        dfs_e_path_found = 1
        dfs_e_shortest_path = dfs_e_current_path
        total_unique_paths = total_unique_paths + 1
        dfs_e_current_path.pop()
        return( True )
    node_moves = int(maze[node[0]][node[1]])
    unique_expanded_node_count = unique_expanded_node_count + 1
    child_nodes = build_child_nodes( node, node_moves, rows, columns )
    for n in child_nodes:
        if( n in dfs_e_current_path ):
            continue
        if( run_dfs_exhaustive( maze, rows, columns, n ) == True ):
            continue
    dfs_e_current_path.pop()
    return( False )

# For BestFirst this routine determines if a node is in the frontier.
def in_frontier( coord, frontier ):
    for n in frontier:
        if( n[0] == coord ):
            return True
    return False

# For BestFirst this adds a node called coord to the frontier sorted by the heuristic value h.
# The data structure is a priority queue.
def insert_in_frontier( coord, h, frontier ):
    for x in range(0, len(frontier)):
        h_tuple = frontier[x]
        if( h_tuple[1] <= h ):
            frontier.insert(x, (coord,h))
            return
    frontier.append((coord,h))

# For AStar this adds a node called coord to the frontier sorted by the heuristic value h and path
# cost to the given node from the start.  The data structure is a priority queue.
def insert_in_astar_frontier( coord, path_cost, h, frontier ):
    total_cost = path_cost + h
    for x in range(0, len(frontier)):
        h_tuple = frontier[x]
        if( (h_tuple[1] + h_tuple[2]) <= total_cost ):
            frontier.insert(x, (coord,path_cost,h))
            return
    frontier.append((coord,path_cost,h))

# In cases where AStar finds a better path to a node already in the frontier, this routine
# does just that.  If found, the old node is removed and re-inserted with the lower total
# path cost (g(n) + h(n)).
def replace_in_astar_frontier_if_better( n, path_cost, h, frontier ):
    for x in range(0, len(frontier)):
        h_tuple = frontier[x]
        if( h_tuple[0] == n ):
            if( (path_cost + h) < (h_tuple[1] + h_tuple[2]) ):
                del frontier[x]
                insert_in_astar_frontier( n, path_cost, h, frontier )
                return True
    return False

# Algorithm taken from the book to run the Greedy Best First search.
def run_best_first( maze, rows, columns ):
    global expanded_node_count
    heuristic = {}
    compute_node_costs( maze, rows, columns, heuristic ) 
    # Nodes will be stored as tuples:  ([X,Y], h([X,Y]))
    node = ([0,0],heuristic[0,0])
    frontier = [node]
    explored = []
    path_lookup = {}
    initialize_path_lookup( path_lookup, rows, columns )
    while( 1 ):
        if( len(frontier) == 0 ):
            return False
        node = frontier.pop()
        coord = node[0]
        if( maze[coord[0]][coord[1]] == "G" ):
            construct_shortest_path(coord, path_lookup)
            return True
        explored.append(coord)
        node_moves = int(maze[coord[0]][coord[1]])
        expanded_node_count = expanded_node_count + 1
        child_coords = build_child_nodes( coord, node_moves, rows, columns )
        for n in child_coords:
            if( not((n in explored) or (in_frontier( n, frontier ))) ):
                path_lookup[n[0],n[1]] = coord
                insert_in_frontier( n, heuristic[n[0],n[1]], frontier )
            # Heuristic value never changes so second branch of Uniform cost search is not
            # needed here.
            
# Algorithm taken from the book to run the AStar search.
def run_astar( maze, rows, columns ):
    global expanded_node_count
    heuristic = {}
    compute_node_costs( maze, rows, columns, heuristic ) 
    # Nodes will be stored as tuples:  ([X,Y], g(n), h([X,Y]))
    node = ([0,0],0,heuristic[0,0])
    frontier = [node]
    explored = []
    path_lookup = {}
    initialize_path_lookup( path_lookup, rows, columns )
    while( 1 ):
        if( len(frontier) == 0 ):
            return False
        node = frontier.pop()
        coord = node[0]
        if( maze[coord[0]][coord[1]] == "G" ):
            construct_shortest_path(coord, path_lookup)
            return True
        explored.append(coord)
        node_moves = int(maze[coord[0]][coord[1]])
        expanded_node_count = expanded_node_count + 1
        child_coords = build_child_nodes( coord, node_moves, rows, columns )
        for n in child_coords:
            if( not((n in explored) or (in_frontier( n, frontier ))) ):
                path_lookup[n[0],n[1]] = coord
                parent_path_cost = node[1]
                insert_in_astar_frontier( n, parent_path_cost+1, heuristic[n[0],n[1]], frontier )
            elif( replace_in_astar_frontier_if_better( n, parent_path_cost+1, heuristic[n[0],n[1]], frontier ) ):
                path_lookup[n[0],n[1]] = coord

# Reads maze file into memory.  Assumes file exists and is correctly formatted.
def read_maze_file( filename, maze ):
    maze_row_count = 0
    maze_column_count = 0
    file = open(filename, "r")
    for line in file:
        line = line.rstrip()         # Remove newline and whitespace at end
        line = line.replace(" ","")  # Remove all spaces
        row = line.split(",")        # Split row by commas
        if( maze_column_count == 0 ):
            maze_column_count = len(row)   # Count number of columns in maze
        maze.append(row)
        maze_row_count = maze_row_count + 1
    file.close()
    return( maze_row_count, maze_column_count )

# Outputs a solution to solution_filename file.
def write_solution_file( solution_filename, shortest_path ):
    file = open(solution_filename, "w")
    for x in shortest_path:
        file.write("{0},{1}\n".format(x[0],x[1]))
    file.close()

# Brains of operation.
def main():
    vc_result = validate_command_line( sys.argv )
    if( vc_result == False ):
        exit()
    [algorithm,filename] = vc_result
    solution_filename = filename + "." + algorithm + ".solution"
    maze = []
    print(f"Maze file                      = {filename}")
    print(f"Solution output file           = {solution_filename}")
    (maze_row_count,maze_column_count) = read_maze_file( filename, maze )
    print(f"Maze rows x columns            = {maze_row_count} x {maze_column_count}")

    # Only do exhaustive runs when both dimensions of maze are <= 8.
    exhaustive_run = False
    if( (maze_column_count <= 8) and (maze_row_count <= 8) ):
        run_dfs_exhaustive( maze, maze_row_count, maze_column_count, [0,0] )
        exhaustive_run = True

    print(f"Algorithm                      = {algorithm}")
        
    if( algorithm == "BFS" ):
        if( run_bfs( maze, maze_row_count, maze_column_count ) ):
            print(f"Shortest path (length = {len(shortest_path)}):")
            for x in shortest_path:
                print(f"{x[0]},{x[1]}")
    elif( algorithm == "DFS" ):
        run_dfs( maze, maze_row_count, maze_column_count, [0,0] )
        if( dfs_path_found == 1 ):
            print(f"Shortest path (length = {len(shortest_path)}):")
            for x in shortest_path:
                print(f"{x[0]},{x[1]}")
    elif( algorithm == "BestFirst" ):
        if( run_best_first( maze, maze_row_count, maze_column_count ) ):
            print(f"Shortest path (length = {len(shortest_path)}):")
            for x in shortest_path:
                print(f"{x[0]},{x[1]}")          
    elif( algorithm == "AStar" ):
        if( run_astar( maze, maze_row_count, maze_column_count ) ):
            print(f"Shortest path (length = {len(shortest_path)}):")
            for x in shortest_path:
                print(f"{x[0]},{x[1]}")  
    print("Expanded node count            = ",expanded_node_count)
    if( exhaustive_run ):
        print("Total unique paths             = ",total_unique_paths)
        print("Exhaustive expanded node count = ",unique_expanded_node_count)

    write_solution_file( solution_filename, shortest_path ) 
        
        
if __name__=="__main__":
    main()
