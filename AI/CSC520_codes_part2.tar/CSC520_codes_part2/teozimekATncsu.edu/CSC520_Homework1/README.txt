# Name:  Tim Ozimek
# Unity ID:  teozimek
#
# *** NOTE ***
# >>> This is a Python 3.6(.4) program.  You must run with python3 via the command line as described
# >>> below.  As may be known, Python3+ is not backwards compatible with versions before 3.0.  This
# >>> program uses newer features of the language and will not work on older interpreters.
#
# The code has been tested on Cygwin.
#
# This program is called via python3 as:
#
# Usage:  python3 pymaze.py <algorithm> <maze_file>
#     <algorithm> = one of BFS,DFS,BestFirst,AStar
#     <maze_file> = valid text file in correct maze format
#
# An output solution file will be generated with name <input_file_path>.<algorithm>.solution
# It will contain the sequence of steps from start to goal of the number maze.
#
# The algorithm implements 4 search routines:
#   BFS       = Breadth First Search
#   DFS       = Depth First Search
#   BestFirst = Best First (Greedy)
#   AStar     = A Star Algorithm
#
# The heuristic used in BestFirst and AStar is described in the accompanying paper.  It is
# admissible and consistent.
#
# I learned Python in a day or two to crank this out.   My apologies if things could be done
# better.  Constructive criticism is welcome.
#
# The code is simple structured code.  Since I was just learning Python I did not explore its
# object oriented features.  I coded in a style that limits function size to digestible morsels.
# In my years of coding, generally its recommended to let the code document itself.  That's what
# I strived to do here.
