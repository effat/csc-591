The following source code is used to run the maze_solver application for homework assignment 1. The single java file, can be compiled from the command line,
in typical fashion, ie. javac maze_solver.java. The class file will then run with the following commands from the
the command line <algorithm> <input_file_path>. The possible algorithms include "BFS" "DFS" "BestFirst" "AStar" and "Unique". The unique algorithm will run the 
exhaustive search on the particular input file, and output the number of unique paths found, and the number of states expanded to the console. 
The exhaustive search is just an exhaustive implementation of the BFS algorithm. The other algorithms will simply return the first found path, and the number of 
states expanded, to the console. The code has been documented, and hopefully will be clear to follow. This work is my own.
-Anthony Polakiewicz. 