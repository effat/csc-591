import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Scanner;


/**
 * The following is the source file for the maze_solver class which contains the main method for 
 * the maze_solver application. 
 * @author apolaki
 *
 */
public class maze_solver {

	public static int POSSIBLE_DIRECTIONS = 4;

	/**
	 * The main method takes arguments <algorithm> <filepath> from the command line. 
	 * It then reads in the maze from the file path and constructs a 2d array of Node objects
	 * representative of the coordinates on the maze. The method then determines which search
	 * algorithm to run based on the parameter passed from the command line. It is assumed that 
	 * each maze path, will start from the coordinate 0, 0. Thus the maze is passed to the
	 * search algorithm which will return the proper metrics for the search. 
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {

		//obtain algorithm to run
		final String algorithm = args[0];

		//read input file and build 2D matrix of Nodes
		final String file_path = args[1];
		//Scanner s = new Scanner(new File(args[1]));
		Scanner s = new Scanner(new File(file_path));

		//Init value to determine the number of cols and rows
		int rows = 0;
		int cols = 0;
		ArrayList<String[]> list = new ArrayList<String[]>();
		while(s.hasNext()) { // read each line and determine
			String line = s.nextLine();
			String[] row_values = line.split(",");
			list.add(row_values);
			cols = row_values.length;
			rows++;
		}
		s.close();

		//initialize 2D array of nodes and construct and insert each node into the Maze model
		Node[][] maze = new Node[rows][cols];

		for(int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				//get value of coordinate
				String value_string = list.get(i)[j];
				int value;
				if(value_string.equals("G")) {//If goal state, implement node with -1
					value = -1;
				} else {
					value = Integer.parseInt(value_string);
				}
				maze[i][j] = new Node(value, j, i);
			}
		} // maze now initialized
		
		//Run input best search algorithm and output
		//shortest path and number of expanded states. 
		switch(algorithm) {
		case "BFS":
			breadthFirstSearch(maze);
			break;
		case "DFS":
			depthFirstSearch(maze);
			break;
		case "BestFirst":
			bestFirstSearch(maze);
			break;
		case "AStar":
			aStarSearch(maze);
			break;
		case "Unique":
			exhaustiveBreadthFirstSearch(maze);
		}

	}

	/**
	 * The exhaustiveBreadthFirstSearch algorithm is used in order to determine the number of unique
	 * paths through the input maze. The algorithm takes the maze as input. A queue of all possible paths
	 * is initialized. The queue is essentially a bfs queue which holds all unique bfs returned paths through
	 * the maze. This method was an expansion of the breadthFirstSearch method, to be used in an exhaustive case
	 * @param maze 2d array of Nodes
	 */
	@SuppressWarnings("unchecked")
	public static void exhaustiveBreadthFirstSearch(Node[][] maze) {
		//Init queue of paths
		LinkedList<LinkedList<Node>> queue_of_paths = new LinkedList<LinkedList<Node>>();
		
		//Init first path from node (0,0)
		LinkedList<Node> first_path = new LinkedList<Node>();
		first_path.add(maze[0][0]);
		
		//Insert the first path into the queue
		queue_of_paths.addLast(first_path);
		
		//Init the counters for the number of unique states
		// and the number of expanded states
		int num_of_goal_state = 0;
		int num_of_expanded_states = 0;
		
		//Start the BFS algorithm 
		while(!queue_of_paths.isEmpty()) {
			//Pop the first path from the queue
			LinkedList<Node> pop_path = queue_of_paths.removeFirst();
			
			//Get the last node of the path and determinie if goal state
			//is reached
			Node current_state = pop_path.getLast();
			int movement_value = current_state.get_value();
			num_of_expanded_states++;
			//Check if path is complete
			if(current_state.isGoal()) {
				num_of_goal_state++;
			}
			else{ // If not search all possible neighbors of the current state. create new paths for each viable state, and put them in the queue
				for(int i = 0; i < POSSIBLE_DIRECTIONS; i++) {
					switch (i) {
					case 0: //Up neighbor
						if(current_state.get_coord_y() - movement_value >= 0) {
							//Check if visited the neighbor node already on this path
							Node temp_node = maze[current_state.get_coord_y() - movement_value][current_state.get_coord_x()];
							if(!pop_path.contains(temp_node)) {
								LinkedList<Node> new_path = (LinkedList<Node>) pop_path.clone();
								new_path.addLast(temp_node);
								queue_of_paths.addLast(new_path);
							}
						}
						break;
					case 1: //Down neighbor
						if(current_state.get_coord_y() + movement_value < maze.length) {
							//Check if visited the neighbor node already on this path
							Node temp_node = maze[current_state.get_coord_y() + movement_value][current_state.get_coord_x()];
							if(!pop_path.contains(temp_node)) {
								LinkedList<Node> new_path = (LinkedList<Node>) pop_path.clone();
								new_path.addLast(temp_node);
								queue_of_paths.addLast(new_path);
							}
						}
						break;
					case 2: //Left neighbor
						if(current_state.get_coord_x() -  movement_value >= 0) {
							//Check if visited the neighbor node already on this path
							Node temp_node = maze[current_state.get_coord_y()][current_state.get_coord_x() - movement_value];
							if(!pop_path.contains(temp_node)) {
								LinkedList<Node> new_path = (LinkedList<Node>) pop_path.clone();
								new_path.addLast(temp_node);
								queue_of_paths.addLast(new_path);
							}
						}
						break;
					case 3: //Right neighbor
						if(current_state.get_coord_x() + movement_value < maze[0].length) {
							//Check if visited the neighbor node already on this path
							Node temp_node = maze[current_state.get_coord_y()][current_state.get_coord_x() + movement_value];
							if(!pop_path.contains(temp_node)) {
								LinkedList<Node> new_path = (LinkedList<Node>) pop_path.clone();
								new_path.addLast(temp_node);
								queue_of_paths.addLast(new_path);
							}
						}
						break;
					}
				}
			}
		}

		System.out.println("Number of unique paths: " + num_of_goal_state);
		System.out.println("Number of states expanded: " +num_of_expanded_states);

	}

	/**
	 * The following method implements the breadthFirstSearch algorithm on the input maze.
	 * The algorithm is based on the pseudo code found in the text "Artificial Intelligence a Modern Approach"
	 * by Russell and Norvig. The algorithm initializes a queue that will operate using FIFO. The queue
	 * is initialized with the starting state. The viable neighbors of the state inserted into the queue in order
	 * to traverse each node in a breadth first manner. Likewise, a HashSet was used in order to store the states that were
	 * explored or expanded. The algorithm runs until the queue is empty or the shortest path is found. The metrics are then
	 * printed to the console
	 * @param maze 2d Array of Node
	 */
	public static void breadthFirstSearch(Node[][] maze) { 
		ArrayList<Node> shortest_path = null;
		LinkedList<Node> queue = new LinkedList<Node>();
		//Start node visit and enqueue
		queue.addLast(maze[0][0]);

		//Implement a tree set for a list of explored nodes/states
		//TreeSet guarantees retrieval of at worst log n
		HashSet<Node> explored_states = new HashSet<Node>();
		int num_extended_state = 0;
		while(true) {
			num_extended_state++;
			if(queue.size() == 0) {
				break;
			} else {
				//get first node
				Node current_state = queue.removeFirst();
				//visit state
				current_state.visit();
				explored_states.add(current_state);
				int move_value = current_state.get_value();
				if(move_value == -1) {
					shortest_path = goal_found(current_state);
					break;
				}
				//check neighbors of current node
				for(int i = 0; i < POSSIBLE_DIRECTIONS; i++) {
					if(i == 0) {//check up
						//Check boundary of moving up
						if(current_state.get_coord_y() - move_value >= 0) {

							Node temp_child = maze[current_state.get_coord_y() - move_value][current_state.get_coord_x()];
							//check if visited
							if(!queue.contains(temp_child)
									&& !explored_states.contains(temp_child)) {
								//if not in queue or explored mark its predecessor
								temp_child.set_prev(current_state);
								queue.addLast(temp_child);

							}
						}
					}
					else if( i == 1) {//check down
						//Check boundary of moving up 
						if(current_state.get_coord_y() + move_value < maze.length ) {

							Node temp_child = maze[current_state.get_coord_y() + move_value][current_state.get_coord_x()];
							//check if visited
							if(!queue.contains(temp_child)
									&& !explored_states.contains(temp_child)) {
								// if not in queue or explored mark predecessor 
								temp_child.set_prev(current_state);
								queue.addLast(temp_child);
							}
						}
					}
					else if ( i == 2) {//check left
						//Check boundary of moving left
						if(current_state.get_coord_x() - move_value >= 0) {

							Node temp_child = maze[current_state.get_coord_y()][current_state.get_coord_x() - move_value];
							//check if visited
							if(!queue.contains(temp_child)
									&& !explored_states.contains(temp_child)) {
								// if not in queue or explored mark predecessor 
								temp_child.set_prev(current_state);
								queue.addLast(temp_child);

							}

						}

					}
					else if (i == 3) {//check right
						//Check boundary of moving right
						if(current_state.get_coord_x() + move_value < maze[0].length) {

							Node temp_child = maze[current_state.get_coord_y()][current_state.get_coord_x() + move_value];
							//check if visited
							if(!queue.contains(temp_child)
									&& !explored_states.contains(temp_child)) {
								// if not in queue or explored mark predecessor 
								temp_child.set_prev(current_state);
								queue.addLast(temp_child);

							}
						}

					}
				}
			}
		}

		//Print out shortest path
		for(int i = 0; i < shortest_path.size(); i++) {
			System.out.println(shortest_path.get(i).get_coord_y() + "," + shortest_path.get(i).get_coord_x() );
		}
		System.out.println("Number of states expanded: " + num_extended_state);

	}

	/**
	 * The following method is an implementation of the depth first search algorithm on the input
	 * number maze. The algorithm is derived modeled from the BFS algorithm but  working with a stack
	 * (LIFO) to traverse depthwise over the nodes of the maze. 
	 * @param maze 2D array of Node
	 */
	public static void depthFirstSearch(Node[][] maze) {
		//Instantiate the path 
		ArrayList<Node> first_path = null;

		//Instantiate the list that will be used as the stack 
		LinkedList<Node> queue = new LinkedList<Node>();
		queue.addFirst(maze[0][0]);

		//Implement a hash set for a list of explored nodes/states
		HashSet<Node> explored_states = new HashSet<Node>();
		int num_expanded_state = 0;
		//Start depth first search
		while(queue.size() !=0) {
			//Pop stack to get current state
			Node n = queue.removeFirst();
			num_expanded_state++;
			//Visit state and add to explored
			n.visit();
			explored_states.add(n);

			int movement_value = n.get_value();
			if(movement_value == -1) {
				first_path = goal_found(n);
				break;
			}
			//Use movement value to access neighbors
			for(int i = 0; i < POSSIBLE_DIRECTIONS; i++) {
				switch(i) {
				case 3: //Check up
					if(n.get_coord_y() - movement_value >= 0) {
						Node temp_child = maze[n.get_coord_y() - movement_value][n.get_coord_x()];
						//Check if neighbor has been visited or is being visited
						if(!explored_states.contains(temp_child) && !temp_child.was_visited()) {
							//Mark n as the parent and push it onto the stack
							temp_child.set_prev(n);
							queue.addFirst(temp_child);
						}
					}
					break;
				case 2: //Check down
					if(n.get_coord_y() + movement_value < maze.length) {
						Node temp_child = maze[n.get_coord_y() + movement_value][n.get_coord_x()];
						//Check if neighbor has been visited or is being visited
						if(!explored_states.contains(temp_child) && !temp_child.was_visited()) {
							//Mark n as the parent and push it onto the stack
							temp_child.set_prev(n);
							queue.addFirst(temp_child);
						}
					}
					break;
				case 1: //Check left
					if(n.get_coord_x() - movement_value >= 0) {
						Node temp_child = maze[n.get_coord_y()][n.get_coord_x() - movement_value];
						//Check if neighbor has been visited or is being visited
						if(!explored_states.contains(temp_child) && !temp_child.was_visited()) {
							//Mark n as the parent and push it onto the stack
							temp_child.set_prev(n);
							queue.addFirst(temp_child);
						}
					}
					break;
				case 0: //Check right
					if(n.get_coord_x() + movement_value < maze[0].length) {
						Node temp_child = maze[n.get_coord_y()][n.get_coord_x() + movement_value];
						//Check if neighbor has been visited or is being visited
						if(!explored_states.contains(temp_child) && !temp_child.was_visited()) {
							//Mark n as the parent and push it onto the stack
							temp_child.set_prev(n);
							queue.addFirst(temp_child);
						}
					}
					break;
				}
			}

		}
		//Print out shortest path
		for(int i = 0; i < first_path.size(); i++) {
			System.out.println(first_path.get(i).get_coord_y() + "," + first_path.get(i).get_coord_x());
		}
		System.out.println("Number of states expanded: " + num_expanded_state);

	}

	/**
	 * The following is an implementation of the best first search algorithm on the input
	 * number maze. The algorithm uses the get_best heuristic function in order to determine 
	 * which neighbor node is best and implements greedy search based on the heuristic.
	 * @param maze 2D array of Node
	 */
	public static void bestFirstSearch(Node[][] maze) {
		//Instance of possible path
		ArrayList<Node> path = new ArrayList<Node>();
		//Get start node and goal node for heuristic
		Node start_node = maze[0][0];
		//find goal node in maze
		Node goal_node = null;
		boolean goal_node_found = false;
		int num_extended_states = 0;
		for(int i = 0; i < maze.length; i++) {
			for(int j = 0; j < maze[0].length; j++) {
				if(maze[i][j].get_value() == -1) {// found goal
					goal_node = maze[i][j];
					goal_node_found = true;
					break;
				}
			}
			if(goal_node_found) {
				break;
			}
		}
		//Check if goal i initial state
		if(start_node == goal_node) {
			path = goal_found(start_node);
		}
		else {
			//Construct a priority queue such that it will
			//be possible to find the best heuristic weighted move
			ArrayList<Node> queue = new ArrayList<Node>();
			queue.add(start_node);

			while(queue.size() > 0) {
				num_extended_states++;
				// get best
				Node n = get_best(queue, goal_node);

				if(n == goal_node) {//check if we reached goal
					path = goal_found(n);
					break;
				}
				//reset queue for next possible neighbors
				queue = new ArrayList<Node>();
				//Visit the node
				n.visit();
				//Get movement value
				int movement_value = n.get_value();
				//Initialize a check for neighbors.
				//If no neighbors are available, predecessor node
				//will be put back in the queue
				boolean neighbors_avail = false;
				//Check neighbors
				for(int i = 0; i < POSSIBLE_DIRECTIONS; i++) {
					switch(i) {
					case 0://Check up
						if(n.get_coord_y() - movement_value >= 0) {//can we move?
							if(!maze[n.get_coord_y() - movement_value][n.get_coord_x()].was_visited()) {
								//Was up neighbor visited?
								Node temp_node = maze[n.get_coord_y() - movement_value][n.get_coord_x()];
								//Set predecessor of node and put in queue
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;
							}
						}
						break;
					case 1:// Check down
						if(n.get_coord_y() + movement_value < maze.length) {
							//Can we move down
							if(!maze[n.get_coord_y() + movement_value][n.get_coord_x()].was_visited()) {
								//Was down neighbor visited
								Node temp_node = maze[n.get_coord_y() + movement_value][n.get_coord_x()];
								//Set predecessor for backtracking and put in queue
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;

							}
						}
						break;
					case 2://Check left
						if(n.get_coord_x() - movement_value >= 0) {
							//Check neighbor down
							if(!maze[n.get_coord_y()][n.get_coord_x() - movement_value].was_visited()) {
								//was neighbor visited
								Node temp_node = maze[n.get_coord_y()][n.get_coord_x() - movement_value];
								//Set predecessor for backtracking
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;

							}
						}
						break;
					case 3: //Check right
						if(n.get_coord_x() + movement_value < maze[0].length) {
							//Check neighbor right
							if(!maze[n.get_coord_y()][n.get_coord_x() + movement_value].was_visited()) {
								//was neighbor visited
								Node temp_node = maze[n.get_coord_y()][n.get_coord_x() + movement_value];
								//Set predecessor for backtracking
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;
							}
						}
						break;
					}
				}
				if(!neighbors_avail) {//If no neighbors were found, revert back to predecessor
					queue.add(n.get_pred());

				}
			}
		}
		//Print out path
		for(int i = 0; i < path.size(); i++) {
			System.out.println(path.get(i).get_coord_y() + "," + path.get(i).get_coord_x() );
		}
		System.out.println("Number of states expanded: " + num_extended_states);

	}
	/**
	 * The following is the implementation of the A* search algorithm. The algorithm uses the heuristic function and cost
	 * function defined by the get_A_star function. The algorithm does a search based on the return of the heuristic
	 * function indicating the favorable neighbor not to search next. 
	 * @param maze
	 */
	public static void aStarSearch(Node[][] maze) {
		//Instance of possible path
		ArrayList<Node> path = new ArrayList<Node>();
		//Get start node and goal node for heuristic
		Node start_node = maze[0][0];
		//Get diagonal length of maze
		float diagonal = (float) Math.sqrt(Math.pow(maze.length, 2) + Math.pow(maze[0].length, 2));
		//find goal node in maze
		Node goal_node = null;
		boolean goal_node_found = false;
		int num_extended_states = 0;
		for(int i = 0; i < maze.length; i++) {
			for(int j = 0; j < maze[0].length; j++) {
				if(maze[i][j].get_value() == -1) {// found goal
					goal_node = maze[i][j];
					goal_node_found = true;
					break;
				}
			}
			if(goal_node_found) {
				break;
			}
		}
		//Check if goal i initial state
		if(start_node == goal_node) {
			path = goal_found(start_node);
		}
		else {
			//Construct a priority queue such that it will
			//be possible to find the best heuristic weighted move
			ArrayList<Node> queue = new ArrayList<Node>();
			queue.add(start_node);

			while(queue.size() > 0) {
				num_extended_states++;
				// get best
				Node n = get_A_star(queue, goal_node, diagonal);

				if(n == goal_node) {//check if we reached goal
					path = goal_found(n);
					break;
				}
				//reset queue for next possible neighbors
				queue = new ArrayList<Node>();
				//Visit the node
				n.visit();
				//Get movement value
				int movement_value = n.get_value();
				//Initialize a check for neighbors.
				//If no neighbors are available, predecessor node
				//will be put back in the queue
				boolean neighbors_avail = false;
				//Check neighbors
				for(int i = 0; i < POSSIBLE_DIRECTIONS; i++) {
					switch(i) {
					case 0://Check up
						if(n.get_coord_y() - movement_value >= 0) {//can we move?
							if(!maze[n.get_coord_y() - movement_value][n.get_coord_x()].was_visited()) {
								//Was up neighbor visited?
								Node temp_node = maze[n.get_coord_y() - movement_value][n.get_coord_x()];
								//Set predecessor of node and put in queue
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;
							}
						}
						break;
					case 1:// Check down
						if(n.get_coord_y() + movement_value < maze.length) {
							//Can we move down
							if(!maze[n.get_coord_y() + movement_value][n.get_coord_x()].was_visited()) {
								//Was down neighbor visited
								Node temp_node = maze[n.get_coord_y() + movement_value][n.get_coord_x()];
								//Set predecessor for backtracking and put in queue
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;

							}
						}
						break;
					case 2://Check left
						if(n.get_coord_x() - movement_value >= 0) {
							//Check neighbor down
							if(!maze[n.get_coord_y()][n.get_coord_x() - movement_value].was_visited()) {
								//was neighbor visited
								Node temp_node = maze[n.get_coord_y()][n.get_coord_x() - movement_value];
								//Set predecessor for backtracking
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;

							}
						}
						break;
					case 3: //Check right
						if(n.get_coord_x() + movement_value < maze[0].length) {
							//Check neighbor right
							if(!maze[n.get_coord_y()][n.get_coord_x() + movement_value].was_visited()) {
								//was neighbor visited
								Node temp_node = maze[n.get_coord_y()][n.get_coord_x() + movement_value];
								//Set predecessor for backtracking
								temp_node.set_prev(n);
								queue.add(temp_node);
								neighbors_avail = true;
							}
						}
						break;
					}
				}
				if(!neighbors_avail) {//If no neighbors were found, revert back to predecessor
					queue.add(n.get_pred());
					num_extended_states--;

				}
			}
		}
		//Print out path
		for(int i = 0; i < path.size(); i++) {
			System.out.println(path.get(i).get_coord_y() + "," + path.get(i).get_coord_x() );
		}
		System.out.println("Number of states expanded: " + num_extended_states);
	}

	/**
	 * The heuristic defined in the A* search algorithm will be the same as that of the 
	 * best-first search, in that the heuristic will be a weight of the minimum of 
	 * potential steps a node can take to get to the goal. Additionally, the search will now
	 * implement a cost function. The cost function will attempt to drive the search away from the starting 
	 * node, as it will be more costly to move to a node closer to the start than that of a right or down quadrants of
	 * the maze. * This cost was implemented on the idea that the goal state is always either to the right, down or both from the
	 * initial start_node. In order to compute the cost, the general distance from the node to the start is calculated. 
	 * For this, will also weight states that are not . The distance is then normalized to 
	 * the length of the diagonal of the maze. Then the normalized distance is subtracted from one such that shorter 
	 * distances away from the start, will carry a heavier cost. 
	 * @param queue the queue of possible neighbors to select
	 * @param goal_node the goal node of the maze
	 * @param diagonal_length the overall diagonal length of the maze, used to normalize the cost 
	 * @return
	 */
	public static Node get_A_star(ArrayList<Node> queue, Node goal_node, float diagonal_length) {
		//Initialize the node to be returned
		Node min_node = null;
		int steps = 0;
		float cost = 0;
		float steps_plus_cost = 0;
		//Traverse the queue calculating the heuristic + cost for each possible
		//node and comparing to the current min_node in order to find the 
		//overall min of possible neighbors
		for(int i = 0; i < queue.size(); i++) {
			Node temp_node = queue.get(i);
			int temp_steps = 0;
			float temp_cost = 0;
			float temp_steps_plus_cost = 0;
			//calculate heuristic of initial min_node
			if(min_node == null) {
				min_node = temp_node;
				if(goal_node.get_coord_x() == min_node.get_coord_x() && 
						goal_node.get_coord_y() == min_node.get_coord_x()) {
					steps = 0;//goal node found***
					cost = 0;
					steps_plus_cost = 0;

				}
				else if(goal_node.get_coord_x() == min_node.get_coord_x() ||
						goal_node.get_coord_y() == min_node.get_coord_y()){
					steps = 1;
					//Calculate the cost ie measure of how far/close we are to start_node
					float distance_from_start = (float) Math.sqrt(Math.pow(min_node.get_coord_x(), 2) + Math.pow(min_node.get_coord_y(), 2));
					cost = (1 - distance_from_start / diagonal_length);
					steps_plus_cost = steps + cost;
				} else {
					steps = 2;
					//Calculate the cost ie measure of how far/close we are to start_node
					float distance_from_start = (float) Math.sqrt(Math.pow(min_node.get_coord_x(), 2) + Math.pow(min_node.get_coord_y(), 2));
					cost = (1 - distance_from_start / diagonal_length);
					steps_plus_cost = steps + cost;
				}

			} 
			else { //Calculate heuristic for possible next_node
				if(goal_node.get_coord_x() == temp_node.get_coord_x() && 
						goal_node.get_coord_y() == temp_node.get_coord_x()) {
					temp_steps = 0; // Goal node found
					temp_cost = 0;
					temp_steps_plus_cost = 0;
				}
				else if(goal_node.get_coord_x() == temp_node.get_coord_x() ||
						goal_node.get_coord_y() == temp_node.get_coord_y()){
					temp_steps = 1;
					float distance_from_start = (float) Math.sqrt(Math.pow(min_node.get_coord_x(), 2) + Math.pow(min_node.get_coord_y(), 2));
					temp_cost = (1 - distance_from_start / diagonal_length);
					temp_steps_plus_cost = steps + cost;
				} else {
					temp_steps = 2;
					float distance_from_start = (float) Math.sqrt(Math.pow(min_node.get_coord_x(), 2) + Math.pow(min_node.get_coord_y(), 2));
					temp_cost = (1 - distance_from_start / diagonal_length);
					temp_steps_plus_cost = steps + cost;
				}
				if(temp_steps_plus_cost < steps_plus_cost) {
					steps = temp_steps;
					cost = temp_cost;
					steps_plus_cost = temp_steps_plus_cost;
					min_node = temp_node;
				}
			}
		}
		return min_node;

	}


	/**
	 * The heuristic for the best_first search goes off the heuristic underestimate, 
	 * that the goal state is one move away from the current node. Thus, it is either accurate, or an underestimate.
	 * Thus, the heuristic will determine if a node in the list of possible neighbors, 
	 * is a better selection, by whether or not it can reach goal state, zero, in one, or two steps. The
	 * idea is to favor getting on the same, row or column of the goal state as that will be the way to 
	 * reach the goal
	 * @param queue the queue of possible neighbors
	 * @param goal_node the goal node to reach
	 * @return
	 */
	public static Node get_best(ArrayList<Node> queue, Node goal_node) {
		//Init the min_node
		Node min_node = null;
		int steps = 0;

		for(int i = 0; i < queue.size(); i++) {
			Node temp_node = queue.get(i);
			int temp_steps;
			//calculate heuristic of initial min_node
			if(min_node == null) {
				min_node = temp_node;
				if(goal_node.get_coord_x() == min_node.get_coord_x() && 
						goal_node.get_coord_y() == min_node.get_coord_x()) {
					steps = 0;//goal node found***
				}
				else if(goal_node.get_coord_x() == min_node.get_coord_x() ||
						goal_node.get_coord_y() == min_node.get_coord_y()){
					steps = 1;
				} else {
					steps = 2;
				}

			} 
			else { //Calculate heuristic for possible next_node
				if(goal_node.get_coord_x() == temp_node.get_coord_x() && 
						goal_node.get_coord_y() == temp_node.get_coord_x()) {
					temp_steps = 0;
				}
				else if(goal_node.get_coord_x() == temp_node.get_coord_x() ||
						goal_node.get_coord_y() == temp_node.get_coord_y()){
					temp_steps = 1;
				} else {
					temp_steps = 2;
				}
				if(temp_steps < steps) {//compare the heuristic of the node to the possible min node
					steps = temp_steps;
					min_node = temp_node;
				}
			}
		}
		return min_node; //return the node with the minimun heuristic value

	}
	
	/**
	 * The following helper function is used when a goal state is found for the non-exhaustive searches. 
	 * The method traverses from pointer from the goal state to determine the path taken to get there and return 
	 * a it in a list
	 * @param n the goal node
	 * @return path
	 */
	public static ArrayList<Node> goal_found(Node n) {
		//Trace back path to goal by getting predecessor nodes
		ArrayList<Node> path = new ArrayList<Node>();
		Node last_node = n;
		while(last_node != null) {
			path.add(0, last_node);
			Node temp_node = last_node.get_pred();
			last_node = temp_node;
		}
		return path;
	}

	/**
	 * The following the class for each node created for each coordinate of the 
	 * the number maze. The node will include a flag for if it was visited during
	 * search, the value for movement found in the coordinate, the coordinates of the node 
	 * in the maze, a pointer to its predecessor in the shortest path used to find it.
	 * @author apolaki
	 *
	 */
	static class Node {

		private boolean visited;
		private int movement_value;
		private boolean goal;
		private Node predecessor;
		private int x_coord;
		private int y_coord;

		public Node(int value, int x_coord, int y_coord) {
			if( value == -1) { //goal node initialized by -1
				this.goal = true;
			}
			else {
				this.goal = false;
			}
			this.movement_value = value;
			this.x_coord = x_coord;
			this.y_coord = y_coord;
			this.visited = false;
			this.predecessor = null;
		}

		public boolean isGoal() {
			return this.goal;
		}

		public void visit() {
			this.visited = true;
		}

		public boolean was_visited() {
			return this.visited;
		}

		public int get_value() {
			return this.movement_value;
		}

		public void set_prev(Node n) {
			this.predecessor = n;
		}

		public Node get_pred() {
			return this.predecessor;
		}

		public int get_coord_x() {
			return this.x_coord;
		}

		public int get_coord_y() {
			return this.y_coord;
		}

		/**
		 * The following function takes a node and checks to see if the node was
		 * previously in the current path of this node. 
		 * @param n
		 * @return
		 */
		public boolean check_predecessor(Node n) {
			Node prev = this.get_pred();
			while(prev != null) {
				if(prev == n) {
					return true;
				}
				else
					prev = prev.get_pred();
			}
			return false;
		}
	}

}
