import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * Training Maze is a program that solves m x n mazes using uninformed and informed search
 * algorithms.
 * 
 * @author Cameron Nelson
 */
public class TrainingMaze {

	/**
	 * Reads an input maze file, parses it into a 2D array, and calls an appropriate algorithm
	 * of BFS, DFS, BestFirst, or AStar.
	 * 
	 * @param args Command line arguments
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {		
		int width = 0; // Represents rows of the maze
		int length = 0; // Represents columns of the maze
		String line = "";
		Node goalNode = null; // Sets the goal state for Informed algorithms
		
		//Scans the maze file to determine the number of rows and columns of the maze.
		Scanner scanColRow = new Scanner(new File(args[1]));

		while (scanColRow.hasNextLine()) {
			line = scanColRow.nextLine();
			width++;
		}
		
		length = line.split(",").length;
		scanColRow.close();
		
		//Scans the file again to parse the maze. If "G" is found, it is replaced by a 0
		//to represent that the node cannot step anywhere in the maze and that it is goal state.
		Scanner parseMaze = new Scanner(new File(args[1]));
		Node[][] maze = new Node[width][length];
			
		for (int i = 0; i < width; i++) {
			line = parseMaze.nextLine();
			String[] lineChar = line.split(",");
			
			for (int j = 0; j < length; j++) {
				
				if (lineChar[j].equals("G")) {
					lineChar[j] = lineChar[j].replace("G", "0");
					goalNode = new Node(Integer.parseInt(lineChar[j]), i , j, null);
				}
				
				maze[i][j] = new Node(Integer.parseInt(lineChar[j]), i , j, null);
			}
		}
		
		parseMaze.close();
		
		// If the command line argument contains any of the following algorithm names,
		// run the algorithm on the maze (and goalNode if BestFirst or AStar is given).
		// Otherwise, print out the commandline call and exit.
		if (args[0].equalsIgnoreCase("BFS")) {
			BFS(maze);	
		} else if (args[0].equalsIgnoreCase("DFS")) {
			DFS(maze);
		} else if (args[0].equalsIgnoreCase("BestFirst")) {
			bestFirst(maze, goalNode);
		} else if (args[0].equalsIgnoreCase("AStar")) {
			aStar(maze, goalNode);
		} else {
			System.out.println("java TrainingMaze <BFS|DFS|BestFirst|AStar> <mazeFile>");
			System.exit(1);
		}
		
		// Run this if the 6x6 or 8x8 maze is given as a command line argument to determine
		// the total number of unique paths and states expanded in finding the paths using.
		// uniquePath. Those will then be printed to a file in printUniqueResults.
		if((length == 6 && width == 6) || (length == 8 && width == 8)) {
			resetMaze(maze); // Resets the maze to default settings
			Node start = maze[0][0];
			ArrayList<Node> paths = new ArrayList<Node>();
			ArrayList<Node> explored = new ArrayList<Node>();
			explored.add(start);
			uniquePath(start, maze, paths, explored);
			printUniqueResults(paths, explored);
		}
		
	}
	
	/**
	 * Determines the total number of unique paths to a graph and the total number of states
	 * expanded by implementing a recursive DFS algorithm. Note: This method is only used
	 * for 6x6 and 8x8 mazes as per the instructions of the homework.
	 * @param node The current node being visited
	 * @param maze The maze problem
	 * @param paths An array list of unique paths the graph can traverse to until it reaches
	 *              the goal
	 * @param explored An array list of nodes that have been explored/visited in the maze
	 * @throws FileNotFoundException
	 */
	private static void uniquePath(Node node, Node[][] maze, ArrayList<Node> paths, ArrayList<Node> explored) throws FileNotFoundException {
		
		maze[node.col][node.row].visited = true; // Sets in the maze that the node is visiting
		
		// If the current node's step count is equal to 0, or "G", add the node path to paths
		// and set the current node's visit to false in order to find more unique paths
		// that may contain this node.
		if (node.stepCount == 0) {
			paths.add(node);
			maze[node.col][node.row].visited = false;
			return;
		}
		
		// Checks if the node can visit another node by either going up, down, left, and right
		// respectively below. If it can, add it to explored and recursively call the function
		// with the neighboring node as the current node
		if (canVisit(node.col - node.stepCount, node.row, maze)) {
			Node newNode = new Node(maze[node.col - node.stepCount][node.row].stepCount,
					                node.col - node.stepCount, node.row, node);
			explored.add(newNode);
			uniquePath(newNode, maze, paths, explored);
		} 
			
		if (canVisit(node.col + node.stepCount, node.row, maze)) {
			Node newNode = new Node(maze[node.col + node.stepCount][node.row].stepCount,
					                node.col + node.stepCount, node.row, node);
			explored.add(newNode);
			uniquePath(newNode, maze, paths, explored);
		}
			
		if (canVisit(node.col, node.row - node.stepCount, maze)) {
			Node newNode = new Node(maze[node.col][node.row - node.stepCount].stepCount,
								    node.col, node.row - node.stepCount, node);
			explored.add(newNode);
			uniquePath(newNode, maze, paths, explored);
		}
			
		if (canVisit(node.col, node.row + node.stepCount, maze)) {
			Node newNode = new Node(maze[node.col][node.row + node.stepCount].stepCount,
								    node.col, node.row + node.stepCount, node);
			explored.add(newNode);
			uniquePath(newNode, maze, paths, explored);
		}
		
		maze[node.col][node.row].visited = false; // Sets the current node as unvisited to
		                                          // allow for more paths
	}

	/**
	 * Implements the A* algorithm to determine the best path of reaching the goal in a maze.
	 * The heuristic function used in this function is explained in detail on Problem 4.a of
	 * HW1.
	 * @param maze The maze problem
	 * @param goalNode The goal state of the maze. This is primarily used with the heuristic
	 *                 function to determine if the current node is close to the goal state
	 *                 or not.
	 * @throws FileNotFoundException
	 */
	private static void aStar(Node[][] maze, Node goalNode) throws FileNotFoundException {
		Node node = maze[0][0];

		// The compare function of the Priority Queue determines where a Node will be placed
		// by comparing f(n1) - f(n2), where f(n) = g(n) + h(n). g(n) is the total distance
		// from the start of the maze to the current node and h(n) is the heuristic cost.
		PriorityQueue<Node> pq = new PriorityQueue<Node>(new Comparator<Node>() {
			public int compare(Node n1, Node n2) {
		        return (n1.distance + n1.hCost) - (n2.distance + n2.hCost);
		      }
			
		});
		
		pq.add(node);
		node.visited = true;
		ArrayList<Node> explored = new ArrayList<Node>();
		
		// If the current node is the goal state, print the node path with no state expansions
		if (node.stepCount == 0) {
			printResults(node, explored);
		}
		
		while (!pq.isEmpty()) {
			node = pq.remove();
			explored.add(node);
			
			// If the current node is the goal state, print the results of the best
			// path and the number of explored nodes.
			if (node.stepCount == 0) {
				printResults(node, explored);
			}
			
			// Checks if the node can visit another node by either going up, down, left, and
			// right respectively below. If it can, create the neighboring node, set it as
			// visited, determine the heuristic cost of the neighboring node and if
			// it is closer to the goal state, calculate the distance of the neighboring node,
			// and place it in the Priority Queue
			if (canVisit(node.col - node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col - node.stepCount][node.row].stepCount,
						                node.col - node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;				
				newNode.hCost = heuristicFunction(newNode, goalNode);
				newNode.distance = node.stepCount + node.distance;
				pq.add(newNode);
			}
			
			if (canVisit(node.col + node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col + node.stepCount][node.row].stepCount,
						                node.col + node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;		
				newNode.hCost = heuristicFunction(newNode, goalNode);
				newNode.distance = node.stepCount + node.distance;
				pq.add(newNode);
			}
			
			if (canVisit(node.col, node.row - node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row - node.stepCount].stepCount,
						                node.col, node.row - node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				newNode.hCost = heuristicFunction(newNode, goalNode);
				newNode.distance = node.stepCount + node.distance;
				pq.add(newNode);
			}
			
			if (canVisit(node.col, node.row + node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row + node.stepCount].stepCount,
					                    node.col, node.row + node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				newNode.hCost = heuristicFunction(newNode, goalNode);
				newNode.distance = node.stepCount + node.distance;
				pq.add(newNode);
			}
			
		}

	}

	/**
	 * Implements the Best First algorithm to determine the best path of reaching the goal in
	 * a maze. The heuristic function used in this function is explained in detail on
	 * Problem 4.a of HW1.
	 * @param maze The maze problem
	 * @param goalNode The goal state of the maze. This is primarily used with the heuristic
	 *                 function to determine if the current node is close to the goal state
	 *                 or not.
	 * @throws FileNotFoundException
	 */
	private static void bestFirst(Node[][] maze, Node goalNode) throws FileNotFoundException {
		Node node = maze[0][0];
		
		// The compare function of the Priority Queue determines where a Node will be placed
		// by comparing the heuristic costs of two nodes.
		PriorityQueue<Node> pq = new PriorityQueue<Node>(new Comparator<Node>() {
			public int compare(Node n1, Node n2) {
		        return n1.hCost - n2.hCost;
		      }
			
		});
		
		pq.add(node);
		node.visited = true;
		ArrayList<Node> explored = new ArrayList<Node>();
		
		// If the current node is the goal state, print the node path with no state expansions
		if (node.stepCount == 0) {
			printResults(node, explored);
		}
		
		while (!pq.isEmpty()) {
			node = pq.remove();
			explored.add(node);
			
			// If the current node is the goal state, print the results of the best
			// path and the number of explored nodes.
			if (node.stepCount == 0) {
				printResults(node, explored);
			}
			
			if (canVisit(node.col - node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col - node.stepCount][node.row].stepCount,
						                node.col - node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;
				
				newNode.hCost = heuristicFunction(newNode, goalNode);
				pq.add(newNode);
			}
			
			// Checks if the node can visit another node by either going up, down, left, and
			// right respectively below. If it can, create the neighboring node, set it as
			// visited, determine the heuristic cost of the neighboring node and if
			// it is closer to the goal state, and place it in the Priority Queue
			if (canVisit(node.col + node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col + node.stepCount][node.row].stepCount,
						                node.col + node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;
				newNode.hCost = heuristicFunction(newNode, goalNode);
				pq.add(newNode);
			}
			
			if (canVisit(node.col, node.row - node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row - node.stepCount].stepCount,
						                node.col, node.row - node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				newNode.hCost = heuristicFunction(newNode, goalNode);
				pq.add(newNode);
			}
			
			if (canVisit(node.col, node.row + node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row + node.stepCount].stepCount,
					                    node.col, node.row + node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
			
				newNode.hCost = heuristicFunction(newNode, goalNode);
				pq.add(newNode);
			}
		}
	}

	/**
	 * Implements the Breath First Search algorithm to determine the best path of reaching
	 * the goal in a maze.
	 * @param maze The maze problem
	 * @throws FileNotFoundException
	 */
	private static void BFS(Node[][] maze) throws FileNotFoundException {
		Node node = maze[0][0];
		
		Queue<Node> frontier = new LinkedList<Node>();
		frontier.add(maze[0][0]);
		ArrayList<Node> explored = new ArrayList<Node>();
		node.visited = true;
		
		// If the current node is the goal state, print the node path with no state expansions
		if (node.stepCount == 0) {
			printResults(node, explored);
		}
		
		while (!frontier.isEmpty()) {
			node = frontier.remove();
			explored.add(node);
			
			// If the current node is the goal state, print the results of the best
			// path and the number of explored nodes.
			if (node.stepCount == 0) {
				printResults(node, explored);
			}
			
			// Checks if the node can visit another node by either going up, down, left, and
			// right respectively below. If it can, create the neighboring node, set it as
			// visited, and add it to the queue.
			if (canVisit(node.col - node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col - node.stepCount][node.row].stepCount,
						                node.col - node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.add(newNode);
			} 
			
			if (canVisit(node.col + node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col + node.stepCount][node.row].stepCount,
						                node.col + node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.add(newNode);
			}
			
			if (canVisit(node.col, node.row - node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row - node.stepCount].stepCount,
									    node.col, node.row - node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.add(newNode);
			}
			
			if (canVisit(node.col, node.row + node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row + node.stepCount].stepCount,
									    node.col, node.row + node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				
				frontier.add(newNode);
			}
		}
	}
	
	/**
	 * Implements the Depth First Search algorithm to determine the best path of reaching
	 * the goal in a maze.
	 * @param maze The maze problem
	 * @throws FileNotFoundException
	 */
	private static void DFS(Node[][] maze) throws FileNotFoundException {
		Node node = maze[0][0];
		
		Stack<Node> frontier = new Stack<Node>();
		frontier.add(maze[0][0]);
		ArrayList<Node> explored = new ArrayList<Node>();
		node.visited = true;
		
		// If the current node is the goal state, print the node path with no state expansions
		if (node.stepCount == 0) {
			printResults(node, explored);
		}
		
		while (!frontier.isEmpty()) {
			node = frontier.pop();
			explored.add(node);
			
			// If the current node is the goal state, print the results of the best
			// path and the number of explored nodes.
			if (node.stepCount == 0) {
				printResults(node, explored);
			}
			
			// Checks if the node can visit another node by either going up, down, left, and
			// right respectively below. If it can, create the neighboring node, set it as
			// visited, and add it to the stack.
			if (canVisit(node.col - node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col - node.stepCount][node.row].stepCount,
						                node.col - node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;				
				frontier.push(newNode);
			} 
			
			if (canVisit(node.col + node.stepCount, node.row, maze)) {
				Node newNode = new Node(maze[node.col + node.stepCount][node.row].stepCount,
						                node.col + node.stepCount, node.row, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.push(newNode);
			}
			
			if (canVisit(node.col, node.row - node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row - node.stepCount].stepCount,
									    node.col, node.row - node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.push(newNode);
			}
			
			if (canVisit(node.col, node.row + node.stepCount, maze)) {
				Node newNode = new Node(maze[node.col][node.row + node.stepCount].stepCount,
									    node.col, node.row + node.stepCount, node);
				
				maze[newNode.col][newNode.row].visited = true;
				frontier.push(newNode);
			}
		}
	}
	
	/**
	 * Determines if a node can move to another node if it is within the maze boundaries and
	 * does not land on another visited node.
	 * 
	 * @param col The column index
	 * @param row The row index
	 * @param maze The maze problem
	 * @return True if a node can be visited.  False otherwise
	 */
	private static boolean canVisit(int col, int row, Node[][] maze) {
		if (col >= 0 && col < maze.length) {
			if (row >= 0 && row < maze[col].length) {
				if (!maze[col][row].visited) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Determines if a neighboring node is in the same row or column as the goal state. If it
	 * is, then that node has higher priority and should be checked first before any other
	 * nodes.
	 * 
	 * @param node The current node
	 * @param goalNode The goal state of the maze
	 * @return 1 if the current node is in the same column or row as the goal state.  2
	 *         otherwise
	 */
	private static int heuristicFunction(Node node, Node goalNode) {
		if ((node.col == goalNode.col) || (node.row == goalNode.row)) {
			return 1;
		}

		return 2;
	}
	
	/**
	 * Prints the best path and number of expanded states in a given maze problem.
	 * @param node The best path of nodes from the start of the maze to the goal state
	 * @param explored An array list of explored nodes or expanded states
	 * @throws FileNotFoundException
	 */
	private static void printResults(Node node, ArrayList<Node> explored) throws FileNotFoundException {
		ArrayList<Node> nodePath = new ArrayList<Node>();
		
		while (node.getParent() != null) {
			nodePath.add(node);
			node = node.getParent();
		}
		
		nodePath.add(node);
		
		PrintWriter write = new PrintWriter("Path&ExpandedStatesSolution.txt");
		
		write.println("Best Path Solution");
		for (int i = nodePath.size() - 1; i >= 0; i--) {
			write.print(nodePath.get(i).col + ",");
			write.println(nodePath.get(i).row);
		}
		
		write.println("");
		write.println("Expanded States Solution: " + explored.size());
		
		for (int i = 0; i < explored.size(); i++) {
			write.print(explored.get(i).col + ",");
			write.println(explored.get(i).row);
		}
		
		write.close();
	}
	
	/**
	 * Prints the total number of unique paths and each path as well as the total number of
	 * expanded states in order to final all unique paths.
	 * @param paths An array list of unique paths
	 * @param explored An array list of explored nodes or expanded states
	 * @throws FileNotFoundException
	 */
	private static void printUniqueResults(ArrayList<Node> paths, ArrayList<Node> explored) throws FileNotFoundException {
		PrintWriter write = new PrintWriter("UniquePath&ExpandedStatesSolution.txt");
		
		write.println("Total Number of Unique Paths: " + paths.size());
		for (int i = 0; i < paths.size(); i++) {
			ArrayList<Node> nodePath = new ArrayList<Node>();
			Node node = paths.get(i);
			
			while (node.getParent() != null) {
				nodePath.add(node);
				node = node.getParent();
			}
			
			nodePath.add(node);
			
			write.println("Best Unique Path Solution for Path # " + i + 1);
			write.println("Total: " + nodePath.size());
			for (int j = nodePath.size() - 1; j >= 0; j--) {
				write.print(nodePath.get(j).col + ",");
				write.println(nodePath.get(j).row);
			}
			
			write.println("");
		}
		
		write.println("Expanded States Solution: " + explored.size());
		
		for (int j = 0; j < explored.size(); j++) {
			write.print(explored.get(j).col + ",");
			write.println(explored.get(j).row);
		}
		write.close();
	}
	
	/**
	 * Resets the maze problem to its default settings. In other words, each node should keep
	 * only it's column index, row index, and step count. Everything else is either set to
	 * false or 0.
	 * @param maze The maze problem
	 */
	private static void resetMaze(Node[][] maze) {
		for (int i = 0; i < maze.length; i++) {
			for (int j = 0; j < maze[i].length; j++) {
				maze[i][j].visited = false;
				maze[i][j].hCost = 0;
				maze[i][j].distance = 0;
				maze[i][j].parent = null;
			}
		}
	}
	
	/**
	 * The Node class represents cells in the maze. Each Node holds it's location indexes,
	 * the number of steps it can traverse on the maze, whether or not it has been visited or
	 * not, and what its heuristic costs and total distances are.
	 * 
	 * @author Cameron Nelson
	 *
	 */
	public static class Node {
		int row, col;
		int stepCount = 0;
		Node parent;
		boolean visited = false;
		int hCost = 0;
		int distance = 0;
		
		/**
		 * Constructor
		 * @param stepValue The number of steps a node can move on a maze
		 * @param width The row index
		 * @param length The column index
		 * @param parent The parent of the child node
		 */
		public Node(int stepValue, int width, int length, Node parent) {
			stepCount = stepValue;
			row = length;
			col = width;
			this.parent = parent;
		}
		
		/**
		 * Returns the parent of a node.
		 * @return The parent of a node
		 */
		public Node getParent() {
			return parent;
		}
	}
}
