To compile Problem 4 of HW1, implement the following:

1. In a terminal, go to the location to where TrainingMaze.java is located
2. Enter javac TrainingMaze.java
3. Enter java TrainingMaze <BFS|DFS|BestFirst|AStar> <mazeFile>
4. After the code executes, a file called "Path&ExpandedStatesSolution.txt" will be created in
   the same directory as the TrainingMaze program that lists the best path and expanded states
   solutions generated from the given algorithm above.
5. Another file is created only if a 6x6 or 8x8 maze is given called
   "UniquePath&ExpandedStatesSolution.txt". This file lists all unique paths that can be found
   in those mazes and the total number of states expanded to find all paths.