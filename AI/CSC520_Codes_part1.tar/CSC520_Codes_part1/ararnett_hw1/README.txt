Austin Arnett
CSC520 - Artificial Intelligence
Homework 1 - Number Maze Searching

My assignment was written in python and should be launched as follows:

python main.py <search_type> <path_to_maze>


Code Structure Overview:
------------------------

My program takes the search type and maze file as arguments. In the main function,
the maze file is read in and stored in a list of lists. Then the search type is
compared against some globally defined variables to determine which type to use.
The selected algorithm's function is then called to process the maze.


Breadth-First Search:
---------------------

My implementation of BFS uses a queue which starts with only the origin cell. A
check is performed for the base case (the goal node is at 0,0) and exits early if
that case is met.

The main bulk of the algorithm is in a while loop that pops the first path off of
the queue. The last cell of the path is the current node that we will be expanding.
If the current cell is the goal node, the path is output if it is the first path
found. Otherwise, the unique_paths variable is incremented and the rest of the loop
is skipped (the goal cell has no children). The algorithm then requests all cells
that are available to move to from available_spaces().

The spaces returned from available_spaces() are iterated through and each is added
onto its own copy of the current path and pushed to the end of the queue, as long
as the cell hasn't already been visited in the path.


Depth-First Search:
-------------------

My implementation of DFS is split into two functions. One to handle the top level
flow of the algorithm, and the other two handle the recursive nature of the
algorithm. The former simply checks the base case as mentioned in BFS above, adds
the start cell to the path, and calls the recursive function.

The recursive function starts by incrementing the expanded_nodes variable and
getting the current space from the end of the path parameter. If the current
cell is the goal cell, the path is printed the first time a solution is found;
otherwise, the unique_paths variable is incremented.

The algorithm then requests all cells that are available to move to from
available_spaces(). The spaces returned are iterated through and each is added onto
its own copy of the current path and the recursive function is called, as long as
the cell hasn't already been visited in the path.


Best-First Search:
------------------

My implementation of Best-First Search uses a priority queue to track which cell
has the lowest "distance" from the goal cell as provided by heuristic().

The function begins by iterating through the maze to find the goal cell and stores
its location for use by the heuristic function. The start node is then put into
the priority queue. The rest of the function is performed in a while loop that
iterates until the goal is found.

In the while loop, the path with the lowest priority score (highest actual priority)
is popped from the queue. The last cell in the path is the current cell. The current
cell is then checked against the goal cell and the result is printed if it is found.

Otherwise, the algorithm then requests all cells that are available to move to from
available_spaces(). The spaces returned are iterated through and each is added onto
its own copy of the current path and added to the queue with the priority returned
from calling heuristic() on cell, assuming the cell hasn't already been visited in
the current path.


A* Search:
----------

My implementation of A* uses two dictionaries to track the parent of the current
cell and the path cost to the current cell. A unit path cost of 1 is assumed for
each move. The function begins by finding the goal cell and storing it for use in
the heuristic function. The starting node is then put into a priority queue.

A while loop then performs the rest of the algorithm, running until a path is found.
In the while loop the lowest priority path cost cell is popped. This cell is then
checked against the goal node and the results are printed if it matches.

All cells that are avaiable to move to are requested from available_spaces(). The
path cost to these spaces is found or updated based on the current path cost and the
estimate returned by heuristic(). These new paths are then added to the priority queue.


Miscellaneous Functions:
------------------------

main(): Controls the flow for the entire program. Decides which search algorithm
        to use based on the input and reads in the provided maze.

solution(): Outputs the path to a file similar to the one provided.

available_spaces(): Checks if the neighboring cells are reachable based on the
                    current coordinates and the cell's value. A list of valid spaces
                    is returned.

heuristic(): Returns either a 0, 1, 2, or 3 based on the following rules.

0 - The current space is the goal cell
1 - The current space can reach the goal cell in one move.
    This means that the current space is on either the same x or y axis as the
    goal and is the correct number of spaces away.
2 - The current space is on the same x or y axis as the goal but can't reach the
    goal in the next move.
2 - The current space is on a different x and y axis as the goal, but can reach the
    correct axis in the next move.
3 - The current space is on a different x and y axis as the goal and cannot reach
    the correct axis in the next move.


