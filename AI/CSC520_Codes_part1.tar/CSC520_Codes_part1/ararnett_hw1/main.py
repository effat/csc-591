# CSC520 - Artificial Intelligence
# Austin Arnett
# Homework 1 - Number Maze Searching

# Required libraries
import sys
import collections
import heapq
import os

# Search Type Constants
# Listed in: https://moodle-courses1819.wolfware.ncsu.edu/mod/forum/discuss.php?d=191425
DFS = "DFS"
BFS = "BFS"
BEST_FIRST = "BestFirst"
A_STAR = "AStar"


# Global variables for argument inputs
SEARCH_TYPE = ""
INPUT_FILE_LOCATION = ""


# Stores input file path
MAZE_FILE = None

# Store the input file text
FILE_TEXT = ""

# Store the maze values
MAZE = []

# Store the maze goal location
MAZE_GOAL_ROW = 0
MAZE_GOAL_COL = 0

# Store the number of unique paths
UNIQUE_PATHS = 0

# DFS Variables
DFS_EXPANDED_NODES = 0
DFS_PRINTED_FIRST = False


# Print out information about solution
def solution(path_list):
    # Open a file for output adding '-solution' before the extension
    with open(os.path.splitext(INPUT_FILE_LOCATION)[0] + "-solution" + os.path.splitext(INPUT_FILE_LOCATION)[1], 'w') \
            as output_file:
        for path in path_list:
            print >> output_file, path
    # Also print out to the console for easy viewing
    print path_list


# Return the spaces available to move to from the current position
def available_spaces(row, col):
    global MAZE

    # String used to track the cells available for movement
    available_cells = ""

    # Verify a valid location was provided
    if int(row) > len(MAZE):
        print "Invalid maze location"
        return None
    if int(col) > len(MAZE[0]):
        print "Invalid maze location"
        return None

    # Number of cells to move
    distance = MAZE[int(row)][int(col)]

    # DEBUG - Display the distance value in the maze cell
    # print distance

    # Check all directions for valid movement - Force int typing for row and col as input validation

    # Check the cell above
    if(int(row) - int(distance)) >= 0:
        available_cells += str(int(row) - int(distance)) + "," + str(col) + " "

    # Check the cell below
    if(int(row) + int(distance)) < len(MAZE):
        available_cells += str(int(row) + int(distance)) + "," + str(col) + " "

    # Check the cell to the left
    if (int(col) - int(distance)) >= 0:
        available_cells += str(row) + "," + str(int(col) - int(distance)) + " "

    # Check the cell to the right
    if (int(col) + int(distance)) < len(MAZE[int(row)]):
        available_cells += str(row) + "," + str(int(col) + int(distance))

    # DEBUG - Display the cells available for movement
    # print available_cells

    # Remove any trailing whitespace
    return available_cells.strip()


# Breadth-First Search Implementation
def bfs_search():
    global MAZE
    global UNIQUE_PATHS

    paths_queue = collections.deque()

    # Track the number of nodes expanded
    expanded_nodes = 0

    # Track if the first found path has already been displayed
    path_displayed = False

    # Check the base case - The starting node is the Goal node
    if MAZE[0][0] == 'G':
        solution(["0,0"])
        print "Unique Solutions: 1"
        print "States Expanded: 1"

    curr_path = ["0,0"]
    paths_queue.append(curr_path)

    # Make sure there are more paths to check
    while not len(paths_queue) == 0:
        # Get the oldest path in the queue
        current_path = paths_queue.popleft()

        # New expansion, increment the total
        expanded_nodes += 1

        # The last cell in the path is the current cell
        current_space = current_path[len(current_path)-1]
        current = current_space.split(',')
        current_row = current[0]
        current_col = current[1]

        # DEBUG - Display cell coordinates
        # print current_row
        # print current_col

        # If the current cell is the goal, it's a new successful path
        if MAZE[int(current_row)][int(current_col)] == "G":
            UNIQUE_PATHS += 1

            # Check if the path has been output yet
            if not path_displayed:
                solution(current_path)
                print "Number of expansions for first path: " + str(expanded_nodes)
                path_displayed = True
            # There are no children of the goal cell, skip the rest.
            continue

        # Get the list of the children cells available for movement
        new_spaces = available_spaces(current_row, current_col)
        new_spaces_list = new_spaces.split()

        # Iterate through the children cells
        for space in new_spaces_list:
            # Check if the node has already been visited in the current path to avoid infinite looping
            if space not in current_path:
                new_path = current_path[:]
                new_path.append(space)
                paths_queue.append(new_path)

    print "Unique Paths: " + str(UNIQUE_PATHS)
    # Expanded States
    print "States Expanded: " + str(expanded_nodes)


# Depth-First Search Implementation
def dfs_search():
    global MAZE
    global UNIQUE_PATHS

    # Check the base case - The starting node is the Goal node
    if MAZE[0][0] == 'G':
        solution(["0,0"])
        print "Unique Solutions: 1"
        print "States Expanded: 1"

    path = ["0,0"]

    dfs_children(path)

    print "Unique Paths: " + str(UNIQUE_PATHS)
    print "States Expanded: " + str(DFS_EXPANDED_NODES)


# Recursive-call for DFS to check the children of current node
def dfs_children(path):
    global MAZE
    global UNIQUE_PATHS
    global DFS_EXPANDED_NODES
    global DFS_PRINTED_FIRST

    # New graph node expanded
    DFS_EXPANDED_NODES += 1

    # Debug - Display current path
    # print path

    # The last cell in the path is the current cell
    current_space = path[len(path)-1]
    current = current_space.split(',')
    current_row = current[0]
    current_col = current[1]

    # Check if we have reached the end node
    if MAZE[int(current_row)][int(current_col)] == "G":
        UNIQUE_PATHS += 1

        # Print the path, if it is the first successful one
        if not DFS_PRINTED_FIRST:
            solution(path)
            print "States Expanded: " + str(DFS_EXPANDED_NODES)
            DFS_PRINTED_FIRST = True

        # There are no children, return to the parent
        return

    # Get the list of the children cells available for movement
    new_spaces = available_spaces(current_row, current_col)
    new_spaces_list = new_spaces.split()

    # Iterate through the children cells
    for space in new_spaces_list:
        # Check if the node has already been visited in the current path to avoid infinite looping
        if space not in path:
            new_path = path[:]
            new_path.append(space)
            dfs_children(new_path)


# Heuristic function
def heuristic(space):
    global MAZE_GOAL_ROW
    global MAZE_GOAL_COL

    current_space = space.split(',')
    current_row = int(current_space[0])
    current_col = int(current_space[1])

    # Possible return values
    # 0 - The current space is the goal node
    #
    # 1 - The current space can reach the goal node in one move.
    #     This means that the current space is on either the same x or y axis as the goal and is the
    #     correct number of spaces away.
    #
    # 2 - The current space is on the same x or y axis as the goal but can't reach the goal in the next move
    #   - The current space is on a different x and y axis as the goal, but can reach the correct axis in the next move
    #
    # 3 - The current space is on a different x and y axis as the goal and cannot reach the correct axis
    #     in the next move.

    # Return 0 distance if current space is the goal
    if current_row == MAZE_GOAL_ROW and current_col == MAZE_GOAL_COL:
        return 0

    # Check if the current space is on the same axis as the goal and can reach the goal in one move
    # Same row, different column
    if current_row == MAZE_GOAL_ROW:
        if str(abs(int(MAZE_GOAL_COL) - int(current_col))) == MAZE[current_row][current_col]:
            return 1
        else:
            return 2
    # Same column, different row
    if current_col == MAZE_GOAL_COL:
        if str(abs(int(MAZE_GOAL_ROW) - int(current_row))) == MAZE[current_row][current_col]:
            return 1
        else:
            return 2

    # Different column and row
    if str(abs(int(MAZE_GOAL_ROW) - int(current_row))) == MAZE[current_row][current_col] or \
       str(abs(int(MAZE_GOAL_COL) - int(current_col))) == MAZE[current_row][current_col]:
        return 2
    else:
        return 3


# Best First Search Implementation
def best_first_search():
    global MAZE
    global MAZE_GOAL_ROW
    global MAZE_GOAL_COL

    # Track the number of expansions
    expanded_nodes = 0

    # Find the goal space for use in the heuristic
    goal_found = False
    for row in range(0, len(MAZE)):
        for col in range(0, len(MAZE[0])):
            if MAZE[row][col] == "G":
                MAZE_GOAL_ROW = row
                MAZE_GOAL_COL = col
                goal_found = True
                break
        if goal_found:
            break


    # Debug - Display the heuristic's values for each cell
    # for row in range(0, len(MAZE)):
    #     for col in range(0, len(MAZE[0])):
    #        print str(row) + "," + str(col) + ": " + str(heuristic(str(row) + "," + str(col)))

    # Debug - Display goal location
    # print "Goal: " + str(MAZE_GOAL_ROW) + "," + str(MAZE_GOAL_COL)

    queue = []
    heapq.heappush(queue, (0, ["0,0"]))

    while not len(queue) == 0:
        unused_priority, path = heapq.heappop(queue)

        expanded_nodes += 1

        current_space = path[len(path) - 1].split(',')
        current_row = current_space[0]
        current_col = current_space[1]

        if MAZE[int(current_row)][int(current_col)] == "G":
            solution(path)
            print "Number of expansions: " + str(expanded_nodes)
            break

        new_spaces = available_spaces(current_row, current_col)
        new_spaces_list = new_spaces.split()

        for space in new_spaces_list:
            if space not in path:
                priority = heuristic(space)
                new_path = path[:]
                new_path.append(space)
                heapq.heappush(queue, (priority, new_path))


# A* Implementation
def a_star_search():
    global MAZE
    global MAZE_GOAL_ROW
    global MAZE_GOAL_COL

    # Track the number of expansions
    expanded_nodes = 0

    # Create a dictionary to track the parents of each cell
    parent_list = {}
    parent_list["0,0"] = None

    # Create a dictionary to track the cost to the current cell and whether the cell is in the "closed" list
    visited_list = {}
    visited_list["0,0"] = 0

    # Find the goal space for use in the heuristic
    goal_found = False
    for row in range(0, len(MAZE)):
        for col in range(0, len(MAZE[0])):
            if MAZE[row][col] == "G":
                MAZE_GOAL_ROW = row
                MAZE_GOAL_COL = col
                goal_found = True
                break
        if goal_found:
            break

    # Debug - Display the heuristic's values for each cell
    # for row in range(0, len(MAZE)):
    #     for col in range(0, len(MAZE[0])):
    #        print str(row) + "," + str(col) + ": " + str(heuristic(str(row) + "," + str(col)))

    # Debug - Display goal location
    # print "Goal: " + str(MAZE_GOAL_ROW) + "," + str(MAZE_GOAL_COL)

    # Add the starting node and it's cost to the priority queue
    queue = []
    heapq.heappush(queue, (visited_list["0,0"], "0,0"))

    # Run until the path is found
    while not len(queue) == 0:
        # Get the cheapest cell
        unused_priority, current = heapq.heappop(queue)

        # A node was expanded, increment
        expanded_nodes += 1

        # Get the coordinates for the current space
        current_space = current.split(',')
        current_row = current_space[0]
        current_col = current_space[1]

        # The goal cell was found
        if MAZE[int(current_row)][int(current_col)] == "G":
            # Start a list of the path cells
            path = [current]

            # Iterate backwards through the path adding each cell
            parent = current
            while not parent_list[parent] == "0,0":
                parent = parent_list[parent]
                path.insert(0, parent)
            # Add the starting cell
            path.insert(0, "0,0")

            # Display the required results
            solution(path)
            print "Number of expansions: " + str(expanded_nodes)
            break

        # Get the spaces available for movement
        new_spaces = available_spaces(current_row, current_col)
        new_spaces_list = new_spaces.split()

        # Iterate through the available spaces calculating the cost for each
        for space in new_spaces_list:
            # Assuming a constant movement cost of 1
            new_cost = visited_list[current] + 1

            # If the space hasn't been visited or a cheaper path to it was found, add the new path and update the parent
            if space not in visited_list or new_cost < visited_list[space]:
                # Update the cost
                visited_list[space] = new_cost
                # Calculate the new priority/cost
                priority = new_cost + heuristic(space)

                # Add the new path to the queue
                heapq.heappush(queue, (priority, space))

                # Update the parent of the cell
                parent_list[space] = current


# Main Function - Control over program flow
def main():
    # Set global variables for use in function
    global SEARCH_TYPE
    global INPUT_FILE_LOCATION
    global MAZE_FILE
    global FILE_TEXT
    global MAZE

    # Grab the input arguments
    SEARCH_TYPE = sys.argv[1]
    INPUT_FILE_LOCATION = sys.argv[2]

    # DEBUG - Verify correct inputs
    # print "Search Type: " + SEARCH_TYPE
    # print "Input File: " + INPUT_FILE_LOCATION

    # Open the file for reading
    MAZE_FILE = open(INPUT_FILE_LOCATION, "r")
    FILE_TEXT = MAZE_FILE.read()

    # DEBUG - Verify input
    # print FILE_TEXT

    # Store the maze values into a multi-dimensional list
    lines = FILE_TEXT.split('\n')
    for line in lines:
        # Skip the trailing newline
        if line == '':
            continue
        row = []
        values = line.split(',')
        for value in values:
            row.append(value)
        MAZE.append(row)

    # DEBUG - Print maze values
    # print MAZE

    # Select the sorting function based on the input
    if SEARCH_TYPE == BFS:
        bfs_search()
    elif SEARCH_TYPE == DFS:
        dfs_search()
    elif SEARCH_TYPE == BEST_FIRST:
        best_first_search()
    elif SEARCH_TYPE == A_STAR:
        a_star_search()
    else:
        print "Invalid Search Type Provided. Exiting."
        exit()


# Run Main Function
if __name__ == "__main__":
    main()
