import sys
from collections import deque
import heapq
import itertools

# Default to only print the solution
verbose = 0
expanded_count = 0

# Default to not counting the total unique paths with BFS
count_total_unique = 0

# Number of total unique paths to the goal
total_unique = 0


# Representation of a node
class Node:
    def __init__(self, state, parent, action, path_cost):
        self.state = state
        self.parent = parent
        self.action = action
        self.path_cost = path_cost


# Converts a line of the board represented as a string and returns a row represented as a list
# of numbers and 'G' characters
def line_to_row(line):
    str_row = line.split(',')
    row = []

    for str in str_row:
        if 'G' in str:
            row.append('G')
        else:
            row.append(int(str))

    return row


# Determines if the given state is a goal state
def goal_test(state, board):
    return board[state[0]][state[1]] == 'G'


# Takes a node which is assumed to have passed the goal test and prints the path to this node
def solution(node):
    # Solution will always end with the passed in node.state
    sol = [node.state]

    # Follow parent pointers to map out the path
    parent = node.parent
    while parent is not None:
        sol.append(parent.state)
        parent = parent.parent

    # Reverse list
    sol.reverse()

    return sol


# Returns a list of legal actions given a state, or None if the state is a goal state
def actions(state, board):
    if goal_test(state, board):
        return None

    # Get dimensions of the board
    n_rows = len(board)
    n_cols = len(board[0])

    # Read the magnitude of movement from the board
    magnitude = board[state[0]][state[1]]

    legal_moves = []
    if state[0] + magnitude <= (n_rows - 1):
        legal_moves.append('down')
    if state[0] - magnitude >= 0:
        legal_moves.append('up')
    if state[1] + magnitude <= (n_cols - 1):
        legal_moves.append('right')
    if state[1] - magnitude >= 0:
        legal_moves.append('left')

    # Actions are represented as dictionaries containing a direction and magnitude
    actions = []
    for move in legal_moves:
        actions.append({'direction': move, 'magnitude': magnitude})

    return actions


# Takes a state and an action and returns the new state which is reached by
# performing the given action at the given state. Assumes that the action is legal
# in the given state
def result(state, action):
    # First component in the new state
    i = None
    # Second component in the new state
    j = None

    # Determine new state based on action
    if action['direction'] == 'left':
        j = state[1] - action['magnitude']
        i = state[0]
    elif action['direction'] == 'right':
        j = state[1] + action['magnitude']
        i = state[0]
    elif action['direction'] == 'up':
        i = state[0] - action['magnitude']
        j = state[1]
    elif action['direction'] == 'down':
        i = state[0] + action['magnitude']
        j = state[1]

    return (i, j)


# Creates a new child node based on the parent node and the chosen action
# Note that the step cost for this problem is always 1
def child_node(parent, action):
    child = Node(state=result(parent.state, action),
                 parent=parent,
                 action=action,
                 path_cost=parent.path_cost + 1)
    return child


# Helper function to check if a given state is in a specified frontier
def state_in_frontier(state, frontier):
    for n in frontier:
        if n.state == state:
            return True
    return False


# Runs the breadth first search algorithm on the given board. Returns a list of states that define
# the shortest path
# Or -1 if there is no path to the goal
def breadth_first_search(board):
    # Initial starting state
    init_state = (0, 0)

    # Create root node
    node = Node(state=init_state, parent=None, action=None, path_cost=0)

    # Test initial state for goal state
    if goal_test(node.state, board):
        return solution(node)

    # Set up the frontier as a FIFO queue
    frontier = deque()
    frontier.append(node)

    # Set up the explored as a hash set of states (which are tuples of indexes into the board)
    explored = set()

    while True:
        # If the frontier is empty, there is no path to the goal
        if len(frontier) == 0:
            return -1

        # Choose shallowest node in the frontier to expand
        node = frontier.popleft()

        # Count number of expanded nodes if requested
        if verbose == 1:
            global expanded_count
            expanded_count += 1

        # Add to explored set
        explored.add(node.state)

        # For each possible action at the current state
        for action in actions(node.state, board):
            # Create child node
            child = child_node(parent=node, action=action)

            # Avoid redundant paths
            if child.state not in explored and not state_in_frontier(child.state, frontier):
                # Goal test applied when child is generated, not when selected for expansion
                if goal_test(child.state, board):
                    return solution(child)

                frontier.append(child)


# Runs the depth first search algorithm on the given board. Returns a list of states that define
# the first path found by the algorithm
# Or -1 if there is no path to the goal
def depth_first_search(board):
    # Initial starting state
    init_state = (0, 0)

    # Create root node
    node = Node(state=init_state, parent=None, action=None, path_cost=0)

    # Test initial state for goal state
    if goal_test(node.state, board):
        return solution(node)

    # Set up the frontier as a FIFO queue
    frontier = deque()
    frontier.append(node)

    # Set up the explored as a hash set of states (which are tuples of indexes into the board)
    explored = set()

    while True:
        # If the frontier is empty, there is no path to the goal
        if len(frontier) == 0:
            return -1

        # Choose deepest node in the frontier LIFO structure to expand
        node = frontier.pop()

        # Count number of expanded nodes if requested
        if verbose == 1:
            global expanded_count
            expanded_count += 1

        # Goal test applied when node selected for expansion
        if goal_test(node.state, board):
            return solution(node)

        # Add to explored set
        explored.add(node.state)

        # For each possible action at the current state
        for action in actions(node.state, board):
            # Create child node
            child = child_node(parent=node, action=action)

            # Avoid redundant paths and repeated states
            if child.state not in explored and not state_in_frontier(child.state, frontier):
                frontier.append(child)


# Runs the depth first tree search algorithm to find all unique paths to the solution
# Returns the number of unique paths to the solution
def depth_first_tree_search(board):
    global total_unique

    # Initial starting state
    init_state = (0, 0)

    # Create root node
    node = Node(state=init_state, parent=None, action=None, path_cost=0)

    # Test initial state for goal state
    if goal_test(node.state, board):
        return 1

    # Set up the frontier as a FIFO queue
    frontier = deque()
    frontier.append(node)

    while True:
        # If the frontier is empty, there is no path to the goal
        if len(frontier) == 0:
            return total_unique

        # Choose deepest node in the frontier LIFO structure to expand
        node = frontier.pop()

        # Count number of expanded nodes if requested
        if verbose == 1:
            global expanded_count
            expanded_count += 1

        # Goal test applied when node selected for expansion
        if goal_test(node.state, board):
            total_unique += 1
            # Counting all unique paths to the goal node. We want to stop each path at the goal node, so don't expand
            continue

        # For each possible action at the current state
        for action in actions(node.state, board):
            # Create child node
            child = child_node(parent=node, action=action)

            # Avoid infinite loops by checking new states against those on the path from the root
            # to the current node
            if child.state not in solution(node):
                frontier.append(child)


# Returns the estimated cost to the goal state, with the relaxed constraint that the player
# can move any number of spaces in a direction in a single move
def heuristic_function(state, board, goal_state):
    # If already at the goal state
    if goal_test(state, board):
        return 0
    # If on the same row or column as the goal state
    if state[0] == goal_state[0] or state[1] == goal_state[1]:
        return 1
    return 2


# Runs the best first search algorithm on the given board. Returns a list of states that define
# the first path found by the algorithm
# Or -1 if there is no path to the goal
def best_first_search(board, goal_state):

    # Credit to using heapq as a priority queue to API documentation for python standard library:
    # https: // docs.python.org / 3 / library / heapq.html

    # Set up the frontier as a priority queue ordered by h(n)
    frontier = []  # list of entries arranged in a heap
    entry_finder = {}  # mapping of tasks to entries
    REMOVED = '<removed-task>'  # placeholder for a removed task
    counter = itertools.count()  # unique sequence count

    def add_node(n, priority):
        'Add a new node or update the priority of an existing node'
        if n.state in entry_finder:
            remove_node(n)
        count = next(counter)
        entry = [priority, count, n]
        entry_finder[n.state] = entry
        heapq.heappush(frontier, entry)

    def remove_node(n):
        'Mark an existing node as REMOVED.  Raise KeyError if not found.'
        entry = entry_finder.pop(n.state)
        entry[-1] = REMOVED

    def pop_node():
        'Remove and return the lowest priority node. Raise KeyError if empty.'
        while frontier:
            priority, count, n = heapq.heappop(frontier)
            if n is not REMOVED:
                del entry_finder[n.state]
                return n
        raise KeyError('pop from an empty priority queue')

    # Initial starting state
    init_state = (0, 0)

    # Create root node
    node = Node(state=init_state, parent=None, action=None, path_cost=0)

    # Add root node to frontier
    add_node(node, priority=heuristic_function(node.state, board, goal_state))

    # Set up the explored as a hash set of states (which are tuples of indexes into the board)
    explored = set()

    while True:
        # If the frontier is empty, there is no path to the goal
        if len(frontier) == 0:
            return -1

        # Choose node in the frontier with lowest h(n) to expand
        node = pop_node()

        # Count number of expanded nodes if requested
        if verbose == 1:
            global expanded_count
            expanded_count += 1

        # Goal test applied when node selected for expansion
        if goal_test(node.state, board):
            return solution(node)

        # Add state to explored set
        explored.add(node.state)

        # For each possible action at the current state
        for action in actions(node.state, board):
            # Create child node
            child = child_node(parent=node, action=action)

            # Avoid redundant paths and repeated states (just check the entry finder since it contains
            # all nodes in the frontier, keyed by their state)
            if child.state not in explored and child.state not in entry_finder:
                add_node(child, priority=heuristic_function(child.state, board, goal_state))
            # if child.state is in frontier with higher h(n)
            # entry_finder stores lists of [h(n), count, node]
            elif child.state in entry_finder and \
                    entry_finder[child.state][0] > heuristic_function(child.state, board, goal_state):
                # Replace frontier node with child
                remove_node(entry_finder[child.state][2])
                add_node(child, priority=heuristic_function(child.state, board, goal_state))


# Runs the A* search algorithm on the given board. Returns a list of states that define
# the first path found by the algorithm
# Or -1 if there is no path to the goal
def a_star(board, goal_state):

    # Credit to using heapq as a priority queue to API documentation for python standard library:
    # https: // docs.python.org / 3 / library / heapq.html

    # Set up the frontier as a priority queue ordered by g(n) + h(n)
    frontier = []  # list of entries arranged in a heap
    entry_finder = {}  # mapping of tasks to entries
    REMOVED = '<removed-task>'  # placeholder for a removed task
    counter = itertools.count()  # unique sequence count

    def add_node(n, priority):
        'Add a new node or update the priority of an existing node'
        if n.state in entry_finder:
            remove_node(n)
        count = next(counter)
        entry = [priority, count, n]
        entry_finder[n.state] = entry
        heapq.heappush(frontier, entry)

    def remove_node(n):
        'Mark an existing node as REMOVED.  Raise KeyError if not found.'
        entry = entry_finder.pop(n.state)
        entry[-1] = REMOVED

    def pop_node():
        'Remove and return the lowest priority node. Raise KeyError if empty.'
        while frontier:
            priority, count, n = heapq.heappop(frontier)
            if n is not REMOVED:
                del entry_finder[n.state]
                return n
        raise KeyError('pop from an empty priority queue')

    # Initial starting state
    init_state = (0, 0)

    # Create root node
    node = Node(state=init_state, parent=None, action=None, path_cost=0)

    # Add root node to frontier
    add_node(node, priority=node.path_cost + heuristic_function(node.state, board, goal_state))

    # Set up the explored as a hash set of states (which are tuples of indexes into the board)
    explored = set()

    while True:
        # If the frontier is empty, there is no path to the goal
        if len(frontier) == 0:
            return -1

        # Choose node in the frontier with lowest g(n) + h(n) to expand
        node = pop_node()

        # Count number of expanded nodes if requested
        if verbose == 1:
            global expanded_count
            expanded_count += 1

        # Goal test applied when node selected for expansion
        if goal_test(node.state, board):
            return solution(node)

        # Add state to explored set
        explored.add(node.state)

        # For each possible action at the current state
        for action in actions(node.state, board):
            # Create child node
            child = child_node(parent=node, action=action)

            # Avoid redundant paths and repeated states (just check the entry finder since it contains
            # all nodes in the frontier, keyed by their state)
            if child.state not in explored and child.state not in entry_finder:
                add_node(child, priority=child.path_cost + heuristic_function(child.state, board, goal_state))
            # if child.state is in frontier with higher h(n)
            # entry_finder stores lists of [g(n) + h(n), count, node]
            elif child.state in entry_finder and \
                    (entry_finder[child.state][0] > (child.path_cost + heuristic_function(child.state, board, goal_state))):
                # Replace frontier node with child
                remove_node(entry_finder[child.state][2])
                add_node(child, priority=child.path_cost + heuristic_function(child.state, board, goal_state))


# Prints the found solution in the required format
def print_solution(sol):
    for step in sol:
        print(str(step[0]) + ',' + str(step[1]))
    if verbose == 1:
        print()
        print(expanded_count)


# Returns the goal state (index into the board for the 'G')
def find_goal_state(board):
    for i, r in enumerate(board):
        for j, c in enumerate(board[i]):
            if c == 'G':
                return (i, j)


# Reads in command line argument and runs the specified search algorithm on the number maze indicated by the
# second argument. The verbose option tells the algorithm to also print number of expanded nodes during search.
# If unique is 1 and DFS is selected, a modified tree search version will run which will count the total
# number of unique paths to the goal
def main():
    algorithm = sys.argv[1]
    if algorithm not in ["BFS", "DFS", "BestFirst", "AStar"]:
        print('Usage: python search.py <algorithm> <mazefile> <verbose> <unique>')
        print('Specified algorithm must be one of "BFS", "DFS", "BestFirst", "AStar"')
        print('Verbose of 0 will print only the solution. Verbose of 1 will print additional information.')
        print('If unique = 1 and DFS is being run, the tree version will run'
              'and the algorithm will output the total number of unique'
              'paths to the goal, instead of the single optimal path. Unique must of 1 or 0')
        return

    mazefile = sys.argv[2]

    # Set verbosity of program if this was passed in (otherwise default to 0)
    if len(sys.argv) >= 4:
        vbose = int(sys.argv[3])
        if vbose == 0 or vbose == 1:
            global verbose
            verbose = vbose

    if len(sys.argv) >= 5:
        count_tu = int(sys.argv[4])
        if count_tu == 0 or count_tu == 1:
            global count_total_unique
            count_total_unique = count_tu

    # The game board. Represented as a 2d list
    board = []
    with open(mazefile) as f:
        for idx, line in enumerate(f):
            row = line_to_row(line)
            board.append(row)

    # Run algorithm on board
    if algorithm == 'BFS':
        print_solution(breadth_first_search(board))
    elif algorithm == 'DFS':
        if count_total_unique == 0:
            print_solution(depth_first_search(board))
        else:
            print('Number of unique paths: ' + str(depth_first_tree_search(board)))
            if verbose == 1:
                print('Number of expanded nodes: ' + str(expanded_count))
    elif algorithm == 'BestFirst':
        goal_state = find_goal_state(board)
        print_solution(best_first_search(board, goal_state))
    elif algorithm == 'AStar':
        goal_state = find_goal_state(board)
        print_solution(a_star(board, goal_state))


if __name__ == '__main__':
    main()