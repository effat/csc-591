import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

public class SearchAlgorithms {
	
	static int [][] maze;
	static Location goal;
	static int statesExpanded = 0;
	static boolean foundGoalDFS = false;
	
	public int[][] getMaze() {
		return maze;
	}

	public static void setStatesExpanded() {
		SearchAlgorithms.statesExpanded = 0;
	}

	
	public SearchAlgorithms(String inputFile) throws IOException{
		byte[] encoded = Files.readAllBytes(Paths.get(inputFile));
		String stringMaze = new String(encoded, "UTF-8");

		String[] stringMazeSplitted = stringMaze.split("\n");
		maze = new int[stringMazeSplitted.length][stringMazeSplitted[0].split(",").length];

		for(int i=0; i<stringMazeSplitted.length; i++){
			String[] row = stringMazeSplitted[i].split(",");
			for(int j=0; j< row.length; j++){
				if(row[j].equals("G")){
					maze[i][j] = -1;
					goal = new Location(i, j, null, 0);
				}
				else
					maze[i][j] = Integer.parseInt(row[j]);
			}
		}
	

	}
	static class Location{
		int x;
		int y;
		Location parent;
		int cost;
		
		public Location(int x, int y, Location parent, int cost){
			this.x = x;
			this.y = y;
			this.parent = parent;
			this.cost = cost;
		}
		
		public String toString(){
			return "(" + this.x + "," + this.y  + ")" ;
		}
		
		public Location clone(){
			return new Location(this.x,this.y, this.parent,this.cost);
		}
		
		public boolean equals(Location a){
			return this.x == a.x && this.y == a.y;
		}

		public int getHeuristic(){
			//Special Case for Goal: h(G) = 0
			if(maze[this.x][this.y] == -1) return 0;
			
			boolean sameX = goal.x == this.x;
			boolean sameY = goal.y == this.y;
			boolean reachableFromGoal = Math.abs(goal.x - this.x) - maze[this.x][this.y] == 0 || Math.abs(goal.y - this.y) - maze[this.x][this.y] == 0;

			//If the current location is on same horizontal or vertical line with goal ... give it zero heuristic only if it reachable from goal
			// Otherwise, give it a heuristic of 1
			//If it is not on same horizontal or vertical line ... give it 2
			int horizontal = sameX? 1:0;
			int vertical = sameY? 1:0;
			int reachable = reachableFromGoal? 1:0;
			return horizontal * (reachable * (0) + (1-reachable) * 1) +
				   vertical * (reachable * (0) + (1-reachable) * 1) +
				   (1-horizontal) * (1-vertical) * (2); 
		}
		
//		@Override
//		public int compareTo(Location x) {
//			// TODO Auto-generated method stub
//			return this.cost - x.cost;
//		}
	}
	
	static class Result{
		ArrayList<Location> path;
		int statesExpanded;
		
		public Result(ArrayList<Location> path, int statesExpanded){
			this.path = path;
			this.statesExpanded = statesExpanded;
		}
		
		public String toString(){
			return "Path:( " + this.path + " ), States Expanded: " + this.statesExpanded;
		}
		
		public Result clone(){
			return new Result(this.path,this.statesExpanded);
		}
	}
	
	static class Record{
		ArrayList<Result> result;
		int shortestPathIndex;
		int uniquePaths;
		
		public Record(ArrayList<Result> result, int shortestPathIndex,int uniquePaths){
			this.result = result;
			this.shortestPathIndex = shortestPathIndex;
			this.uniquePaths = uniquePaths;
		}
	}
	
	//AStar Comparator: Path+Heuristic difference between two nodes
	public static Comparator<Location> aStarComparator = new Comparator<Location>(){
		
		@Override
		public int compare(Location c1, Location c2) {
            return c1.cost + c1.getHeuristic() - c2.cost - c2.getHeuristic();
        }
	};
	
	//Breadth First Comparator: Path Cost (assuming unit cost) difference between two nodes
	public static Comparator<Location> breadthFirstComparator = new Comparator<Location>(){
		
		@Override
		public int compare(Location c1, Location c2) {
            return c1.cost - c2.cost;
        }
	};

	//Best First Comparator: Heuristic Difference difference between two nodes
	public static Comparator<Location> bestFirstComparator = new Comparator<Location>(){
		
		@Override
		public int compare(Location c1, Location c2) {
            return c1.getHeuristic() - c2.getHeuristic();
        }
	};
	
	
	
	//This method handles AStar, BestFirst & BreadthFirst by manipulating the heuristic
	private Record heuristicSearch(Location root, Comparator<Location> comparator, String algorithm) {
		// BFS, BestFirst & AStar all incorporated in this function. The only difference is in the passed argument "comparator"
		// BFS: we compare by path cost only
		// Best First: Only heuristic
		// AStar: Heuristic and Parh Cost
		
		//Number of unique paths so far
		int uniquePaths = 0;
		// the index of the shortest path in our array
		int shortestPathIndex = Integer.MAX_VALUE;
		// the length of the shortest path in our array
		int shortestLength = Integer.MAX_VALUE;
		ArrayList<Result> solution = new ArrayList<Result>();

		root.cost = 0;
		PriorityQueue<Location> queue = new PriorityQueue<Location>(comparator);
		queue.add(root);
		
		while(!queue.isEmpty()){
			//pop out the current root (node)
			Location current = queue.poll();
			
			
			statesExpanded++;
			
			// The next part is replicated in depthFirst method ... go there for explanation of these lines.
			//Goal Found! Save states expanded and current path
			if(maze[current.x][current.y] == -1){
				ArrayList<Location> path = new ArrayList<Location>();
				path.add(current);
				Location pp = current.parent;
				while(pp != null){
					//Add nodes in reversed order to show readable path!
					path.add(0, pp);
					pp = pp.parent;
					
				}
				
				uniquePaths++;
				
				//Compare current solution to the current shortest one
				
				if(path.size() - 1 < shortestLength){
					shortestLength = path.size() - 1;
					//The current shortest index will be at the end of the array, which is its current size (before actually adding it)
					shortestPathIndex = solution.size();
				}
				

				solution.add(new Result(path,statesExpanded));
					

				
				//if maze dimensions is greater than 8x8 and the algorithm is either BFS or AStar, then you already find optimal ... so terminate
				if(maze.length > 8 && maze[0].length > 8 ) return new Record(solution, shortestPathIndex, uniquePaths);
				
				//If the maze dimensions are 8x8 or smaller, we simply add all solutions and keep documenting!
				continue;
			}
			
			Location left = transitionFunction(current, "left");
			Location right = transitionFunction(current, "right");
			Location up = transitionFunction(current, "up");
			Location down = transitionFunction(current, "down");
			
			
			// We only add children to queue, if they are never like their parents (to avoid loops)
			
			if(!visited(up))
				queue.add(up);
//			System.out.println("Left: " + left + ", Cost:" + left.cost + ",  Heuristic: " + left.getHeuristic());
			
			if(!visited(down))
				queue.add(down);
//			System.out.println("Right: " + right + ", Cost:" + right.cost + ",  Heuristic: " + right.getHeuristic());
			
			if(!visited(left))
				queue.add(left);
//			System.out.println("Up: " + up + ", Cost:" + up.cost + ",  Heuristic: " + up.getHeuristic());
			
			if(!visited(right))
				queue.add(right);
//			System.out.println("Down: " + down + ", Cost:" + down.cost + ",  Heuristic: " + down.getHeuristic());

			
		}
		
		
		return new Record(solution, shortestPathIndex,uniquePaths);
		
	}


	public boolean visited (Location current){
		Location p = current.parent;
		while(p != null){
			if(current.equals(p)){
				return true;
			}
			p = p.parent;
		}
		
		return false;
	}

	
	private Record depthFirst(Location current) {
		//terminate a recursion whenever the firstGoal is found among one of the other branches
		if(foundGoalDFS) return null;
		
		//Array to store solution, each as pair of: (Path to Goal, States Expanded to Reach this path)
		ArrayList<Result> solution = new ArrayList<Result>();
		
		// if the current node is similar to one of its parents (ancestors) .. return null, because this is a loop
		Location p = current.parent;
		while(p != null){
			if(current.equals(p))
				return null;
			p = p.parent;
		}
		
		//increment states expanded by 1
		statesExpanded++;

		//Goal Found! Save states expanded and current path
		if(maze[current.x][current.y] == -1){
			
			if(maze.length>8 && maze[0].length>8) foundGoalDFS = true;
			
			ArrayList<Location> path = new ArrayList<Location>();
			path.add(current);
			Location pp = current.parent;
			while(pp != null){
				//Add nodes in reversed order to show readable path!
				// the last found node is the goal ... we need to print it in the last position in our printed sequence..
				// Thats why we reverse the path.
				path.add(0, pp);
				pp = pp.parent;
			}
//			System.out.println(new Result(path,statesExpanded));
			solution.add(new Result(path,statesExpanded));
			//index of shortest path at a leaf is always 0
			return new Record(solution, 0,0); 
		}
		
		// We need to branch now! and concatenate all found results!
		Record upChoice = depthFirst(transitionFunction(current, "up"));
		Record downChoice = depthFirst(transitionFunction(current, "down"));
		Record leftChoice = depthFirst(transitionFunction(current, "left"));
		Record rightChoice = depthFirst(transitionFunction(current, "right"));

		// All of the following code is to handle cases where one of the branches return null...
		// Basically we want to get the shortest path in 4 branches ... each branch has a candidate shortest one ..
		// We compare the 4 by listing the length of each in a priority queue. and then since we will inlcude all paths in one array
		// We need to update the shortest index with the new offset. 
		// For example, originally it was at position 2 in right branch ... and left branch has overall of 10 solutions..
		// So, when we concatenate left array with right array ... now the shortest index is at index (10+2) = 12 in the new array.
		if(upChoice != null){
			for(int i=0; i<upChoice.result.size(); i++)
				solution.add(upChoice.result.get(i));
		}
		
		if(downChoice != null){
			for(int i=0; i<downChoice.result.size(); i++)
				solution.add(downChoice.result.get(i));
		}

		if(leftChoice != null){
			for(int i=0; i<leftChoice.result.size(); i++)
				solution.add(leftChoice.result.get(i));
		}
		
		if(rightChoice != null){
			for(int i=0; i<rightChoice.result.size(); i++)
				solution.add(rightChoice.result.get(i));
		}
		
		

		int shortestPathIndex = -1;

		int upSolutionSize = upChoice == null? 0: upChoice.result.size();
		int downSolutionSize = downChoice == null? 0: downChoice.result.size();
		int leftSolutionSize = leftChoice == null? 0: leftChoice.result.size();
		
		int leftShortestLength = leftChoice == null? Integer.MAX_VALUE: leftChoice.result.get(leftChoice.shortestPathIndex).path.size() - 1;
		int rightShortestLength = rightChoice == null? Integer.MAX_VALUE: rightChoice.result.get(rightChoice.shortestPathIndex).path.size() - 1;
		int upShortestLength = upChoice == null? Integer.MAX_VALUE: upChoice.result.get(upChoice.shortestPathIndex).path.size() - 1;
		int downShortestLength = downChoice == null? Integer.MAX_VALUE: downChoice.result.get(downChoice.shortestPathIndex).path.size() - 1;
		
		PriorityQueue<Integer> length = new PriorityQueue<>();
		length.add(upShortestLength);
		length.add(downShortestLength);
		length.add(leftShortestLength);
		length.add(rightShortestLength);

		
		if(length.peek() == upShortestLength && upChoice != null){ 
			shortestPathIndex = upChoice.shortestPathIndex;}
		else{
			if(length.peek() == downShortestLength && downChoice != null) { shortestPathIndex = downChoice.shortestPathIndex + upSolutionSize; }
			else{
				if(length.peek() == leftShortestLength && leftChoice != null){ shortestPathIndex = leftChoice.shortestPathIndex + upSolutionSize + downSolutionSize;}
				else{
					if(length.peek() == rightShortestLength && rightChoice != null){shortestPathIndex = rightChoice.shortestPathIndex + upSolutionSize + downSolutionSize + leftSolutionSize;}
				}
			}
		}

		if(solution.size() == 0) return null;
		return new Record(solution, shortestPathIndex,0);
	}
	
	private Location transitionFunction(Location a, String direction){
		int shift = this.maze[a.x][a.y];
		if(shift == -1) return a;
		
		int newLocation;
		
		//The transition function implements the move in the game, and creates a new child whose path cost is more than its parent by 1
		
		switch (direction) {
		case "up":
			newLocation = a.x - shift < 0? a.x: a.x - shift;
			return new Location(newLocation, a.y,a,a.cost+1);
		
		case "down":
			newLocation = a.x + shift > maze[0].length - 1 ? a.x : a.x + shift ;
			return new Location(newLocation, a.y,a,a.cost+1);
		
		case "left":
			newLocation = a.y - shift < 0? a.y: a.y - shift;
			return new Location(a.x, newLocation,a,a.cost+1);
		
		case "right":
			newLocation = a.y + shift > maze.length - 1 ? a.y : a.y + shift ;

			return new Location(a.x, newLocation,a,a.cost+1);

		default:
			break;
		}
		
		return null;
	}
	

	

	
	private static void printResult(ArrayList<Result> x) {
		
		for(int i=0; i<x.size(); i++){
			System.out.println(x.get(i));
		}
	}

	private static void PrintSummary(Record result, String algorithm, int mazeLength, int mazeWidth, String fileName) throws IOException {

		//Return no answer if the result is empty
		if(result.result.size() == 0){
			System.out.println("No Solution exists for this maze!");
			return;
		}
		System.out.println();
		
		//For small mazes, we print all possible paths, each with states expanded to reach it + total number of unique paths
		if(mazeLength <= 8 && mazeWidth <= 8){
			System.out.println("Paths & States Expanded to find each: \n \n");
			printResult(result.result);
			System.out.println();
			if(algorithm.equals("DFS"))
				System.out.println("Unique Paths: " + result.result.size());
			else
				System.out.println("Unique Paths: " + result.uniquePaths);
		}
		
		System.out.println("Algorithm Used: " + algorithm + ", Maze Dimensions:" + mazeLength + "x" + mazeWidth);
		
		//Shortest Path
		
		// In case of big mazes, just return the first answer, which is optimal in BFS or AStar.
		
		int shortest_index = mazeLength > 8 && mazeWidth > 8? 0:result.shortestPathIndex;
		if(mazeLength > 8 && mazeWidth > 8){
			String x = algorithm.equals("DFS") || algorithm.equals("BestFirst")? "First":"Shortest";
			System.out.println(x +" Path:" + result.result.get(0).path);
			System.out.println("States Expanded to Find it: " + result.result.get(0).statesExpanded);

		}
		else{
			System.out.println("Shortest Path:" + result.result.get(result.shortestPathIndex).path);
			System.out.println("States Expanded to Find it: " + result.result.get(result.shortestPathIndex).statesExpanded);
		}
		
		
		//Writing in File
		int fileStart = 0;
		for(int i = 0; i<fileName.length(); i++){
			if(fileName.charAt(i) == '\\') {
				fileStart = i+1;
				break;
			}
		}
		fileName = fileName.substring(fileStart);


		FileWriter writer = new FileWriter(new File(".\\Solution_"+algorithm + fileName));
		for(int i=0; i<result.result.get(shortest_index).path.size(); i++){
			Location l = result.result.get(shortest_index).path.get(i);
			writer.write(l.x +"," + l.y+ "\n");
		}
		writer.close();
	}
	
//	@SuppressWarnings("static-access")
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		
		/*
		   java -jar MyCode.jar <algorithm> <mazefile>

		   Where the algorithm names should be: "BFS" "DFS" "BestFirst" and "AStar".
		 */
		
		/*
		 jar cfe myJar.jar myClass myClass.class
		 java -jar myJar.jar

		 */
		String algorithm = args[0];
//		String algorithm = "BestFirst";
		String fileName = args[1];
//		String fileName = "12x12a-maze.txt";
		SearchAlgorithms search = new SearchAlgorithms(fileName);
		
		//We create the variable to hold results, and the root of each tree, which is the top left corner of the maze
		Record result = null;
		Location root = new Location(0, 0, null, 0);
		
		//According to the input algorithm argument, we call the specific method
		switch (algorithm) {
		case "DFS":
			result = search.depthFirst(root);
			break;
		case "BFS":
			result = search.heuristicSearch(root, breadthFirstComparator, "BFS");
			break;
		case "BestFirst":
			result = search.heuristicSearch(root, bestFirstComparator, "BestFirst");
			break;
		case "AStar":
			result = search.heuristicSearch(root, aStarComparator, "AStar");
			break;
		default:
			break;
		}

		PrintSummary(result,algorithm,search.maze.length,maze[0].length,fileName);
		
		

		
	}












}
