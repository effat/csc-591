Name: Mark Abdelshiheed
Unity ID: mnabdels
Student ID: 200261369

CSC 520 (artificial Intelligence) -- Assignment 1


Executing the code:



Option 1 (Source Code):

a-) extract the zip folder "mnabdels_NumberMaze.zip"
b-) Go To src file
c-) Compiler the java code:

    javac SearchAlgorithms.java

d-) Run the java file with this format:  java SearchAlgorithms <algorithm_name> <relative_path_to_maze_from_src"

For example:

    java SearchAlgorithms DFS ..\4x4Maze-maze.txt


Note that it generates a file of solution in the same directory from where the command was executed.



Option 2 (Jar File):

execute the following command:

    java -jar mnabdels.jar BFS 4x4Maze-maze.txt





Code Structure:

1- DFS is implemented inside the method "depthFirst(Location current)"
2- BFS, BestFirst and AStar are implemented inside the method: "heuristicSearch(Location root, Comparator<Location> comparator, String algorithm)"
   The comparator differs from one algorithm to another to specify how to compare two nodes in the priority queue.

3- There are three additional classes that achieves the encapsulation of objects:
    - Location : Represents a current node in the graph (priority queue). It has x location, y location, a parent of its type and a path cost
    - Result: It has two attributes:
            - Path: which is a sequence of locations from start to goal
            - Expanded States which represents the number of expanded states to reach that goal
    - Record: It is an arraylist of results, with the index of the shortest path in them.

