    import java.util.*;
    /**
     * Controls the solutions to the maze for all 4 (5 if you count DFSALL) algorithms
     *
     * @author Josh Arfin
     * @version 1/31/19
     */
    public class Solver
    {
        // instance variables - replace the example below with your own
        private int x=0;
        private int tot,npaths; 
        public PriorityList pl;
        /**
         * Constructor for objects of class Solver
         * Finds x, which tells the solver which algorithm to call
         */
        public Solver(String method)
        {
                      
            if(method.equals("DFS")){
                x=2;
                
            }else{
                if(method.equals("AStar")){                 
                    x=4;
                    
                }else{
                    if(method.equals("BestFirst")){
                        x=3;
                        
                    }else{
                        x=1;
                        if(method.equals("DFSALL")){
                            x=5;
                        }
                    }
                }
            }
            
        }
        /**
     * go tells the appropriate algorithm to find a/all solutions
     */
        public String go(CreateMaze built){
            String solution;
            if(x==2){
                solution=dfs(built);
                return(solution);
            }
            if(x==5){
                solution=dfsall(built);
                return(solution);
            }
            if(x==1){
                solution=bfs(built);
                return(solution);
            }
            if(x==3){
                solution=best(built);
                return(solution);
            }
            if(x==4){
                solution=astar(built);
                return(solution);
            }
            return("Yes");
        } 
        
        /**
     * AStar sets up the lists used in the recursive algorithm as well as assigning the appropriate values for the origin
     * calls the recursive solver
     */
        private String astar(CreateMaze built){
            int current=0;  
            int k;
            LinkedList<Integer> been=new LinkedList<Integer>();
            ArrayList<Integer> queue=new ArrayList<Integer>(); 
            ArrayList<Integer> queuep=new ArrayList<Integer>(); 
            been.add(current);
            k=3;
               if(built.board.get(current).row+built.board.get(current).num==built.gr||built.board.get(current).col+built.board.get(current).num==built.gc||built.board.get(current).row-built.board.get(current).num==built.gr||built.board.get(current).col-built.board.get(current).num==built.gc){
              k=2;
            }         
            if(built.board.get(current).row==built.gr||built.board.get(current).col==built.gc){
                 k=1;
                 if(built.board.get(current).row==built.gr&&built.board.get(current).col==built.gc){
                      k=0;
                 }
            }
            
            
            
            queue.add(current);
            queuep.add(k);
            built.board.get(current).path.add(current);
            int tot=1;
            
            return(astarreccur(built,been,queue,queuep,tot,0));
        }
        
        private String astarreccur(CreateMaze built,LinkedList<Integer> been,ArrayList<Integer> queue,ArrayList<Integer> queuep, int tot,int p){
            /**
             * Called Recursively to run astar
             * p indexes the estimated distance starting and resetting from 0 and going up until a member of the queue has that estimated cost
             */
            int current;
            int index=queuep.indexOf(p); 
            
                    if(index>-1){
                        current=queue.remove(index);                        
                        queuep.remove(index);
                        
                        int k;
                        /**
                           * Check if at solution
                             * returns string that ends up as the out file
                               */
                        if(built.board.get(current).num==0){
                            
                            String st="";
                            String temp;
                            while(built.board.get(current).path.isEmpty()==false){
                                int j=built.board.get(current).path.remove(0);
                                
                                    temp='('+Integer.toString(built.board.get(j).row)+','+Integer.toString(built.board.get(j).col)+')';
                                    st=st+' '+temp;
                                   
                            }
                            st=st+' '+tot;
                            return(st);
                        }
                        tot++;
                        /**
                           * Look at each of the 4 directions and if possible, add it to queue
                             * ensures that location has not yet been explored
                               */
                    if(built.board.get(current).row>=built.board.get(current).num){
                            int too=current-built.r*built.board.get(current).num;
                            if(been.contains(too)==false){
                                been.add(too);
                                
                                for(int i=0;i<built.board.get(current).path.size();i++){
                                    built.board.get(too).path.add(built.board.get(current).path.get(i));
                                }
                                built.board.get(too).path.add(too);
                                k=3;
                                if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                                    k=2;
                                }
                                if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                                    k=1;
                                    if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                        k=0;
                                    }
                                }
                                
                                queue.add(too);
                                int estcost=k+built.board.get(too).path.size();
                                queuep.add(estcost);
                            }
                        }
                    if(built.board.get(current).row+built.board.get(current).num<built.r){
                        int too=current+built.r*built.board.get(current).num;
                        if(been.contains(too)==false){
                            been.add(too);
                            
                            for(int i=0;i<built.board.get(current).path.size();i++){
                                    built.board.get(too).path.add(built.board.get(current).path.get(i));
                                }                    
                            built.board.get(too).path.add(too);
                            k=3;
                               if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                                    k=2;
                                }  
                                if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                                    k=1;
                                    if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                        k=0;
                                    }
                                }
                               
                                queue.add(too);
                                int estcost=k+built.board.get(too).path.size();
                                queuep.add(estcost);
                            }
                            
                        }                
                        
                    if(built.board.get(current).col>=built.board.get(current).num){
                        int too=current-built.board.get(current).num;
                        if(been.contains(too)==false){
                           been.add(too);
                           
                           for(int i=0;i<built.board.get(current).path.size();i++){
                                    built.board.get(too).path.add(built.board.get(current).path.get(i));
                                } 
                           built.board.get(too).path.add(too);
                           k=3;
                              if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                                    k=2;
                                }   
                                if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                                    k=1;
                                    if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                        k=0;
                                    }
                                }
                               
                                queue.add(too);
                                int estcost=k+built.board.get(too).path.size();
                                queuep.add(estcost);
                            }
                    }
                    if(built.board.get(current).col+built.board.get(current).num<built.c){
                        int too=current+built.board.get(current).num;
                        if(been.contains(too)==false){
                           been.add(too);
                           
                           for(int i=0;i<built.board.get(current).path.size();i++){
                                    built.board.get(too).path.add(built.board.get(current).path.get(i));
                                } 
                           built.board.get(too).path.add(too);
                           k=3;
                               if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                                    k=2;
                                } 
                                if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                                    k=1;
                                    if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                        k=0;
                                    }
                                }
                                
                                queue.add(too);
                                int estcost=k+built.board.get(too).path.size();
                                queuep.add(estcost);
                        }
                    }
                    /**
                       * Recurrsively calls this method ressetting p to 0
                           */
                    return(astarreccur(built,been,queue,queuep,tot,0));
                }
                /** increase p and recursively call the method with larger p*/
            p++;
            return(astarreccur(built,been,queue,queuep,tot,p));
        }
        /**
           * BestFirst algorithm
           * builds path stack and calls recursive function
               */
        private String best(CreateMaze built){
            int current=0;       
            Stack<Integer> path=new Stack<Integer>();
            path.push(current);            
            int tot=0;
            return(bestreccur(built,path,tot));
        }
        
        /**
           *reccursive function for bestfirst
           *picks best of possible options the runs an equivalent of depth first search, always going to the best option as deep as possible
           */
        private String bestreccur(CreateMaze built,Stack<Integer> path, int tot){
            int current =path.peek();
            String complete;
            tot++;
            ArrayList<Integer> min=new ArrayList<Integer>();
            ArrayList<Integer> nexts=new ArrayList<Integer>();
            /**
                           * Check if at solution
                             * returns string that ends up as the out file
                               */
            if(built.board.get(current).num==0){
                String st="";
                String temp;
                while(path.empty()==false){
                    int k=path.pop();
                    
                        temp='('+Integer.toString(built.board.get(k).row)+','+Integer.toString(built.board.get(k).col)+')';
                        st=temp+' '+st;
                       
                }
                st=st+' '+tot;
                return(st);
            }
            
            for(int i=0;i<4;i++){
                min.add(-1);
                min.add(-1);
                min.add(-1);
                min.add(-1);
                nexts.add(-1);
                nexts.add(-1);
                nexts.add(-1);
                nexts.add(-1);
                int k;
                if(built.board.get(current).row>=built.board.get(current).num){
                    int too=current-built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        k=3;
                        if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                            k=2;
                        }
                        if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                            k=1;
                            if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                k=0;
                            }
                        }
                        
                        min.remove(i);
                        min.add(i,k);
                        nexts.remove(i);
                        nexts.add(i,too);
                        
                    }
                }
                if(built.board.get(current).row+built.board.get(current).num<built.r&&i==1){
                    int too=current+built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        k=3;
                        if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                            k=2;
                        }
                        if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                            k=1;
                            if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                k=0;
                            }
                        }
                        
                        min.remove(i);
                        min.add(i,k);
                        nexts.remove(i);
                        nexts.add(i,too);
                    }
                }
                if(built.board.get(current).col>=built.board.get(current).num&&i==2){
                    int too=current-built.board.get(current).num;
                    if(path.search(too)==-1){
                        k=3;
                        if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                            k=2;
                        }
                        if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                            k=1;
                            if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                k=0;
                            }
                        }
                        
                        min.remove(i);
                        min.add(i,k);
                        nexts.remove(i);
                        nexts.add(i,too);
                    }
                }
                if(built.board.get(current).col+built.board.get(current).num<built.c&&i==3){
                    int too=current+built.board.get(current).num;
                    if(path.search(too)==-1){
                        k=3;
                        if(built.board.get(too).row+built.board.get(too).num==built.gr||built.board.get(too).col+built.board.get(too).num==built.gc||built.board.get(too).row-built.board.get(too).num==built.gr||built.board.get(too).col-built.board.get(too).num==built.gc){
                            k=2;
                        }
                        if(built.board.get(too).row==built.gr||built.board.get(too).col==built.gc){
                            k=1;
                            if(built.board.get(too).row==built.gr&&built.board.get(too).col==built.gc){
                                k=0;
                            }
                        }
                        
                        min.remove(i);
                        min.add(i,k);
                        nexts.remove(i);
                        nexts.add(i,too);
                    }
                }
            } 
            for(int i=0;i<4;i++){
                while(min.contains(i)){
                    int loc=min.indexOf(i);
                    min.remove(loc);
                    min.add(loc,-1);
                    path.push(nexts.get(loc));
                        complete=dfsreccur(built,path,tot);
                        if(complete!="no"){
                            return(complete);
                        }
                }
            }
            return("no");
        }
        /**
           *Breadth first search, creats queue and list of previous locations then calls recursive function
            */
        private String bfs(CreateMaze built){
            int current=0;       
            LinkedList<Integer> been=new LinkedList<Integer>();
            LinkedList<Integer> queue=new LinkedList<Integer>(); 
            been.add(current);
            queue.add(current);
            built.board.get(current).path.add(current);
            int tot=1;
            return(bfsreccur(built,been,queue,tot));
        }
        
        private String bfsreccur(CreateMaze built,LinkedList<Integer> been,LinkedList<Integer> queue, int tot){
            int current=queue.poll();          
            if(built.board.get(current).num==0){
                
                String st="";
                String temp;
                /**
                           * Check if at solution
                             * returns string that ends up as the out file
                               */
                while(built.board.get(current).path.isEmpty()==false){
                    int k=built.board.get(current).path.remove(0);
                    
                        temp='('+Integer.toString(built.board.get(k).row)+','+Integer.toString(built.board.get(k).col)+')';
                        st=st+' '+temp;
                       
                }
                st=st+' '+tot;
                return(st);
            }
            /**
                           * Checks each of the four directions to see what to add to the queue
                               */
            if(built.board.get(current).row>=built.board.get(current).num){
                    int too=current-built.r*built.board.get(current).num;
                    if(been.contains(too)==false){
                        been.add(too);
                        queue.add(too);
                        for(int i=0;i<built.board.get(current).path.size();i++){
                            built.board.get(too).path.add(built.board.get(current).path.get(i));
                        }
                        built.board.get(too).path.add(too);
                        
                    }
                }
            if(built.board.get(current).row+built.board.get(current).num<built.r){
                int too=current+built.r*built.board.get(current).num;
                if(been.contains(too)==false){
                    been.add(too);
                    queue.add(too);
                    for(int i=0;i<built.board.get(current).path.size();i++){
                            built.board.get(too).path.add(built.board.get(current).path.get(i));
                        }                    
                    built.board.get(too).path.add(too);
                    
                    }
                    
                }                
                
            if(built.board.get(current).col>=built.board.get(current).num){
                int too=current-built.board.get(current).num;
                if(been.contains(too)==false){
                   been.add(too);
                   queue.add(too);
                   for(int i=0;i<built.board.get(current).path.size();i++){
                            built.board.get(too).path.add(built.board.get(current).path.get(i));
                        } 
                   built.board.get(too).path.add(too);
                   
                    }
            }
            if(built.board.get(current).col+built.board.get(current).num<built.c){
                int too=current+built.board.get(current).num;
                if(been.contains(too)==false){
                   been.add(too);
                   queue.add(too);
                   for(int i=0;i<built.board.get(current).path.size();i++){
                            built.board.get(too).path.add(built.board.get(current).path.get(i));
                        } 
                   built.board.get(too).path.add(too);
                   
                }
            }
            /**
                           * Recursively call this function
                               */
            tot++;
            return(bfsreccur(built,been,queue,tot));
        }
        /**
                           * DFS initiator, builds stack for algorithm, calls recursive method
                               */
        private String dfs(CreateMaze built){
            int current=0;       
            Stack<Integer> path=new Stack<Integer>();
            path.push(current);            
            int tot=0;
            return(dfsreccur(built,path,tot));
        }
         
        private String dfsreccur(CreateMaze built,Stack<Integer> path,int tot){
            int current =path.peek();
            String complete;
            tot++;
            /**
                           * Check if at solution
                             * returns string that ends up as the out file
                               */
            if(built.board.get(current).num==0){
                String st="";
                String temp;
                while(path.empty()==false){
                    int k=path.pop();
                    
                        temp='('+Integer.toString(built.board.get(k).row)+','+Integer.toString(built.board.get(k).col)+')';
                        st=temp+' '+st;
                       
                }
                st=st+' '+tot;
                return(st);
            }
            /**
                           * Check each of the four directsions
                           * Before for loop completes, recursively calls itself to complete the depth search
                               */
            for(int i=0;i<4;i++){
                if(built.board.get(current).row>=built.board.get(current).num&&i==0){
                    int too=current-built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        complete=dfsreccur(built,path,tot);
                        if(complete!="no"){
                            return(complete);
                        }
                    }
                }
                if(built.board.get(current).row+built.board.get(current).num<built.r&&i==1){
                    int too=current+built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        complete=dfsreccur(built,path,tot);
                        if(complete!="no"){
                            return(complete);
                        }
                    }
                }
                if(built.board.get(current).col>=built.board.get(current).num&&i==2){
                    int too=current-built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        complete=dfsreccur(built,path,tot);
                        if(complete!="no"){
                            return(complete);
                        }
                    }
                }
                if(built.board.get(current).col+built.board.get(current).num<built.c&&i==3){
                    int too=current+built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        complete=dfsreccur(built,path,tot);
                        if(complete!="no"){
                            return(complete);
                        }
                    }
                }
            }   
            return("no");
        }
        /**
                           * DFSALL works just like dfs, except it prints completed paths and doesnt stop when it encounters a path
                               */
        private String dfsall(CreateMaze built){
            int current=0;       
            Stack<Integer> path=new Stack<Integer>();
            path.push(current);            
            int tot=0;
            int npaths=0;
            
            
            return(dfsallreccur(built,path));
        }
         
        private String dfsallreccur(CreateMaze built,Stack<Integer> path){
            int current =path.peek();
            
            tot++;
            
            if(built.board.get(current).num==0){
                
                npaths++;
                String st="";
                String temp;
                for(int i=0;i<path.search(0);i++){
                    int k=path.get(i);
                    
                        temp='('+Integer.toString(built.board.get(k).row)+','+Integer.toString(built.board.get(k).col)+')';
                        st=st+' '+temp;                       
                }
                System.out.println(st);
                
            }
            
            for(int i=0;i<4;i++){
                
                if(built.board.get(current).row>=built.board.get(current).num&&i==0){
                    int too=current-built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        dfsallreccur(built,path); 
                        path.pop();
                    }
                }
                if(built.board.get(current).row+built.board.get(current).num<built.r&&i==1){
                    
                    int too=current+built.r*built.board.get(current).num;
                    if(path.search(too)==-1){
                        
                        path.push(too);
                        dfsallreccur(built,path);
                        path.pop();
                    }
                }
                if(built.board.get(current).col>=built.board.get(current).num&&i==2){
                    int too=current-built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        dfsallreccur(built,path);
                        path.pop();
                    }
                }
                if(built.board.get(current).col+built.board.get(current).num<built.c&&i==3){
                    int too=current+built.board.get(current).num;
                    if(path.search(too)==-1){
                        path.push(too);
                        dfsallreccur(built,path);
                        path.pop();
                    }
                }
            }   
            return("paths "+npaths+" Explored "+tot);
        }
    }
