import java.util.ArrayList;
/**
 * Creates the puzzle
 *
 * @author Josh Arfin
 * @version 1/31/19
 */
public class CreateMaze
{
    // instance variables - replace the example below with your own
    ArrayList<Square> board;
    public int r,c, gr, gc;
    

    /**
     * Constructor for objects of class CreateMaze
     * Creates squares that store their row, column, and number
     */
    public CreateMaze(int rows, int cols,ArrayList<Integer> numbs,int grow, int gcol)
    {
        r=rows;
        c=cols;
        gr=grow;
        gc=gcol;
        int size=rows*cols;
        board=new ArrayList<Square>(size);
        Square tempsq;
        int n=0;
            for(int i=0;i<rows;i++){
                for(int j=0;j<cols;j++){
                    tempsq= new Square(i,j,numbs.get(n));
                    board.add(n,tempsq);
                    n++;
                }
                
            }
        
    }


}
