import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
/**
 * Maze reads in the command line information, processes it and tells the other methods to due their job
 *
 * @author Josh Arfin
 * @version 1/31/19
 */
public class Maze
{
    // instance variables - replace the example below with your own
    public int grow,gcol;

    /**
     * Constructor for objects of class Maze
     */
    public static void main(String[] args)
    {
       Maze solver = new Maze();
       solver.go(args, solver);
    }

    /**
     * Create a scanner and and a printer
     * calls reader go to execute the solver and print to the file out.txt
     */
    public void go(String[] args, Maze solver)
    {
        String method=args[0];
        
        Scanner infile;
       
        try{
            File file = new File(args[1]);
             infile = new Scanner(file);
            
            PrintWriter out = new PrintWriter("out.txt");
            go(infile, out, args[0]);
           
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    
    public void go(Scanner infile,PrintWriter out, String method){
        String st = null;
        int cols=1;
        int rows=1;
         grow=0;
         gcol=0;
        boolean bool=false;
        String currentline;
        
        /**
     * Loop through the lines of the file counting the number of columns and rows as well as identifying the goal location
     * create a string that has all of numbers from the file, with 0 replacing G
     */
   
        while(infile.hasNextLine()){
            if(st==null){
                st = infile.nextLine();
                for(int i=0;i<st.length();i++){
                    if(st.charAt(i)=='G'){
                        gcol=cols-1;
                        grow=1;
                        if(i>0){
                            if(i<st.length()){
                                String st1=st.substring(0,i)+'0'+st.substring(i+1,st.length());
                                st=st1;
                            }else{
                                String st1=st.substring(0,i)+'0';
                                st=st1;
                            }
                        }else{
                            String st1='0'+st.substring(1,st.length());
                            st=st1;
                        }
                    }
                   
                    if(st.charAt(i)==','){
                        cols++;
                    }                  
                }
                
            }else{
                if(bool==false){
                    grow=0;
                }                
                currentline=infile.nextLine();
                
                for(int i=0;i<currentline.length();i++){
                    
                    if(currentline.charAt(i)==','&&bool==false){
                        grow++;
                    }
                    if(currentline.charAt(i)=='G'){
                        bool=true;
                        gcol=cols-1;
                        if(i>0){
                            if(i<currentline.length()){
                                String st1=currentline.substring(0,i)+'0'+currentline.substring(i+1,currentline.length());
                                currentline=st1;
                            }else{
                                String st1=currentline.substring(0,i)+'0';
                                currentline=st1;
                            }
                        }else{
                            String st1='0'+currentline.substring(1,currentline.length());
                            currentline=st1;
                        }
                    }
                    
                }
                rows++;
                st=st+","+currentline;
            }
        }
        /**
     * Build a list of integers that occupy the locations in the maze
     */
        int size=rows*cols;
        String[] parts = st.split(",");
        ArrayList<Integer> ints=new ArrayList<Integer>(size);
        
        for (int i = 0; i < size; i++) {
            int k= Integer.parseInt(parts[i]);
             ints.add(i,k);
        }
        /**
     * Call CreateMaze to build the maze and Solve to solve the puzzle
     * Print the result
       */
        CreateMaze builtmaze=new CreateMaze(rows,cols,ints,grow,gcol);
        Solver solve=new Solver(method);
        String ans=solve.go(builtmaze);
        out.println(ans);
        out.close();
    }
}
