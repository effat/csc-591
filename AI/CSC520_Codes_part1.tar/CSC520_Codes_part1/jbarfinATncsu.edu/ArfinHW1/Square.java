import java.util.ArrayList;
/**
 * construcot of objects that represent a location  in the rectangle
 *
 * @author Josh Arfin
 * @version 1/31/19
 */
public class Square
{
    // instance variables - replace the example below with your own
    public int row, col, num;
    /**
                           * Maintains its current path for the DFSALL algorithm
                               */
    public ArrayList<Integer> path = new ArrayList<Integer>();

    /**
     * Constructor for objects of class Square
     */
    public Square(int r, int c, int n)
    {
        // initialise instance variables
        row=r;
        col=c;
        num=n;
    }

    
}
