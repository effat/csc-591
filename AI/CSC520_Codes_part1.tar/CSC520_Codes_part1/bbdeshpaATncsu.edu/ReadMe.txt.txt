
Bhargav Deshpande
bbdeshpa
*********************************************************
The folder contains below Items excluding Readme.txt
- bbdeshpa_AI_HW1 - Report and Solutions
- Mycode.jar - Program Jar file for all algorithms

**********************************************************

Instruction to run:
Open Windows command Prompt and run these below commands

1. DFS - Single Path:  java -jar {Jar file path} DFS {maze file path}
Eg. java -jar C:\Users\Bhargav\Desktop\MyCode.jar DFS C:\Users\Bhargav\Desktop\25x25-maze.txt

2. BFS - Single Path:  java -jar {Jar file path} BFS {maze file path}

3. Astar - Single Path: java -jar {Jar file path} AStar {maze file path}

4. BestFirst - Single Path: java -jar {Jar file path} BestFirst {maze file path}

5. All Paths - Only DFS is implimented accordingly: (Will not work for other algos)
java -jar {Jar file path} DFS {maze file path} all

If you are using other tool, any alternative way to run a jar with arguments will work 


