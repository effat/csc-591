import sys

file_name = sys.argv[1]

#"TrainingMazes/4x4Maze-maze.txt"
with open(file_name, "r") as f:
    content = f.read().splitlines() #store lines in 'content'

class Node:
    def __init__(self, id, row, column, value, target):
        self.id = id        #id is coordinates
        self.row = row
        self.column = column
        self.value = value  #store number/'G' inside the square
        self.visited = False#Initialize as not visited yet
        self.adjacent = []

        # Check if able to move up, down, left, right without hitting walls
        # If so, store the coordinates of neighbors in adjacent[]
        if not target:
            if (self.row - self.value, self.column) in maze_dict.keys():
                self.adjacent.append((self.row - self.value, self.column))
            if (self.row + self.value, self.column) in maze_dict.keys():
                self.adjacent.append((self.row + self.value, self.column))
            if (self.row, self.column - self.value) in maze_dict.keys():
                self.adjacent.append((self.row, self.column - self.value))
            if (self.row, self.column + self.value) in maze_dict.keys():
                self.adjacent.append((self.row, self.column + self.value))
            self.target = False
        # If square is "G", designate as target
        else:
            self.target = True

def initialize_maze(content):
    # Take file contents and make a dict
    # key: coordinates or graph space, value: value stored in the square

    maze_list = []
    maze_dict = {}
    for line in content:
        maze_list.append(line.split(","))


    for x in range(0, len(maze_list)):
        for y in range(0, len(maze_list)):
            maze_dict[(x,y)] = maze_list[x][y]

    return maze_dict


def DFS(start, findall=False, path=None):

    # To print out shortest path
    if not findall:
        if start.visited:           #if already visited, don't expand further
            return False

        start.visited = True        #otherwise mark as visited
        global dfs_count            #import global variables
        global dfs_answer
        dfs_count = dfs_count + 1   #tally states expanded

        if start.target:            #if destination found, recursion is over
            return True

        for adjacent_node in start.adjacent:    #run recursively on child nodes
            if DFS(nodes[adjacent_node]):       #if destination found,
                dfs_answer.append(nodes[adjacent_node].id)   #append node to answer
                return True                             #and return True

    # If looking to print number of paths
    else:

        global unique_paths
        start.visited = True        #mark as visited
        path.append(start.id)

        if start.target:            #if destination found, count another unique path found
            unique_paths = unique_paths + 1

        else:
            for adjacent_node in start.adjacent:    #run recursively on child nodes,
                if not nodes[adjacent_node].visited:#if not already visited.
                    dfs_count = dfs_count + 1       #count another state expanded
                    DFS(nodes[adjacent_node], findall=True, path=path)

        path.pop()              #Remove the most recently added node
        start.visited = False   #Count it as unvisited again

    return False


def BFS(start):
    # takes node object as parameter

    queue = [start.id]          #initialize queue to hold adjacent nodes, starting with (0,0)
    start.visited = True        #mark (0,0) as visited
    previous = {start.id: None} #initialize a dict to store previously visited node
    answer = []                 #initialize a list to store the path taken to destination
    expanded_states = 0         #initialize count, currently no states expanded

    while queue:
        temp = queue.pop(0)                     #get the first node in the list
        for i in nodes[temp].adjacent:          #for each adjacent node, append to queue if not visited
            if not nodes[i].visited:
                queue.append(i)
                expanded_states += 1
                nodes[i].visited = True
                previous[nodes[i].id] = temp    #record which node was visited to get here
                if nodes[i].target:             #if it's the target node,
                    destination = nodes[i].id   #store the id in 'destination', add coordinates to answer, break loop
                    answer.append(destination)
                    break

    while True:                                 #retrace the 'previous' dict and store the backwards path in 'answer'
        if previous[destination] is None:
            break
        answer.append(previous[destination])
        destination = previous[destination]

    return answer[::-1], expanded_states


def best_first(start, goal):

    queue = [start.id]          #initialize queue to hold adjacent nodes, starting with (0,0)
    start.visited = True        #mark (0,0) as visited
    previous = {start.id: None} #initialize a dict to store previously visited node
    answer = []                 #initialize a list to store the path taken to destination
    expanded_states = 0         #initialize count, currently no states expanded

    while queue:
        temp = queue.pop(0)                     #get the first node in the list
        expanded_states += 1
        priority_queue = prioritize_nodes(      #call heuristic function to prioritize nodes
            nodes[temp].adjacent, goal
        )
        for i in priority_queue:                #for each adjacent node, append to queue if not visited
            if not nodes[i].visited:
                queue.append(i)
                nodes[i].visited = True
                previous[nodes[i].id] = temp    #record which node was visited to get here
                if nodes[i].target:             #if it's the target node,
                    destination = nodes[i].id   #store the id in 'destination', add coordinates to answer, break loop
                    answer.append(destination)
                    break

    while True:                                 #retrace the 'previous' dict and store the backwards path in 'answer'
        if previous[destination] is None:
            break
        answer.append(previous[destination])
        destination = previous[destination]

    return answer[::-1], expanded_states


def prioritize_nodes(queue, target):
    # If same column and row, distance = 0
    # If same column different row, or vice versa, min distance is 1
    # If different row and column, min distance is 2

    distance = {0: [], 1: [], 2: []}    # Initialize empty dict

    for node in queue:                  # Add to dict based on heuristic function
        if node == target:
            distance[0].append(node)
        elif (node[0] == target[0] and node[1] != target[1]) or (node[0] != target[0] and node[1] == target[1]):
            distance[1].append(node)
        else:
            distance[2].append(node)
    priority_queue = distance[0] + distance[1] + distance[2]

    return priority_queue


def heuristic(node, target):
    # If same column and row, distance = 0
    # If same column different row, or vice versa, min distance is 1
    # If different row and column, min distance is 2

    if node == target:
        return 0
    elif (node[0] == target[0] and node[1] != target[1]) or (node[0] != target[0] and node[1] == target[1]):
        return 1
    else:
        return 2


def a_star(start, target):
    F, G = {}, {}   # Initialize dicts for total cost, and cost from start to current

    G[start] = 0    # No cost to get to start node
    F[start] = heuristic(start, target)     # call heuristic to get estimate cost to goal

    visited, unvisited = [], [start]        # Initialize lists to store explored and unexplored nodes
    previous = {}   # Store previously visited node
    cost = 0        # Cost before moving is 0

    while unvisited:
        cost += 1
        temp, fn = None, None   # temp will store node with current lowest F(n)
        for node in unvisited:  # find lowest F(n) in unvisited nodes
            if temp is None or F[node] < fn:
                fn = F[node]
                temp = node

        if temp == target:
            path = [temp]
            while temp in previous:
                temp = previous[temp]
                path.append(temp)
            return path.reverse()

        visited.append(temp)
        unvisited.remove(temp)

        for adjacent in nodes[temp].adjacent:
            if adjacent in visited:
                continue

        # previous completions of this while loop unable to locate goal state
        # successfully- need to evaluate adjacent nodes and update scores
        break

    return "Error"

# Take file contents and map coordinates to values
maze_dict = initialize_maze(content)

# Will map coordinates to node objects
nodes = {}
for key in maze_dict.keys():    # For each coordinate, make a node object
    if maze_dict[key] != 'G':
        node = Node(key, key[0], key[1], int(maze_dict[key]), False)
    else:
        node = Node(key, key[0], key[1], 0, True)
        target = key
    nodes[node.id] = node       # Store node objects in dict keyd by coordinates

dfs_count, unique_paths =  0, 0
dfs_answer, path = [], []

# Call DFS function, write result to a new file in correct format
DFS(nodes[(0,0)])
dfs_answer.reverse()
dfs_answer.insert(0,(0,0))
f = open(file_name[:-4]+" DFS.txt","w+")
for i in dfs_answer:
    f.write(str(i[0])+","+str(i[1]))
f.close()
print("DFS states expanded: ", dfs_count)

# Reset nodes to unvisited
for node in nodes:
    nodes[node].visited = False

# Write BFS results to file
answer, states = BFS(nodes[(0,0)])
f = open(file_name[:-4]+" BFS.txt","w+")
for i in answer:
    f.write(str(i[0])+","+str(i[1]))
f.close()
print("BFS states expanded: ", states)

# Reset nodes to unvisited
for node in nodes:
    nodes[node].visited = False

# Write Best First results to file
answer, states = best_first(nodes[(0,0)], target)
f = open(file_name[:-4]+" Best First.txt","w+")
for i in answer:
    f.write(str(i[0])+","+str(i[1]))
f.close()
print("Best First states expanded: ", states)
print("A* implementation incomplete- see code for partial implementation")

# Reset nodes to unvisited
for node in nodes:
    nodes[node].visited = False

# If 6x6 or 8x8 graph entered, print number of unique paths and states expanded to find
if len(content) == 6 or len(content) == 8:
    dfs_count = 0
    DFS(nodes[(0,0)], findall=True, path=path)
    print(str(dfs_count)+" states were expanded to find the "+str(unique_paths)+" unique paths that exist in this graph")
