Hello,

Please give the name of the algorithm as first argument and the second argument as the file name.

The program would give the shortest path and the number of states expanded for that algorithm itself.

The code file is well documented for the explanation of the algorithm.

And, all the 4 A B C D are answered using the algorithm DFS.
