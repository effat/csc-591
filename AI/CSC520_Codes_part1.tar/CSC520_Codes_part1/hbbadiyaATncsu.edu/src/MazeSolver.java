import java.io.*;
import java.util.*;

public class MazeSolver {

	//GLOBAL VARIABLES
	static int expanded[][]; // Used to store all the states/cells expanded
	static int firstCount;// Used to store the count of cells expanded for the first solution
	static boolean flag;
	public static void countFirst()//Utility function to calculate the states/cell expanded in the first solution
	{
		for(int i=0;i<expanded.length;i++)
			for(int j=0;j<expanded[0].length;j++)
				if(expanded[i][j]==1)//counting the number of states/cells expanded
					firstCount++;
	}
	public static boolean isValid(int x, int y, int X, int Y)//Utility function to check wether the cell is inside the four boundaries of the Maze
	{
		if(X>=0 && Y>=0 && X<x && Y<y)
			return true;//If it is within the boundary then returned value is TRUE, else FALSE is returned
		
		return false;
	}
	
	public static ArrayList<String> calPath(int X[][], int Y[][], int x, int y)// Utility function used to calculate the path using the Parent matrix(which stores the parent of the current cell)
	{
		ArrayList<String> tmp = new ArrayList<>();
		ArrayList<String> ans = new ArrayList<>();
		
		//Calculating the path from the Source to destination using the parent Matrix
		//which stores the location of the parent cell of each node
		while(!(x==0 && y==0))
		{
			String s  = (""+x)+","+(""+y);
			//Calculating the String as specified in the O/P format
			tmp.add(s);
			int tx = x, ty = y;
			x = X[tx][ty];	y = Y[tx][ty];	
		}
		
		tmp.add("0,0");
		
		for(int i=tmp.size()-1;i>=0;i--)
			ans.add(tmp.get(i));
		
		return ans;// Returning the path
	}
	public static void copy(int a[][], int b[][])//Utility function copy the contents of one array to other
	{
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[0].length;j++)
				a[i][j] = b[i][j];
		}
	}
	public static ArrayList<String> BFS(int arr[][])
	{
		
		/*
		 * This method is used to find a path from Source [0,0] to destination "G"
		 * using the BFS Algorithm.
		 * I have used two QUEUE(data structure in Java), to store the next nodes to be One QUEUE 
		 * is used to store the X-Coordinates and the other is used to store the Y-Coordinates.
		 * expanded, it is same as a Queue Data structure [Last In First Out]
		 * 
		 * So, initially the first node that is the starting index is added to the Arraylist  [0,0]
		 * 
		 * Then while the Goal is not reached OR the ArrayList is not empty the First element 
		 * of the Arraylist is Removed and all the 4 cells which we can reach from the current 
		 * cell is checked whether if we have visited those cells before and whether they lie
		 * within the four cells if all the conditions are satisfied then we add them to the
		 * Arraylist, also the Parent of those cells is updated (This is done to generate back the Path)
		 * 
		 */
		int n = arr.length, m = arr[0].length;
		expanded = new int[n][m];
		int visited[][] = new int[n][m];//This matrix stores whether we have already expanded the current cell and whether we should expand it or not
		int xParent[][] = new int[n][m];//This matrix stores the X-Coordinates of the Parent of each cell 
		int yParent[][] = new int[n][m];//This matrix stores the Y-Coordinates of the Parent of each cell 
		
		
	    Queue<Integer> xCor = new LinkedList<>();//QUEUE for storing the X_Coordinate of the next cell to be expanded
	    Queue<Integer> yCor = new LinkedList<>();//QUEUE for storing the Y_Coordinate of the next cell to be expanded
	    
	    xCor.add(0);	yCor.add(0);//Adding the first cell into the Queue
	    
	    while(xCor.size()!=0)//While the queue is not empty
	    {
	    	int curX = xCor.remove(), curY = yCor.remove();//Removing the first element from the Queue to get the X and Y Coordinate
	    	visited[curX][curY]=1;//Marking the current cell as Visited
	    	expanded[curX][curY]=1;//Marking the current cell as Expanded
	    	int hop = arr[curX][curY];//Fetching the value of the HOP
	    	int nxtX,nxtY;
	    	
	    	if(hop==0)//If hop is 0 that means that this is the Goal State
    		{
	    		if(flag==false)// if flag is False then this is the frist Path we encounterd
				{
					countFirst();// we count the number of states expanded for the first path
					flag = true;
				}
	    		return calPath(xParent, yParent, curX, curY);// we generate the path using the Parent matrix and return back the generated path using the utility function
    		}
	    	
	    	nxtX = curX-hop;	nxtY = curY;// calculating the location of UPPER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	nxtX = curX+hop;	nxtY = curY;// calculating the location of LOWER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}    	
	    	
	    	nxtX = curX;	nxtY = curY-hop;// calculating the location of LEFT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	
	    	nxtX = curX;	nxtY = curY+hop;// calculating the location of RIGHT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    }
	    
	    return new ArrayList<String>();// if there is no path generated we return an empty list
	    

	}
	public static void callAllPath(int x, int y, int visited[][], int arr[][], ArrayList<ArrayList<String>> paths, ArrayList<String> currPath)
	{
		int n=visited.length, m=visited[0].length;
		
		expanded[x][y] = 1;
		if(visited[x][y]==1 || (n>8 && m>8 && flag==true))
			return;
		if(arr[x][y]==0)
		{
			String s = (""+x)+","+(""+y);
			currPath.add(s);
			paths.add(currPath);
			if(flag==false)
			{
				countFirst();
				flag = true;
			}
			return;
		}
		
		int hop = arr[x][y];
		
		int nxtX, nxtY;
		
			
		nxtX = x - hop;	nxtY = y;// calculating the location of LOWER  Node
		if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
		{
			String s = (""+x)+","+(""+y);
			ArrayList<String> temp = new ArrayList<>(currPath);
			temp.add(s);
			visited[x][y] = 1;//Marking the current cell as Visited
			callAllPath(nxtX,nxtY,visited, arr, paths, temp);// Traversing to the next paths
			visited[x][y]=0;
		}
		
		
		nxtX = x + hop;	nxtY = y;// calculating the location of UPPER  Node	
		if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
		{
			String s = (""+x)+","+(""+y);
			ArrayList<String> temp = new ArrayList<>(currPath);
			temp.add(s);
			visited[x][y] = 1;//Marking the current cell as Visited
			callAllPath(nxtX,nxtY,visited, arr, paths, temp);// Traversing to the next paths
			visited[x][y]=0;
		}
		
		nxtX = x;	nxtY = y- hop;// calculating the location of LEFT  Node
		if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
		{
			String s = (""+x)+","+(""+y);
			ArrayList<String> temp = new ArrayList<>(currPath);
			temp.add(s);
			visited[x][y] = 1;//Marking the current cell as Visited
			callAllPath(nxtX,nxtY,visited, arr, paths, temp);// Traversing to the next paths
			visited[x][y]=0;
		}
		
		
		nxtX = x;	nxtY = y+ hop;// calculating the location of RIGHT  Node
		if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
		{
			String s = (""+x)+","+(""+y);
			ArrayList<String> temp = new ArrayList<>(currPath);
			temp.add(s);
			visited[x][y] = 1;//Marking the current cell as Visited
			callAllPath(nxtX,nxtY,visited, arr, paths, temp);// Traversing to the next paths
			visited[x][y]=0;
		}
			
	}
	public static void DFS(int arr[][])
	{
		
		int visited[][] = new int[arr.length][arr[0].length];//This matrix stores whether we have already expanded the current cell and whether we should expand it or not
		expanded = new int[arr.length][arr[0].length];
		ArrayList<ArrayList<String>> paths = new ArrayList<ArrayList<String>>();//This matrix stores the X-Coordinates of the Parent of each cell 
		ArrayList<String> curr = new ArrayList<>();//This matrix stores the Y-Coordinates of the Parent of each cell
		
		callAllPath(0,0,visited,arr,paths, curr);// This is the acyuall function to find the answers of Q4 ( a , b , c , d )
		int min = Integer.MAX_VALUE;
		ArrayList<String> minPath = new ArrayList<>();
		for(int i=0;i<paths.size();i++)
		{
			if(min>paths.get(i).size())
			{
				minPath = paths.get(i);
				min = paths.get(i).size();
			}
		}
		int count = 0;// calculating the total number of nodes expanded
		for(int i=0;i<expanded.length;i++)
			for(int j=0;j<expanded[0].length;j++)
				if(expanded[i][j]==1)
					count++;
		
		System.out.println("The shortest path "+minPath);
		System.out.println("The number of states expanded when finding the path "+firstCount);
		System.out.println("Total number of unique paths = "+paths.size());
		System.out.println("The number of states expanded in finding all the paths "+count);
		//Printing all the values returned
		

	}
	
	public static ArrayList<String> BF(int arr[][])
	{
		
		
		int goalX=0,goalY=0;//These two variables store the location of the goal sell
		
		int n = arr.length, m = arr[0].length;
		expanded = new int[n][m];
		for(int i=0;i<n;i++)
			for(int j=0;j<m;j++)
				if(arr[i][j]==0)
				{goalX=i;	goalY=j;	i=n;	break;}// finding the loaction of the goal cell
		
		int visited[][] = new int[n][m];//This matrix stores whether we have already expanded the current cell and whether we should expand it or not
		int xParent[][] = new int[n][m];//This matrix stores the X-Coordinates of the Parent of each cell 
		int yParent[][] = new int[n][m];//This matrix stores the Y-Coordinates of the Parent of each cell
		
		ArrayList<Integer> xCor = new ArrayList<>();//ArrayList for storing the X_Coordinate of the next cell to be expanded
		ArrayList<Integer> yCor = new ArrayList<>();//ArrayList for storing the X_Coordinate of the next cell to be expanded
	    
	    
	    xCor.add(0);	yCor.add(0);//Adding the Start node in the List
	    
	    
	    while(xCor.size()!=0)// While the list is not empty
	    {
	    	int nxtIndex=-1, minHeuristic=Integer.MAX_VALUE,minDistance=Integer.MAX_VALUE;
	    	
	    	for(int i=0;i<xCor.size();i++)
	    	{
	    		/*
	    		 * The Heuristic Function works in the following way
	    		 * 
	    		 * 	IF the next node/cell is in the same  ROW OR COLUMN as that of my the goal state then the H(N) => 1
	    		 * 	ELSE, H(N) => 2
	    		 */
	    		int heuristic = (goalX==xCor.get(i) || goalY==yCor.get(i)) ? 1 : 2;
	    		int dist = Math.abs(goalX-xCor.get(i)) + Math.abs(goalY-yCor.get(i));// Calculating the distance, this is used for TIE_BReaking
	    		
	    		
	    		if(heuristic<=minHeuristic)//If this is the best possible we can get after comparing it with previous heuristic value
	    		{
	    			if(nxtIndex==-1 || Math.abs(dist - arr[xCor.get(i)][yCor.get(i)])<minDistance)
	    			{
	    				heuristic=minHeuristic;// updating the min heuristic
	    				nxtIndex = i;//storing the index
	    				minDistance=Math.abs(dist - arr[xCor.get(i)][yCor.get(i)]);
	    			}
	    			
	    		}
	    	}
	    	
	    	int curX = xCor.get(nxtIndex), curY = yCor.get(nxtIndex);// fetching the next index 
	    	xCor.remove(nxtIndex);	yCor.remove(nxtIndex);// removing that index
	    	
	    	visited[curX][curY]=1;// marking this node as visited
	    	expanded[curX][curY]=1;//updating the global matrix
	    	int hop = arr[curX][curY];
	    	int nxtX,nxtY;
	    	
	    	if(hop==0)// found the GOAL
	    	{
	    		if(flag==false)// if this is the first path
				{
					countFirst();// calculating the num. of nodes expanded in first path
					flag = true;
				}
	    		return calPath(xParent, yParent, curX, curY);// calculating the path 
	    	}
	    	
	    	nxtX = curX+hop;	nxtY = curY;// calculating the location of UPPER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	nxtX = curX-hop;	nxtY = curY;// calculating the location of LOWER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	nxtX = curX;	nxtY = curY-hop;// calculating the location of LEFT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	
	    	nxtX = curX;	nxtY = curY+hop;// calculating the location of RIGHT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    }
	    
	    return new ArrayList<String>();
	    

	}

	
	public static ArrayList<String> AStar(int arr[][])
	{
		
		
		int goalX=0,goalY=0;	
		
		int n = arr.length, m = arr[0].length;
		expanded = new int[n][m];
		for(int i=0;i<n;i++)
			for(int j=0;j<m;j++)
				if(arr[i][j]==0)
				{goalX=i;	goalY=j;	i=n;	break;}
		
		int visited[][] = new int[n][m];//This matrix stores whether we have already expanded the current cell and whether we should expand it or not
		int xParent[][] = new int[n][m];//This matrix stores the X-Coordinates of the Parent of each cell 
		int yParent[][] = new int[n][m];//This matrix stores the Y-Coordinates of the Parent of each cell 
		
		ArrayList<Integer> xCor = new ArrayList<>();//LIST for storing the X_Coordinate of the next cell to be expanded
		ArrayList<Integer> yCor = new ArrayList<>();//LIST for storing the X_Coordinate of the next cell to be expanded
	    
	    
	    xCor.add(0);	yCor.add(0);//Adding the Starting node
	    
	    
	    while(xCor.size()!=0)
	    {
	    	int nxtIndex=-1, minTotalCost=Integer.MAX_VALUE,minDistance=Integer.MAX_VALUE;
	    	//checking each node to find the next favorable node to be visited with the help of the Heuristic Function
	    	for(int i=0;i<xCor.size();i++)
	    	{
	    		int heuristic = (goalX==xCor.get(i) || goalY==yCor.get(i)) ? 1 : 2;
	    		/*
	    		 * The Heuristic Function works in the following way
	    		 * 
	    		 * 	IF the next node/cell is in the same  ROW OR COLUMN as that of my the goal state then the H(N) => 1
	    		 * 	ELSE, H(N) => 2
	    		 * 
	    		 * Also,  I have kept the cost function as Unit, so a unit cost function as every time we make only one move.
	    		 */
	    		int totalCost = heuristic + 1;//Calculating the total cost => Heuristic + Cost Function
	    		int dist = Math.abs(goalX-xCor.get(i)) + Math.abs(goalY-yCor.get(i));// Calculating the distance, this is used for TIE_BReaking
	    		
	    		
	    		if(totalCost<=minTotalCost)//If this is the best possible we can get after comparing it with previous cost function
	    		{
	    			if(nxtIndex==-1 || Math.abs(dist - arr[xCor.get(i)][yCor.get(i)])<minDistance)
	    			{
	    				totalCost=minTotalCost;// updating the min cost
	    				nxtIndex = i;// storing the index
	    				minDistance=Math.abs(dist - arr[xCor.get(i)][yCor.get(i)]);
	    			}
	    			
	    		}
	    	}
	    	
	    	int curX = xCor.get(nxtIndex), curY = yCor.get(nxtIndex);
	    	xCor.remove(nxtIndex);	yCor.remove(nxtIndex);
	    	
	    	visited[curX][curY]=1;// marking this node as visited
	    	expanded[curX][curY]=1;//updating the global matrix
	    	int hop = arr[curX][curY];
	    	int nxtX,nxtY;
	    	
	    	if(hop==0)//If hop is 0 that means that this is the Goal State
	    	{
	    		if(flag==false)// if flag is False then this is the frist Path we encounterd
				{
					countFirst();// we count the number of states expanded for the first pat
					flag = true;
				}
	    		return calPath(xParent, yParent, curX, curY);//we generate the path using the Parent matrix and return back the generated path using the utility function
	    	}
	    	
	    	nxtX = curX+hop;	nxtY = curY;// calculating the location of LOWER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	nxtX = curX-hop;	nxtY = curY;// calculating the location of UPPER  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	nxtX = curX;	nxtY = curY-hop;// calculating the location of LEFT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    	
	    	
	    	nxtX = curX;	nxtY = curY+hop;// calculating the location of RIGHT  Node
	    	if(isValid(n,m,nxtX,nxtY) && visited[nxtX][nxtY]==0)// If this node has not been visited before and the location is within the boundary of the maze
	    	{
	    		xCor.add(nxtX);	yCor.add(nxtY);//if the conditions are satisfied we add this node to Queue and also store the parent of this node
	    		xParent[nxtX][nxtY] = curX;	yParent[nxtX][nxtY] = curY;
	    	}
	    }
	    
	    return new ArrayList<String>();
	    

	}
	
	public static void main(String[] args)throws IOException{
		
		
		
		String choice = args[0];
		File file = new File(args[1]);
		 
		
		 
		BufferedReader br = new BufferedReader(new FileReader(file)); 
		
		
		String st="";
		flag = false;
		firstCount=0;
		ArrayList<String> list = new ArrayList<>();
		while ((st = br.readLine()) != null) 
		{
		    st = st.replaceAll("G", "0");
		    list.add(st);
		}
		int n,m;
		
		n = list.size();
		m = list.get(0).length() - list.get(0).replaceAll(",","").length() + 1;
		
		int arr[][] = new int[n][m];
		
		for(int i=0;i<list.size();i++)
		{
			String[] parts = list.get(i).split(",");
			
			for (int j = 0; j < parts.length; j++) 
			    arr[i][j] = Integer.parseInt(parts[j]);
		}
		
		
         
        
        switch(choice)
        {
        case "BFS":	System.out.println(BFS(arr)+"\nThe number of states expanded when finding the path "+firstCount);
        			break;
        case "DFS": DFS(arr);
        			break;
        case "BestFirst":	System.out.println(BF(arr)+"\nThe number of states expanded when finding the path "+firstCount);
        			break;
        case "AStar":System.out.println(AStar(arr)+"\nThe number of states expanded when finding the path "+firstCount);
        			break;
        default:	System.out.println("Invalid Input!");
        }	
       
        
        
        
		
	}

}
