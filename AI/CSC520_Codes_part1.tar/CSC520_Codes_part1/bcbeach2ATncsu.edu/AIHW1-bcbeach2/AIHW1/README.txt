Bradley Beach
bcbeach2

HW1 Q4

To run this program, navigate a terminal to the containing folder, then use the command java -jar AIHW1.jar <algorithm> <mazefile>

Example: java -jar AIHW1.jar DFS 4x4Maze-maze.txt

The following four algorithm arguments work:
BFS
DFS
BestFirst
AStar

To use additional mazes, add them to the src folder.

When the program is complete, it will save the path to a file in the src folder. 