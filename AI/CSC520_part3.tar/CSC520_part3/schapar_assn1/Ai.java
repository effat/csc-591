import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

class Node{
        int x;
        int y;
        List<String> pre;
        public Node(){
                pre = new ArrayList<>();
        }
        public Node(int x, int y){
                this.x = x;
                this.y = y;
        }
}

class NodeV{
        int x;
        int y;
        int value;
        List<String> pre;
        public NodeV(){
                pre = new ArrayList<>();
        }
        public NodeV(int x, int y, int value){
                this.x = x;
                this.y = y;
                this.value = value;
        }
}

public class Ai {
        static List<List<String>> ans = new ArrayList<>();
        static List<String> small = new ArrayList<>();
        static int max = Integer.MAX_VALUE;
        public static void main(String args[]){
                if(args[0].equals("DFS"))       dfs_main(args[1]);
                else if(args[0].equals("BFS"))       bfs_main(args[1]);
                else if(args[0].equals("BESTFIRST"))  prio_main(args[1]);
                else if(args[0].equals("ASTAR"))        Astar(args[1]);
        }

        public static void dfs_main(String name){
                try{
                        File file = new File(name);
                        File ofile = new File("dfs_shortestpath.txt");
                        if(!ofile.exists())     ofile.createNewFile();
                        BufferedReader br = new BufferedReader(new FileReader(file));
                        FileWriter fw = new FileWriter(ofile);
                        BufferedWriter bw = new BufferedWriter(fw);
                        List<String> rows = new ArrayList<>();
                        String row = null;
                        while((row = br.readLine()) != null)    rows.add(row);
                        String[][] arr = new String[rows.size()][rows.get(0).split(",").length];
                        for(int i = 0 ; i < rows.size(); i++)   arr[i] = rows.get(i).split(",");
                        List<String> temp = new ArrayList<>();
                        dfs(arr, 0, 0, temp);
                        for(int i = 0 ; i < small.size(); i++) bw.write(small.get(i)+"\n");
                        System.out.println("DFS Shortest Path:");
                        for(int i = 0 ; i < small.size(); i++) System.out.println(small.get(i));
                        System.out.println("Number of nodes expanded in finding shortest path: "+small.size());
                        System.out.println("Total number of unique paths: "+ans.size());
                        int cc = 0;
                        for(int i = 0 ; i < ans.size(); i++)    cc += ans.get(i).size();
                        System.out.println("Number of states expaneded in finding unique paths: "+cc );
                        br.close();
                        bw.close();
                }
                catch(Exception e){

                }
        }

        public static void dfs(String[][] arr, int x, int y, List<String> temp){
                if(x >= 0 && y >= 0 && x < arr.length && y < arr[0].length){
                        if(!arr[x][y].equals("G")){
                                if(Integer.parseInt(arr[x][y]) > 0){
                                        int i = Integer.parseInt(arr[x][y]);
                                        int ii = -1 * i;
                                        arr[x][y] = String.valueOf(ii);
                                        temp.add(x+","+y);
                                        List<String> temp1 = new ArrayList<>(temp);
                                        dfs(arr, x + i, y, temp1);
                                        dfs(arr, x - i, y, temp1);
                                        dfs(arr, x, y + i, temp1);
                                        dfs(arr, x, y - i, temp1);
                                        temp.remove(temp.size() - 1);
                                        arr[x][y] = String.valueOf(i);
                                }
                        }
                        else{
                                List<String> a = new ArrayList<>(temp);
                                a.add(x+","+y);
                                ans.add(a);
                                if(max > a.size()){
                                        max = a.size();
                                        small = new ArrayList<>(a);
                                }
                        }
                }
        }

        public static void bfs_main(String name){
                        try{
                        File file = new File(name);
                        File ofile = new File("bfs_shortestpath.txt");
                        if(!ofile.exists())     ofile.createNewFile();
                        BufferedReader br = new BufferedReader(new FileReader(file));
                        FileWriter fw = new FileWriter(ofile);
                        BufferedWriter bw = new BufferedWriter(fw);
                        List<String> rows = new ArrayList<>();
                        String row = null;
                        while((row = br.readLine()) != null)    rows.add(row);
                        String[][] arr = new String[rows.size()][rows.get(0).split(",").length];
                        for(int i = 0 ; i < rows.size(); i++)   arr[i] = rows.get(i).split(",");
                        List<String> temp = new ArrayList<>();
                        Node n = new Node();
                        n.x = 0;
                        n.y = 0;
                        Queue<Node> queue = new LinkedList<>();
                        queue.add(n);
                        List<List<String>> anss = new ArrayList<>();
                        List<String> smalls = new ArrayList<>();
                        int maxs = Integer.MAX_VALUE;
                        while(!queue.isEmpty()){
                                int size = queue.size();
                                for(int i = 0; i < size; i++){
                                        Node ret = queue.poll();
                                        int x = ret.x, y = ret.y;
                                        if(x >= 0 && y >= 0 && x < arr.length && y < arr[0].length){
                                                ret.pre.add(x+","+y);
                                                if(!arr[x][y].equals("G")){
                                                        int ii = Integer.parseInt(arr[x][y]);
                                                        int a = x + ii, b = y;
                                                        String check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check)){
                                                                Node nn = new Node(a, b);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x - ii;
                                                        b = y;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check)){
                                                                Node nn = new Node(a, b);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y + ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check)){
                                                                Node nn = new Node(a, b);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y - ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check)){
                                                                Node nn = new Node(a, b);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                }
                                                else{
                                                        List<String> a = new ArrayList<>(ret.pre);
                                                        anss.add(a);
                                                        if(maxs > a.size()){
                                                                maxs = a.size();
                                                                smalls = new ArrayList<>(a);
                                                        }
                                                }
                                        }
                                }
                        }
                        for(int i = 0 ; i < smalls.size(); i++) bw.write(smalls.get(i)+"\n");
                        System.out.println("BFS Shortest Path:");
                        for(int i = 0 ; i < smalls.size(); i++) System.out.println(smalls.get(i));
                        System.out.println("Number of nodes expanded in finding shortest path: "+smalls.size());
                        System.out.println("Total number of unique paths: "+anss.size());
                        int cc = 0;
                        for(int i = 0 ; i < anss.size(); i++)    cc += anss.get(i).size();
                        System.out.println("Number of states expaneded in finding unique paths: "+cc );
                        br.close();
                        bw.close();
                }
                catch(Exception e){

                }
        }

        public static void prio_main(String name){
                        try{
                        File file = new File(name);
                        File ofile = new File("bestfirst_shortestpath.txt");
                        if(!ofile.exists())     ofile.createNewFile();
                        BufferedReader br = new BufferedReader(new FileReader(file));
                        FileWriter fw = new FileWriter(ofile);
                        BufferedWriter bw = new BufferedWriter(fw);
                        List<String> rows = new ArrayList<>();
                        String row = null;
                        while((row = br.readLine()) != null)    rows.add(row);
                        String[][] arr = new String[rows.size()][rows.get(0).split(",").length];
                        for(int i = 0 ; i < rows.size(); i++)   arr[i] = rows.get(i).split(",");
                        List<String> temp = new ArrayList<>();
                        NodeV n = new NodeV();
                        n.x = 0;
                        n.y = 0;
                        n.value = Integer.parseInt(arr[0][0]);
                        PriorityQueue<NodeV> queue = new PriorityQueue<>(new Comparator<NodeV>(){
                                @Override
                                public int compare(NodeV n1, NodeV n2){
                                        return n1.value > n2.value ? -1 : n1.value < n2.value ? 1 : 0;
                                }
                        });
                        queue.add(n);
                        List<List<String>> anss = new ArrayList<>();
                        List<String> smalls = new ArrayList<>();
                        int maxs = Integer.MAX_VALUE;
                        while(!queue.isEmpty()){
                                int size = queue.size();
                                for(int i = 0; i < size; i++){
                                        NodeV ret = queue.poll();
                                        int x = ret.x, y = ret.y;
                                                ret.pre.add(x+","+y);
                                                if(!arr[x][y].equals("G")){
                                                        int ii = Integer.parseInt(arr[x][y]);
                                                        int a = x + ii, b = y;
                                                        String check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b));
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x - ii;
                                                        b = y;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b));
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y + ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b));
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y - ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b));
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                }
                                                else{
                                                        List<String> a = new ArrayList<>(ret.pre);
                                                        anss.add(a);
                                                        if(maxs > a.size()){
                                                                maxs = a.size();
                                                                smalls = new ArrayList<>(a);
                                                        }
                                                }
                                        }
                                }
                        for(int i = 0 ; i < smalls.size(); i++) bw.write(smalls.get(i)+"\n");
                        System.out.println("Best First Shortest Path:");
                        for(int i = 0 ; i < smalls.size(); i++) System.out.println(smalls.get(i));
                        System.out.println("Number of nodes expanded in finding shortest path: "+smalls.size());
                        System.out.println("Total number of unique paths: "+anss.size());
                        int cc = 0;
                        for(int i = 0 ; i < anss.size(); i++)    cc += anss.get(i).size();
                        System.out.println("Number of states expaneded in finding unique paths: "+cc );
                        br.close();
                        bw.close();
                }
                catch(Exception e){

                }
        }

        public static void Astar(String name){
                        try{
                        File file = new File(name);
                        File ofile = new File("astar_shortestpath.txt");
                        if(!ofile.exists())     ofile.createNewFile();
                        BufferedReader br = new BufferedReader(new FileReader(file));
                        FileWriter fw = new FileWriter(ofile);
                        BufferedWriter bw = new BufferedWriter(fw);
                        List<String> rows = new ArrayList<>();
                        String row = null;
                        while((row = br.readLine()) != null)    rows.add(row);
                        String[][] arr = new String[rows.size()][rows.get(0).split(",").length];
                        for(int i = 0 ; i < rows.size(); i++)   arr[i] = rows.get(i).split(",");
                        List<String> temp = new ArrayList<>();
                        NodeV n = new NodeV();
                        n.x = 0;
                        n.y = 0;
                        n.value = Integer.parseInt(arr[0][0]);
                        PriorityQueue<NodeV> queue = new PriorityQueue<>(new Comparator<NodeV>(){
                                @Override
                                public int compare(NodeV n1, NodeV n2){
                                        return n1.value > n2.value ? -1 : n1.value < n2.value ? 1 : 0;
                                }
                        });
                        queue.add(n);
                        List<List<String>> anss = new ArrayList<>();
                        List<String> smalls = new ArrayList<>();
                        int maxs = Integer.MAX_VALUE;
                        while(!queue.isEmpty()){
                                int size = queue.size();
                                for(int i = 0; i < size; i++){
                                        NodeV ret = queue.poll();
                                        int x = ret.x, y = ret.y;
                                                ret.pre.add(x+","+y);
                                                if(!arr[x][y].equals("G")){
                                                        int ii = Integer.parseInt(arr[x][y]);
                                                        int a = x + ii, b = y, astarsize = ret.pre.size();
                                                        String check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b) + astarsize);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x - ii;
                                                        b = y;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b) + astarsize);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y + ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b) + astarsize);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                        a = x;
                                                        b = y - ii;
                                                        check = String.valueOf(a+","+b);
                                                        if(!ret.pre.contains(check) && a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                                                                NodeV nn = new NodeV(a, b, huristic(arr, a, b) + astarsize);
                                                                nn.pre = new ArrayList<>(ret.pre);
                                                                queue.add(nn);
                                                        }
                                                }
                                                else{
                                                        List<String> a = new ArrayList<>(ret.pre);
                                                        anss.add(a);
                                                        if(maxs > a.size()){
                                                                maxs = a.size();
                                                                smalls = new ArrayList<>(a);
                                                        }
                                                }
                                        }
                                }
                        for(int i = 0 ; i < smalls.size(); i++) bw.write(smalls.get(i)+"\n");
                        System.out.println("Astar Shortest Path:");
                        for(int i = 0 ; i < smalls.size(); i++) System.out.println(smalls.get(i));
                        System.out.println("Number of nodes expanded in finding shortest path: "+smalls.size());
                        System.out.println("Total number of unique paths: "+anss.size());
                        int cc = 0;
                        for(int i = 0 ; i < anss.size(); i++)    cc += anss.get(i).size();
                        System.out.println("Number of states expaneded in finding unique paths: "+cc );
                        br.close();
                        bw.close();
                }
                catch(Exception e){

                }
        }

        public static int huristic(String[][] arr, int x, int y){
                if(arr[x][y].equals("G"))       return 0;
                int ii = Integer.parseInt(arr[x][y]);
                int a = x + ii, b = y;
                if(a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                        if(arr[a][b].equals("G"))       return 1;
                }
                a = x - ii;
                b = y;
                if(a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                        if(arr[a][b].equals("G"))       return 1;
                }
                a = x;
                b = y + ii;
                if(a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                        if(arr[a][b].equals("G"))       return 1;
                }
                a = x;
                b = y - ii;
                if(a >= 0 && b >= 0 && a < arr.length && b < arr[0].length){
                        if(arr[a][b].equals("G"))       return 1;
                }
                return 2;
        }
}
