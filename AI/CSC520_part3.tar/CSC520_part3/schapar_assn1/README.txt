To run the program named Ai.java, You need to have jdk installed on your machine.
If you don't have it installed, in ubuntu machine you can install by using the
command below:
	sudo apt-get install default-jdk

Once, Jdk is installed, you can compile and run the code as follows:
Step1:
	javac Ai.java

Step2:
	java Ai BFS/DFS/BESTFIRST/ASTAR input.txt
	
--> In the step 2 above, second argument is Object file name generated in step 1, 
which is Ai, third argument is one of the four algorithms names(BFS,DFS,BESTFIRST,ASTAR)
and fourth argument is input file name.

--> After above two steps, it will generate the output file showing the shortest path
for the maze given in input file. The filename will be named as algorithmname_shortestpath.txt.
For ex, for BFS, it will generate the output file as bfs_shortestpath.txt.
--> The above code also prints the following four to the console.
	1) Shortest Path
	2) Number of nodes expanded in finding shortest path
	3) Total Number of unique paths
	4) Number of states expanded in finding unique paths
