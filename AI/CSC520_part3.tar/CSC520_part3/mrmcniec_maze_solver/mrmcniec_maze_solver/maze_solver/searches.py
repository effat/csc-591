import math
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Useful Globals
actions = ["Up", "Down", "Left", "Right"]

# Matt McNiece
# mrmcniec @ ncsu . edu
# NCSU CSC 520 AI
# Homework 1 - Number Maze Solver

# Module contains the actual serch algorithm we had to implement, each 
# takes the same inputs and returns the same output so can easily compare between them
# Abstractions of mazes and search graph are handled by other modules

def bfs(maze, queue, search_graph):
    """
    Implementation of Breadth-First Search
    maze: Maze Object representing a number maze
    queue: Python Deque
    search_graph: SearchGraph Object, populated for size of maze
    """

    global actions
    # Set up start of problem
    search_graph.graph[(0, 0)].set_state("Generated")
    search_graph.graph[(0, 0)].path_cost = 0

    # Check that we're not at trivial solution
    if maze.is_goal(0, 0):
        logger.debug(f"Returning from BFS Because (0, 0) is Goal!")
        return search_graph

    # Iterate Over Queue
    queue.append((0, 0))
    while len(queue) > 0:
        # Pull Shallowest Node from Queue and Explore
        current_node = queue.pop()
        search_graph.graph[current_node].set_state('Expanded')
        logger.debug(f"Graph: {search_graph.graph}")

        for action in actions:
            next_node = maze.move(*current_node, action)
            logger.debug(f"Moving {action} from {current_node}, got {next_node}")
            if next_node is None:  # Wall/Out of Bounds
                continue

            if search_graph.graph[next_node].state == "Not-Explored":
                search_graph.graph[next_node].set_state("Generated")
                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1

                # Check if this is the goal
                if maze.is_goal(*next_node):
                    logger.debug(f"Returning from BFS Because {next_node} is Goal!")
                    return search_graph

                # Otherwise Append and Continue
                queue.append(next_node)
        logger.debug(f"Expanded {current_node}")
        logger.debug(f"Graph: {search_graph.graph}")


def dfs(maze, queue, search_graph):
    """
    Implementation of Depth-First Search
    maze: Maze Object representing a number maze
    queue: Python Deque
    search_graph: SearchGraph Object, populated for size of maze
    """
    global actions
    # Set up start of problem
    search_graph.graph[(0, 0)].set_state("Generated")
    search_graph.graph[(0, 0)].path_cost = 0

    # Check that we're not at trivial solution
    if maze.is_goal(0, 0):
        logger.debug(f"Returning from DFS Because (0, 0) is Goal!")
        return search_graph

    # Iterate Over Queue
    queue.appendleft((0, 0))
    while len(queue) > 0:
        # Pull Shallowest Node from Queue and Explore
        current_node = queue.pop()
        search_graph.graph[current_node].set_state('Expanded')
        logger.debug(f"Graph: {search_graph.graph}")

        for action in actions:
            next_node = maze.move(*current_node, action)
            logger.debug(f"Moving {action} from {current_node}, got {next_node}")
            if next_node is None:  # Wall/Out of Bounds
                continue

            if search_graph.graph[next_node].state == "Not-Explored":
                search_graph.graph[next_node].set_state("Generated")
                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1

                # Check if this is the goal
                if maze.is_goal(*next_node):
                    logger.debug(f"Returning from DFS Because {next_node} is Goal!")
                    return search_graph

                # Otherwise Append and Continue
                queue.appendleft(next_node)
        logger.debug(f"Expanded {current_node}")
        logger.debug(f"Graph: {search_graph.graph}")


def best_first(maze, search_graph):
    """
    Implementation of BestFirst Search
    maze: Maze Object representing a number maze
    queue: Python Deque
    search_graph: SearchGraph Object, populated for size of maze
    """

    global actions
    # Set up start of problem
    start = (0, 0)
    search_graph.graph[start].set_state("Generated")
    search_graph.graph[start].path_cost = 0

    # Cheap Priority Queue
    queue = []
    queue.append((search_graph.graph[start].path_cost, start))

    while len(queue) > 0:
        queue.sort(key=lambda tup: tup[0])
        current_node = queue.pop(0)[1]  # Pop Left and Drop the Priority Part

        if maze.is_goal(*current_node):
            logger.debug(f"Returning from BestFirst Because f{current_node} is Goal!")
            return search_graph

        search_graph.graph[current_node].set_state('Expanded')
        logger.debug(f"Graph: {search_graph.graph}")

        for action in actions:
            next_node = maze.move(*current_node, action)
            logger.debug(f"Moving {action} from {current_node}, got {next_node}")
            if next_node is None:
                continue

            if search_graph.graph[next_node].state == "Not-Explored":
                search_graph.graph[next_node].set_state("Generated")
                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1

                queue.append(
                    (search_graph.graph[next_node].path_cost, next_node))
            elif search_graph.graph[next_node].state == "Generated" and \
                    search_graph.graph[next_node].path_cost > search_graph.graph[current_node].path_cost + 1:
                # the existing path is more expensive than current parent plus one

                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1


def astar_heuristic_jumpable_radius(maze, current_node):
    """
    Heuristic function that checks if the goal state is within
    the 'jump' radius of a current node.  If it is, then return an additional weight of 0
    otherwise, return a weight of 1
    """
    current_value = maze.get(*current_node)
    goal_pos = maze.goal_position

    euclidian_distance = math.sqrt(
        ((current_node[0] + goal_pos[0])**2) +
        ((current_node[1] + goal_pos[1])**2)
    )

    if current_value == 'G':
        return 0
    elif current_value >= euclidian_distance:
        return 0
    else:
        return 1


def astar(maze, queue, search_graph):
    # Heurisic
    # Not Euclidian, Not Manhattan
    # Jump Distance + Manhattan?
    global actions
    # Set up start of problem
    start = (0, 0)
    search_graph.graph[start].set_state("Generated")
    search_graph.graph[start].path_cost = 0

    # Cheap Priority Queue
    queue = []
    queue.append((search_graph.graph[start].path_cost +
                  astar_heuristic_jumpable_radius(maze, start), start))

    while len(queue) > 0:
        queue.sort(key=lambda tup: tup[0])
        current_node = queue.pop(0)[1]  # Pop Left and Drop the Priority Part

        if maze.is_goal(*current_node):
            logger.debug(f"Returning from BestFirst Because f{current_node} is Goal!")
            return search_graph

        search_graph.graph[current_node].set_state('Expanded')
        logger.debug(f"Graph: {search_graph.graph}")

        for action in actions:
            next_node = maze.move(*current_node, action)
            logger.debug(f"Moving {action} from {current_node}, got {next_node}")
            if next_node is None:
                continue

            if search_graph.graph[next_node].state == "Not-Explored":
                search_graph.graph[next_node].set_state("Generated")
                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1

                queue.append(
                    (search_graph.graph[next_node].path_cost + astar_heuristic_jumpable_radius(maze, next_node), next_node))
            elif search_graph.graph[next_node].state == "Generated" and \
                    search_graph.graph[next_node].path_cost > search_graph.graph[current_node].path_cost + 1:
                # the existing path is more expensive than current parent plus one

                search_graph.graph[next_node].set_action(action)
                search_graph.graph[next_node].parent = current_node
                search_graph.graph[next_node].path_cost = search_graph.graph[current_node].path_cost + 1
