from pprint import pprint
import logging
import texttable

# Matt McNiece
# mrmcniec @ ncsu . edu
# NCSU CSC 520 AI
# Homework 1 - Number Maze Solver

# This module represents a maze, and some helper functions to iterate over the maze

logger = logging.getLogger(__name__)

class Maze(object):
    def __init__(self, maze_list):
        self.maze = maze_list
        self.width = None
        self.height = None
        self._get_dimensions()
        self._width_idx = self.width - 1
        self._height_idx = self.height -1
        self.goal_position  = None
        self._find_goal()

    def _find_goal(self):
        for i in range(self.width):
            for j in range(self.height):
                if self.maze[i][j] == 'G':
                    self.goal_position = (i, j)

    def _get_dimensions(self):
        # Ensure Rows are all the same length, maze must be rectangular
        row_1_len = len(self.maze[0])
        for idx, row in enumerate(self.maze):
            if len(row) != row_1_len:
                logger.critical(f"Error, rows are different lengths, row1 is {row_1_len}, row {idx} is {len(row)}")
        logger.debug("Verified all rows are the same length")

        # Get Maze Dimensions
        width = row_1_len
        height = len(self.maze)
        logger.debug(f"Maze Dimensions {width}x{height}")

        self.width = width
        self.height = height

    def get(self, row, col):
        return self.maze[row][col]

    def is_goal(self, row, col):
        if self.maze[row][col] == 'G':
            return True
        else:
            return False

    def left(self, row, col):
        # For the value of the number in the number maze
        # reutrn the value of the square to the "left" number of jumps
        jump_distance = self.maze[row][col]
        target_col = col - jump_distance
        if target_col < 0:
            return None
        else:
            return (row, target_col)

    def right(self, row, col):
        # For the value of the number in the number maze
        # reutrn the value of the square to the "right" number of jumps
        jump_distance = self.maze[row][col]
        target_col = col + jump_distance
        if target_col > self._height_idx:
            return None
        else:
            return (row, target_col)

    def up(self, row, col):
        # For the value of the number in the number maze
        # reutrn the value of the square to the "up" number of jumps
        jump_distance = self.maze[row][col]
        target_row = row - jump_distance
        if target_row < 0:
            return None
        else:
            return (target_row, col)

    def down(self, row, col):
        # For the value of the number in the number maze
        # reutrn the value of the square to the "down" number of jumps
        jump_distance = self.maze[row][col]
        target_row = row + jump_distance
        if target_row > self._width_idx:
            return None
        else:
            return (target_row, col)

    def pretty(self):
        table = texttable.Texttable()
        table.set_cols_align(["c"] * self.width)
        table.set_cols_valign(["m"] * self.width)
        pretty_maze = [[i for i in range(self.width)]]
        pretty_maze.extend(self.maze)
        table.add_rows(pretty_maze)
        print(table.draw() + "\n")

    def move(self, row, col, direction):
        logger.debug(f"Move called with {row}, {col}, {direction}")
        actions = ["Up", "Down", "Left", "Right"]

        if direction == "Up":
            return self.up(row, col)
        elif direction == "Down":
            return self.down(row, col)
        elif direction == "Left":
            return self.left(row, col)
        elif direction == "Right":
            return self.right(row, col)
        else:
            raise KeyError(f"{direction} not recognized, must be in {actions}")
