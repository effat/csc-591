echo "Running Maze Solver for All Algorithms on All Graphs";
source mazes_venv/bin/activate;

set -e
Files=("TrainingMazes/4x4Maze-maze.txt" 
       "TrainingMazes/6x6Maze.txt" 
       "TrainingMazes/8x8-maze.txt"
       "TrainingMazes/12x12a-maze.txt" 
       "TrainingMazes/12x12b-maze.txt" 
       "TrainingMazes/25x25-maze.txt" )

algs=("BFS" "DFS" "BestFirst" "AStar")

for file in ${Files[*]}
    do
        for alg in ${algs[*]}
            do
                echo "Calling Maze:" $file "Algorithm:" $alg;
                python maze_solver/maze_solver.py $file $alg 
            done
    done